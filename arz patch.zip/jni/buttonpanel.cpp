#include "main.h"
#include "gui/ui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "playertags.h"
#include "dialog.h"
#include "scoreboard.h"
#include "settings.h"
#include "buttonpanel.h"

extern CGame *pGame;
extern CNetGame *pNetGame;
extern CDialog *pDialog;
extern CScoreBoard *pScoreBoard;
extern CSettings *pSettings;
extern UI *pUI;

ButtonPanel::ButtonPanel()
{
	m_bOpen = false;
}

void ButtonPanel::draw()
{
	if(pNetGame && pUI)
	{
		CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
		CLocalPlayer *pLocal = pNetGame->GetPlayerPool()->GetLocalPlayer();
		ImVec2 vecButSize = pSettings->Get().m_buttonPanelSize;
		
		ImGui::Begin("###buttonPanel", nullptr,
			ImGuiWindowFlags_NoTitleBar |
			ImGuiWindowFlags_NoResize |
			ImGuiWindowFlags_NoScrollbar |
			ImGuiWindowFlags_NoBackground |
			ImGuiWindowFlags_NoSavedSettings |
			ImGuiWindowFlags_AlwaysAutoResize | 
			ImGuiWindowFlags_NoBringToFrontOnFocus);
			
		if (ImGui::Button("ESC", vecButSize)) {
			if(pScoreBoard->getState())
				pScoreBoard->setActive(false);
		
			if(pDialog->IsShowing()) {
				pDialog->Show(false);
				pNetGame->SendDialogResponse(pDialog->getCurDialogID(), 0, -1, "123123");
			}
			
			CTextDrawPool *pTextDrawPool = pNetGame->GetTextDrawPool();
			if(pTextDrawPool) {
				RakNet::BitStream bsClick;
				bsClick.Write(INVALID_TEXT_DRAW);
				pNetGame->GetRakClient()->RPC(&RPC_ClickTextDraw, &bsClick, HIGH_PRIORITY, RELIABLE_ORDERED, 0, false, UNASSIGNED_NETWORK_ID, nullptr);
			}
		}
		
		ImGui::SameLine(0, 5);
		
		if (ImGui::Button(m_bOpen ? "<<" : ">>", vecButSize)) {
			if(m_bOpen) m_bOpen = false;
			else m_bOpen = true;
		}
		
		if(m_bOpen) {
			ImGui::SameLine(0, 5);
		
			if (ImGui::Button("ALT", vecButSize)) {
				if(pPlayerPed->IsInVehicle()) {
					LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = true;
				} else {
					LocalPlayerKeys.bKeys[ePadKeys::KEY_WALK] = true;
				}
			}
			ImGui::SameLine(0, 5);
			if (ImGui::Button("F", vecButSize)) LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = true;
			ImGui::SameLine(0, 5);
			if (ImGui::Button("H", vecButSize)) {
				if(pPlayerPed->IsInVehicle() || pPlayerPed->IsAPassenger()) {
					LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH] = true;
				} else {
					LocalPlayerKeys.bKeys[ePadKeys::KEY_CTRL_BACK] = true;
				}
			}
			ImGui::SameLine(0, 5);
			if (ImGui::Button("Y", vecButSize)) LocalPlayerKeys.bKeys[ePadKeys::KEY_YES] = true;
			ImGui::SameLine(0, 5);
			if (ImGui::Button("N", vecButSize)) LocalPlayerKeys.bKeys[ePadKeys::KEY_NO] = true;
		}
		ImGui::SetWindowPos(pSettings->Get().m_buttonPanelPos);
		ImGui::End();
	}
}
