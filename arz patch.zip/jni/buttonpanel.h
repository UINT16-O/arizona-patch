#pragma once

class ButtonPanel
{
	friend class UI;
public:
	ButtonPanel();
	void draw();
	
	void Show(bool bShow) { m_bOpen = bShow; }
	
private:
	bool m_bOpen;
};
