#include "main.h"
#include "gui/ui.h"
#include "chat.h"
#include "keyboard.h"
#include "settings.h"
#include "game/game.h"
#include "net/netgame.h"
#include "dialog.h"
#include "scoreboard.h"

#include <time.h>
#include <cstdarg>

extern UI *pUI;
extern CKeyBoard *pKeyBoard;
extern CSettings *pSettings;
extern CNetGame *pNetGame;
extern CDialog *pDialog;
extern CScoreBoard *pScoreBoard;

std::unordered_map<std::string, CMDPROC> m_mapCmds;

void chatKeyboardEvent(const char* str)
{
	if(!str || *str == '\0') return;
	if(!pNetGame) return;

	if(*str == '/')
	{
		char *szCmdEndPos = (char*)str + 1;
		while(*szCmdEndPos && *szCmdEndPos != ' ') szCmdEndPos++;
		if(*szCmdEndPos == '\0') {
			std::unordered_map<std::string, CMDPROC>::iterator cmd = m_mapCmds.find(str + 1);
			if(cmd != m_mapCmds.end())
			{
				cmd->second("");
			}
			else
			{
				if(pNetGame)
				{
					pNetGame->SendChatCommand(str);
				}
			}
		} else {
			char szCopiedBuffer[256];
			strcpy(szCopiedBuffer, str);

			*szCmdEndPos = '\0';
			szCmdEndPos++;

			std::unordered_map<std::string, CMDPROC>::iterator cmd = m_mapCmds.find(str + 1);
			if(cmd != m_mapCmds.end())
			{
				cmd->second(szCmdEndPos);
			}
			else
			{
				if(pNetGame)
				{
					pNetGame->SendChatCommand(szCopiedBuffer);
				}
			}
		}
	}
	else
		pNetGame->SendChatMessage(str);
	return;
}

CChat::CChat()
{
	m_fChatPosX = pUI->ScaleX( pSettings->Get().m_chatPos.x );
	m_fChatPosY = pUI->ScaleY( pSettings->Get().m_chatPos.y );
	m_fChatSizeX = pUI->ScaleX( pSettings->Get().m_chatSize.x );
	m_fChatSizeY = pUI->ScaleY( pSettings->Get().m_chatSize.y );
	m_iMaxMessages = pSettings->Get().m_chatMaxMessages;

	m_dwTextColor = 0xFFFFFFFF;
	m_dwInfoColor = 0x00C8C8FF;
	m_dwDebugColor = 0xBEBEBEFF;
}
	
bool CChat::onTouchEvent(int type, bool multi, int x, int y)
{
	static bool bWannaOpenChat = false;
	
	switch(type)
	{
		case TOUCH_PUSH:
			if(x >= m_fChatPosX && x <= m_fChatPosX + m_fChatSizeX &&
				y >= m_fChatPosY && y <= m_fChatPosY + m_fChatSizeY)
				bWannaOpenChat = true;
		break;

		case TOUCH_POP:
			if(bWannaOpenChat &&
				x >= m_fChatPosX && x <= m_fChatPosX + m_fChatSizeX &&
				y >= m_fChatPosY && y <= m_fChatPosY + m_fChatSizeY)
			{
				if(!pDialog->IsDialogList())
					pKeyBoard->Open(&chatKeyboardEvent);
			}
			bWannaOpenChat = false;
		break;

		case TOUCH_MOVE:
		break;
	}

	return true;
}

void CChat::Render()
{
	ImVec2 pos = ImVec2(m_fChatPosX, m_fChatPosY);

	for(auto entry : m_ChatWindowEntries)
	{
		switch(entry.eType)
		{
			case CHAT_TYPE_CHAT:
				if(entry.szNick[0] != 0)
				{
					RenderText(entry.szNick, pos.x, pos.y, entry.dwNickColor);
					pos.x += ImGui::CalcTextSize(entry.szNick).x + ImGui::CalcTextSize(" ").x; //+ pUI->GetFontSize() * 0.4;
				}
				RenderText(entry.utf8Message, pos.x, pos.y, entry.dwTextColor);
			break;

			case CHAT_TYPE_INFO:
			case CHAT_TYPE_DEBUG:
				RenderText(entry.utf8Message, pos.x, pos.y, entry.dwTextColor);
			break;
		}

		pos.x = m_fChatPosX;
		pos.y += pUI->GetFontSize();
	}
}

void CChat::RenderText(const char* u8Str, float posX, float posY, uint32_t dwColor)
{
	const char* textStart = u8Str;
	const char* textCur = u8Str;
	const char* textEnd = u8Str + strlen(u8Str);

	ImVec2 posCur = ImVec2(posX, posY);
	ImColor colorCur = ImColor(dwColor);
	ImVec4 col;

	while(*textCur)
	{
		// {BBCCDD}
		// '{' � '}' ������������� ASCII ���������
		if(textCur[0] == '{' && ((&textCur[7] < textEnd) && textCur[7] == '}'))
		{
			// ������� ����� �� �������� ������
			if(textCur != textStart)
			{
				// ������� �� �������� �������
				pUI->RenderText(pUI->GetFont(), posCur, colorCur, true, textStart, textCur, pUI->GetFontSize());

				// ����������� ����� ��������
				posCur.x += ImGui::CalcTextSize(textStart, textCur).x;
			}

			// �������� ����
			if(ImGuiRenderer::processInlineHexColor(textCur+1, textCur+7, col))
				colorCur = col;

			// ������� ��������
			textCur += 7;
			textStart = textCur + 1;
		}

		textCur++;
	}

	if(textCur != textStart)
		pUI->RenderText(pUI->GetFont(), posCur, colorCur, true, textStart, textCur, pUI->GetFontSize());

	return;
}

void CChat::AddChatMessage(char* szNick, uint32_t dwNickColor, char* szMessage)
{
	FilterInvalidChars(szMessage);
	AddToChatWindowBuffer(CHAT_TYPE_CHAT, szMessage, szNick, m_dwTextColor, dwNickColor);
}

void CChat::AddInfoMessage(char* szFormat, ...)
{
	char tmp_buf[512];
	memset(tmp_buf, 0, sizeof(tmp_buf));

	va_list args;
	va_start(args, szFormat);
	vsprintf(tmp_buf, szFormat, args);
	va_end(args);

	FilterInvalidChars(tmp_buf);
	AddToChatWindowBuffer(CHAT_TYPE_INFO, tmp_buf, nullptr, m_dwInfoColor, 0);
}

void CChat::AddDebugMessage(char *szFormat, ...)
{
	char tmp_buf[512];
	memset(tmp_buf, 0, sizeof(tmp_buf));

	va_list args;
	va_start(args, szFormat);
	vsprintf(tmp_buf, szFormat, args);
	va_end(args);

	FilterInvalidChars(tmp_buf);
	AddToChatWindowBuffer(CHAT_TYPE_DEBUG, tmp_buf, nullptr, m_dwDebugColor, 0);
}

void CChat::AddClientMessage(uint32_t dwColor, char* szStr)
{
	FilterInvalidChars(szStr);
	AddToChatWindowBuffer(CHAT_TYPE_INFO, szStr, nullptr, dwColor, 0);
}

void CChat::PushBack(CHAT_WINDOW_ENTRY &entry)
{
	if(m_ChatWindowEntries.size() >= m_iMaxMessages)
		m_ChatWindowEntries.pop_front();

	m_ChatWindowEntries.push_back(entry);
	return;
}

void CChat::AddToChatWindowBuffer(eChatMessageType type, char* szString, char* szNick, 
	uint32_t dwTextColor, uint32_t dwNickColor)
{
	int iBestLineLength = 0;
	CHAT_WINDOW_ENTRY entry;
	entry.eType = type;
	entry.dwNickColor = __builtin_bswap32(dwNickColor | 0x000000FF);
	entry.dwTextColor = __builtin_bswap32(dwTextColor | 0x000000FF);

	if(szNick)
	{
		strcpy(entry.szNick, szNick);
		strcat(entry.szNick, ":");
	}
	else 
		entry.szNick[0] = '\0';

	if(type == CHAT_TYPE_CHAT && strlen(szString) > MAX_LINE_LENGTH)
	{
		iBestLineLength = MAX_LINE_LENGTH;
		// ������� ������ ������ � �����
		while(szString[iBestLineLength] != ' ' && iBestLineLength)
			iBestLineLength--;

		// ���� ��������� ����� ������ 12 ��������
		if((MAX_LINE_LENGTH - iBestLineLength) > 12)
		{
			// ������� �� MAX_MESSAGE_LENGTH/2
			cp1251_to_utf8(entry.utf8Message, szString, MAX_LINE_LENGTH);
			PushBack(entry);

			// ������� ����� MAX_MESSAGE_LENGTH/2
			entry.szNick[0] = '\0';
			cp1251_to_utf8(entry.utf8Message, szString+MAX_LINE_LENGTH);
			PushBack(entry);
		}
		else
		{
			// ������� �� �������
			cp1251_to_utf8(entry.utf8Message, szString, iBestLineLength);
			PushBack(entry);

			// ������� ����� �������
			entry.szNick[0] = '\0';
			cp1251_to_utf8(entry.utf8Message, szString+(iBestLineLength+1));
			PushBack(entry);
		}
	}
	else
	{
		cp1251_to_utf8(entry.utf8Message, szString, MAX_MESSAGE_LENGTH);
		PushBack(entry);
	}
	return;
}

void CChat::FilterInvalidChars(char *szString)
{
	while(*szString)
	{
		if(*szString > 0 && *szString < ' ')
			*szString = ' ';

		szString++;
	}
}

void CChat::AddCmdProc(const char *cmdname, CMDPROC cmdproc)
{
	m_mapCmds.insert(std::make_pair(cmdname, cmdproc));
}

void CChat::DeleteCmdProc(const char *cmdname)
{
	std::unordered_map<std::string, CMDPROC>::iterator cmd = m_mapCmds.find(cmdname);
	if(cmd != m_mapCmds.end())
		m_mapCmds.erase(cmd);
}
