#pragma once

#define MAX_MESSAGE_LENGTH	144
#define MAX_LINE_LENGTH		MAX_MESSAGE_LENGTH / 2

typedef void(*CMDPROC)(const char *params);

enum eChatMessageType
{
	CHAT_TYPE_NONE = 0,
	CHAT_TYPE_CHAT,
	CHAT_TYPE_INFO,
	CHAT_TYPE_DEBUG
};

typedef struct
{
	eChatMessageType	eType;
	char 				utf8Message[MAX_MESSAGE_LENGTH * 3 + 1];
	char 				szNick[MAX_PLAYER_NAME + 1];
	uint32_t			dwTextColor;
	uint32_t 			dwNickColor;
} CHAT_WINDOW_ENTRY;

class CChat
{
	friend class UI;
public:
	CChat();
	~CChat();

	void AddChatMessage(char* szNick, uint32_t dwNickColor, char* szMessage);
	void AddInfoMessage(char* szFormat, ...);
	void AddDebugMessage(char* szFormat, ...);
	void AddClientMessage(uint32_t dwColor, char* szStr);
	
	void AddCmdProc(const char* cmdname, CMDPROC cmdproc);
	void DeleteCmdProc(const char *cmdname);
	
	bool onTouchEvent(int type, bool multi, int x, int y);

protected:
	void Render();
	
private:
	void FilterInvalidChars(char* szString);
	void AddToChatWindowBuffer(eChatMessageType eType, char* szString, char* szNick, 
		uint32_t dwTextColor, uint32_t dwNickColor);
		
	void RenderText(const char* u8Str, float posX, float posY, uint32_t dwColor);
	void PushBack(CHAT_WINDOW_ENTRY &entry);
	
private:
	float m_fChatPosX, m_fChatPosY;
	float m_fChatSizeX, m_fChatSizeY;
	int m_iMaxMessages;
	
	//std::vector
	std::list<CHAT_WINDOW_ENTRY> m_ChatWindowEntries;

	uint32_t m_dwTextColor;
	uint32_t m_dwInfoColor;
	uint32_t m_dwDebugColor;
	
	int m_iLastPosY;
	int m_iOffsetPosY;
	bool m_bSwipeScroll;
};