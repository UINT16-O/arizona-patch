#include "main.h"
#include "chat.h"
#include "game/game.h"
#include "net/netgame.h"

extern CNetGame *pNetGame;
extern CChat *pChat;

extern bool bShowDebugLabels;

void cmdQuit(const char *szCmd)
{
	if(pNetGame && pNetGame->GetGameState() == GAMESTATE_CONNECTED)
		pNetGame->GetRakClient()->Disconnect(0);
	
    std::terminate();
}

void cmdReconnect(const char *szCmd)
{
	pNetGame->ShutdownForGameModeRestart();
	pNetGame->SetGameState(GAMESTATE_WAIT_CONNECT);
}

void cmdDL(const char *szCmd)
{
	bShowDebugLabels = !bShowDebugLabels;
}

void cmdRcon(const char *szCmd)
{
	if (!szCmd) return;

	uint8_t bytePacketId = ID_RCON_COMMAND;
	RakNet::BitStream bsCommand;
	bsCommand.Write(bytePacketId);
	uint32_t dwCmdLen = (uint32_t)strlen(szCmd);
	bsCommand.Write(dwCmdLen);
	bsCommand.Write(szCmd, dwCmdLen);
	pNetGame->GetRakClient()->Send(&bsCommand, HIGH_PRIORITY, RELIABLE, 0);
}

void SetupCommands()
{
	pChat->AddCmdProc("rcon",cmdRcon);
    pChat->AddCmdProc("dl", cmdDL);
    pChat->AddCmdProc("q", cmdQuit);
    pChat->AddCmdProc("quit", cmdQuit);
    pChat->AddCmdProc("reconnect", cmdReconnect);
}