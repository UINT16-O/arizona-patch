#include "main.h"
#include "gui/ui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "playertags.h"
#include "dialog.h"
#include "scoreboard.h"
#include "settings.h"
#include "extButtonPanel.h"

extern CGame *pGame;
extern CNetGame *pNetGame;
extern CSettings *pSettings;
extern UI *pUI;

RwTexture *pPassenger = nullptr;

ExtButtonPanel::ExtButtonPanel()
{
	pPassenger = (RwTexture *)LoadTextureFromDB("mobile", "enterandexit");
}

void ExtButtonPanel::draw()
{
	if(pNetGame && pUI)
	{
		CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
				
		if(!pPlayerPed->IsInVehicle() && !pPlayerPed->IsAPassenger())
		{
			CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
			if(pVehiclePool)
			{
				uint16_t sNearestVehicleID = pVehiclePool->FindNearestToLocalPlayerPed();
				CVehicle *pVehicle = pVehiclePool->GetAt(sNearestVehicleID);
				if(pVehicle)
				{
					if(pVehicle->GetDistanceFromLocalPlayerPed() < 4.0f)
					{
						CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
						if(pPlayerPool)
						{
							CLocalPlayer *pLocalPlayer = pPlayerPool->GetLocalPlayer();
							if(pLocalPlayer)
							{
								if(!pLocalPlayer->IsSpectating())
								{
									ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.0f, 0.0f, 0.00f));
									ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.0f, 0.0f, 0.00f));
									ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 0.0f, 0.0f, 0.00f));
									
									ImGuiStyle style;
									style.FrameBorderSize = ImGui::GetStyle().FrameBorderSize;
									ImGui::GetStyle().FrameBorderSize = 0.0f;
		
									ImGui::Begin("###extButtonPanel", nullptr,
										ImGuiWindowFlags_NoTitleBar |
										ImGuiWindowFlags_NoResize |
										ImGuiWindowFlags_NoScrollbar |
										ImGuiWindowFlags_NoBackground |
										ImGuiWindowFlags_NoSavedSettings |
										ImGuiWindowFlags_AlwaysAutoResize | 
										ImGuiWindowFlags_NoBringToFrontOnFocus);
										
									if(ImGui::ImageButton((ImTextureID)pPassenger->raster, pSettings->Get().m_extButtonPanelSize))
									{
										pPlayerPed->EnterVehicle(pVehicle->m_dwGTAId, true);
										pLocalPlayer->SendEnterVehicleNotification(sNearestVehicleID, true);
									}
									
									ImGui::SetWindowPos(pSettings->Get().m_extButtonPanelPos);
									ImGui::End();
									ImGui::GetStyle().FrameBorderSize = style.FrameBorderSize;
									ImGui::PopStyleColor(3);
								}
							}
						}
					}
				}
			}
		}
	}
}