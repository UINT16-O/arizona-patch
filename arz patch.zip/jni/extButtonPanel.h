#pragma once

class ExtButtonPanel
{
	friend class UI;
public:
	ExtButtonPanel();
	void draw();
};