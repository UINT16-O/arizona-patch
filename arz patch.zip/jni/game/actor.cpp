#include "../main.h"
#include "game.h"
#include "net/netgame.h"

extern CGame *pGame;

CActor::CActor(int iSkin, float fX, float fY, float fZ, float fRotation)
{
	m_pPed = nullptr;
	m_dwGTAId = 0;
	uint32_t dwActorID = 0;
	
	if(!pGame->IsModelLoaded(iSkin))
	{
		pGame->RequestModel(iSkin);
		pGame->LoadRequestedModels();
		while(!pGame->IsModelLoaded(iSkin)) sleep(5);
	}

	ScriptCommand(&create_actor, 5, iSkin, fX, fY, fZ+0.5f, &dwActorID);
	ScriptCommand(&set_actor_z_angle, dwActorID, fRotation);

	m_dwGTAId = dwActorID;
	m_pPed = GamePool_Ped_GetAt(m_dwGTAId);
	m_pEntity = (ENTITY_TYPE *)m_pPed;
	
	ScriptCommand(&set_actor_immunities, m_dwGTAId, 0, 0, 1, 0, 0);
	ScriptCommand(&set_actor_dicision, m_dwGTAId, 65542);
	return;
}

CActor::~CActor()
{
	if(!m_pPed || !GamePool_Ped_GetAt(m_dwGTAId) || m_pPed->entity.vtable == 0x5C7358)
	{
		m_pPed = nullptr;
		m_pEntity = nullptr;
		m_dwGTAId = 0;
		return;
	}
	
	// CPlayerPed::Destructor
	(( void (*)(PED_TYPE*))(*(void**)(m_pPed->entity.vtable+0x4)))(m_pPed);

	m_pPed = nullptr;
	m_pEntity = nullptr;
	return;
}

void CActor::SetHealth(float fHealth)
{
	if(!m_pPed) return;
	m_pPed->fHealth = fHealth;
	return;
}

void CActor::SetInvulnerable(bool bInv)
{
	if(!m_pPed) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

	if(bInv) 
	{
		ScriptCommand(&set_actor_immunities, m_dwGTAId, 1, 1, 1, 1, 1);
		m_bIsInvulnerable = true;
	}
	else 
	{ 
		ScriptCommand(&set_actor_immunities, m_dwGTAId, 0, 0, 0, 0, 0);
		m_bIsInvulnerable = false;
	}
}

void CActor::SetFacingAngle(float fRotation)
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	m_pPed->fRotation2 = DegToRad(fRotation);
	return;
}

void CActor::ApplyAnimation(char *szAnimName, char *szAnimFile, float fDelta, int bLoop, int bLockX, int bLockY, int bFreeze, int uiTime)
{
	int iWaitAnimLoad = 0;

	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if(!strcasecmp(szAnimFile,"SEX")) return;

	if(!pGame->IsAnimationLoaded(szAnimFile))
	{
		pGame->RequestAnimation(szAnimFile);
		while(!pGame->IsAnimationLoaded(szAnimFile))
		{
			usleep(1000);
			iWaitAnimLoad++;
			if(iWaitAnimLoad > 15) return;
		}
	}
	ScriptCommand(&apply_animation, m_dwGTAId, szAnimName, szAnimFile, fDelta, bLoop, bLockX, bLockY, bFreeze, uiTime);
	return;
}

void CActor::ClearAnimation()
{
	if(!m_pPed) return;
	
	// CPedIntelligence::FlushImmediately
	uintptr_t dwPedPtr = (uintptr_t)m_pPed;
	(( void (*)(uintptr_t, int))(g_libGTASA+0x44E1BC+1))(*(uintptr_t*)(dwPedPtr+1088), 1);
	return;
}