#pragma once

class CActor : public CEntity
{
public:
	CActor(int iSkin, float fX, float fY, float fZ, float fRotation);
	~CActor();

	void SetHealth(float fHealth);
	void SetInvulnerable(bool bInv);
	void SetFacingAngle(float fRotation);
	void ApplyAnimation(char *szAnimName, char *szAnimFile, float fDelta, int bLoop, int bLockX, int bLockY, int bFreeze, int uiTime);
	void ClearAnimation();
	
public:
	PED_TYPE *m_pPed;
	bool m_bIsInvulnerable;
};