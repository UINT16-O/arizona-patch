#pragma once

class CEntity
{
public:
	CEntity() {};
	virtual ~CEntity() {};
	virtual void Add();
	virtual void Remove();
	
	void Render();

	void GetMatrix(PMATRIX4X4 matEntity);
	void SetMatrix(MATRIX4X4 matEntity);	
 
	void GetMoveSpeedVector(PVECTOR vecSpeed);
	void SetMoveSpeedVector(VECTOR vecSpeed);

	void GetTurnSpeedVector(PVECTOR vecSpeed);
	void SetTurnSpeedVector(VECTOR vecSpeed);
	
	void ApplyMoveSpeed();
	
	void UpdateRwMatrixAndFrame();
	void UpdateMatrix(MATRIX4X4 mat);

	uint16_t GetModelIndex();

	void TeleportTo(float fX, float fY, float fZ);

	bool SetModelIndex(unsigned int uiModel);

	bool IsAdded();
	
	uintptr_t GetRWObject();
	
	float GetDistanceFromCamera();
	float GetDistanceFromLocalPlayerPed();
	float GetDistanceFromPoint(float x, float y, float z);

	void SetCollisionChecking(bool bCheck);
	bool GetCollisionChecking();
	
	void SetGravityProcessing(bool bProcess);

public:
	ENTITY_TYPE		*m_pEntity;
	uint32_t		m_dwGTAId;
};