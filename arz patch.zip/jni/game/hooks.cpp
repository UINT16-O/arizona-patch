#include <android/log.h>

#include "../main.h"
#include "../util/armhook.h"
#include "RW/RenderWare.h"
#include "game.h"
#include "net/netgame.h"
#include "gui/ui.h"
#include "chat.h"
#include "settings.h"
#include "keyboard.h"
#include "scoreboard.h"
#include "chat.h"

extern UI *pUI;
extern CChat *pChat;
extern CGame *pGame;
extern CNetGame *pNetGame;
extern CSettings *pSettings;
extern CScoreBoard *pScoreBoard;
extern CKeyBoard *pKeyBoard;
extern CChat *pChat;

bool g_bPlaySAMP = false;
bool bIgnoreNextEntry = false;
bool g_bNeedClearMousePos = false;

// Lag Compensation Mode
extern int g_iLagCompensationMode;

int g_iNeedStorePlayerSkill;

uintptr_t dwCurPlayerActor = 0;
uint8_t byteCurPlayer = 0;
uint8_t byteInternalPlayer = 0;

uint8_t byteSavedCameraMode = 0;
uint16_t wSavedCameraMode2 = 0;
uint8_t byteSavedControlFlags = 0;

void InitGui();
void MainLoop();
void HookCPad();

extern "C" uintptr_t get_lib() 
{
 	return g_libGTASA;
}

struct stFile
{
	int isFileExist;
	FILE *f;
};

stFile* (*NvFOpen)(const char*, const char*, int, int);
stFile* NvFOpen_hook(const char* r0, const char* r1, int r2, int r3)
{
	char path[0xFF] = { 0 };

	if(!strncmp(r1+12, "mainV1.scm", 22))
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading mainV1.scm..");
		sprintf(path, "%sSAMP/main.scm", pGame->GetDataDirectory());
		goto open;
	}
	if(!strncmp(r1+12, "SCRIPTV1.IMG", 24))
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading scriptV1.img..");
		sprintf(path, "%sSAMP/script.img", pGame->GetDataDirectory());
		goto open;
	}
	if(!strncmp(r1, "DATA/GTA.DAT", 12))
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading gta.dat..");
		sprintf(path, "%sSAMP/gta.dat", pGame->GetDataDirectory());
		goto open;
	}
	if(!strncmp(r1, "DATA/PEDS.IDE", 13))
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading peds.ide..");
		sprintf(path, "%sSAMP/peds.ide", pGame->GetDataDirectory());
		goto open;
	}
	if(!strncmp(r1, "DATA/WEAPON.DAT", 13))
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading weapon.dat..");
		sprintf(path, "%sSAMP/weapon.dat", pGame->GetDataDirectory());
		goto open;
	}
	if(!strncmp(r1, "data/paths/tracks2.dat", 21))
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading tracks2.dat..");
		sprintf(path, "%sSAMP/tracks2.dat", pGame->GetDataDirectory());
		goto open;
	}
	else
	{
		if(!strncmp(r1, "data/paths/tracks4.dat", 21))
		{
			__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading tracks4.dat..");
			sprintf(path, "%sSAMP/tracks4.dat", pGame->GetDataDirectory());
			goto open;
		}
	}

orig:
	return NvFOpen(r0, r1, r2, r3);

open:
	stFile *st = (stFile*)malloc(8);
	st->isFileExist = false;

	FILE *f = fopen(path, "rb");
	if(f)
	{
		st->isFileExist = true;
		st->f = f;
		return st;
	}
	else
	{
		free(st);
		st = nullptr;
		return 0;
	}
}

int Init_hook(int r0, int r1, int r2)
{
	int result = (( int (*)(int, int, int))(g_libGTASA+0x244F2C+1))(r0, r1, r2);

	pSettings = new CSettings();

	return result;
}

bool bGameStarted = false;
void (*Render2dStuff)();
void Render2dStuff_hook()
{
	bGameStarted = true;
	Render2dStuff();
	MainLoop();
	return;
}

void (*Render2dStuffAfterFade)();
void Render2dStuffAfterFade_hook()
{
	Render2dStuffAfterFade();
	if(pUI && bGameStarted) pUI->Render();
	return;
}

uint16_t gxt_string[0x7F];
uint8_t byteRowIndex = -1, byteColumnIndex = -1;
uint16_t* (*CText_Get)(uintptr_t thiz, const char* text);
uint16_t* CText_Get_hook(uintptr_t thiz, const char* text)
{
	if(text[0] == 'S' && text[1] == 'A' && text[2] == 'M' && text[3] == 'P')
	{
		const char* code = &text[4];
		if (pNetGame && pNetGame->GetMenuPool())
		{
			CFont::AsciiToGxtChar(pNetGame->GetMenuPool()->GetTextPointer((char*)code), gxt_string);
		}
    	return gxt_string;
	}
	return CText_Get(thiz, text);
}

void (*CFont_PrintString)(float x, float y, uint16_t *gxtString);
void CFont_PrintString_hook(float x, float y, uint16_t *gxtString)
{
	if(pNetGame)
	{
		CMenuPool *pMenuPool = pNetGame->GetMenuPool();
		if(pMenuPool)
		{
			CMenu *pMenu = pMenuPool->GetCurrentMenu();
			if(pMenu)
			{
				if(byteRowIndex != INVALID_MENU && byteColumnIndex != -1)
				{
					CFont_PrintString(x, y, gxtString);
					
					RECT rect;
					// CFont::GetTextRect
					(( void (*)(RECT *, float, float, uint16_t *))(g_libGTASA+0x5352DC+1))(&rect, x, y, gxtString);
					
					float fHeight = (( float (*)(int))(g_libGTASA+0x5330F0+1))(0); // CFont::GetHeight
					float fWidth = (( float (*)(uint16_t *))(g_libGTASA+0x534BAC+1))(gxtString); // CFont::GetStringWidth
					
					rect.fBottom += fHeight / 4.0f;
					rect.fTop = rect.fBottom + fHeight - fHeight / 4.0f;
					rect.fRight = rect.fLeft + (fWidth * 2);
					
					pMenu->m_MenuItemRect[byteColumnIndex][byteRowIndex] = rect;
					byteRowIndex = INVALID_MENU;
					byteColumnIndex = -1;
				}
			}
		}
	}
	return CFont_PrintString(x, y, gxtString);
}

// CGame::InitialiseRenderWare
void (*CGame_InitialiseRenderWare)();
void CGame_InitialiseRenderWare_hook()
{
	CGame_InitialiseRenderWare();
	// TextureDatabaseRuntime::Load
	(( void (*)(const char*, int, int))(g_libGTASA+0x1BF244+1))("samp", 0, 5);
	InitGui();
	return;
}

void RenderSplashScreen();
void (*DisplayScreen)();
void DisplayScreen_hook()
{
	RwCamera* camera = *(RwCamera**)(g_libGTASA+0x95B064);

	if(RwCameraBeginUpdate(camera))
	{
		DefinedState2d();
		(( void (*)())(g_libGTASA+0x5519C8+1))(); // CSprite2d::InitPerFrame()
		RwRenderStateSet(rwRENDERSTATETEXTUREADDRESS, (void*)rwTEXTUREADDRESSCLAMP);
		(( void (*)(bool))(g_libGTASA+0x198010+1))(false); // emu_GammaSet()
		RenderSplashScreen();
		RwCameraEndUpdate(camera);
		RwCameraShowRaster(camera, 0, 0);
	}
	return;
}

void (*AND_TouchEvent)(int, int, int, int);
void AND_TouchEvent_hook(int type, int num, int x, int y)
{
	ImGuiIO& io = ImGui::GetIO();
	
	if(pGame->IsGamePaused())
		return AND_TouchEvent(type, num, x, y);
	
	if(type == TOUCH_POP)
	{
		io.MouseDown[0] = false;
		g_bNeedClearMousePos = true;
	}
	else if(type == TOUCH_MOVE)
	{
		io.MousePos = ImVec2(x, y);
	}
	else if(type == TOUCH_PUSH)
	{
		io.MousePos = ImVec2(x, y);
		io.MouseDown[0] = true;
	}
	
	if(pNetGame)
	{
		if(pKeyBoard && !pKeyBoard->onTouchEvent(type, num, x, y))
			return AND_TouchEvent(TOUCH_POP, 0, 0, 0);
		
		if(pChat && !pChat->onTouchEvent(type, num, x, y))
			return AND_TouchEvent(TOUCH_POP, 0, 0, 0);
		
		/* if(!CVoiceManager::onTouchEvent(type, num, x, y))
			return AND_TouchEvent(TOUCH_POP, 0, 0, 0); */
	}
	
	if(pUI && pUI->m_noPause)
		return AND_TouchEvent(TOUCH_POP, 0, 0, 0);
	
	if(pNetGame && !pNetGame->GetMenuPool()->onTouchEvent(type, num, x, y))
		return AND_TouchEvent(TOUCH_POP, 0, 0, 0);
	
	if(pNetGame && !pNetGame->GetTextDrawPool()->onTouchEvent(type, num, x, y))
		return AND_TouchEvent(TOUCH_POP, 0, 0, 0);
	
	return AND_TouchEvent(type, num, x, y);
}

void (*CStream_InitImageList)();
void CStream_InitImageList_hook()
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Initializing ImageList..");
	
	char* ms_files = (char*)(g_libGTASA+0x6702FC);
	ms_files[0] = 0;
	*(uint32_t*)&ms_files[44] = 0;
	ms_files[48] = 0;
	*(uint32_t*)&ms_files[92] = 0;
	ms_files[96] = 0;
	*(uint32_t*)&ms_files[140] = 0;
	ms_files[144] = 0;
	*(uint32_t*)&ms_files[188] = 0;
	ms_files[192] = 0;
	*(uint32_t*)&ms_files[236] = 0;
	ms_files[240] = 0;
	*(uint32_t*)&ms_files[284] = 0;
	ms_files[288] = 0;
	*(uint32_t*)&ms_files[332] = 0;
	ms_files[336] = 0;
	*(uint32_t*)&ms_files[380] = 0;

	(( uint32_t (*)(char*, uint32_t))(g_libGTASA+0x28E7B0+1))("TEXDB\\SAMPCOL.IMG", 1); // CStreaming::AddImageToList
	(( uint32_t (*)(char*, uint32_t))(g_libGTASA+0x28E7B0+1))("TEXDB\\GTA3.IMG", 1); // CStreaming::AddImageToList
	(( uint32_t (*)(char*, uint32_t))(g_libGTASA+0x28E7B0+1))("TEXDB\\GTA_INT.IMG", 1); // CStreaming::AddImageToList
	(( uint32_t (*)(char*, uint32_t))(g_libGTASA+0x28E7B0+1))("TEXDB\\SAMP.IMG", 1); // CStreaming::AddImageToList
}

PED_MODEL PedsModels[315];
int PedsModelsCount = 0;

PED_MODEL* (*CModelInfo_AddPedModel)(int id);
PED_MODEL* CModelInfo_AddPedModel_hook(int id)
{
	PED_MODEL* model = &PedsModels[PedsModelsCount];
	memset(model, 0, sizeof(PED_MODEL));
    model->vtable = (uintptr_t)(g_libGTASA+0x5C6E90);

    // CClumpModelInfo::CClumpModelInit()
    (( uintptr_t (*)(PED_MODEL*))(*(void**)(model->vtable+0x1C)))(model);

    *(PED_MODEL**)(g_libGTASA+0x87BF48+(id*4)) = model; // CModelInfo::ms_modelInfoPtrs

	PedsModelsCount++;
	return model;
}

extern ATOMIC_MODEL *ATOMIC_MODELS;

ATOMIC_MODEL* (*CModelInfo_AddAtomicModel)(int id);
ATOMIC_MODEL* CModelInfo_AddAtomicModel_hook(int id)
{
	int iCount = *(int*)(g_libGTASA+0x7802C4);
	ATOMIC_MODEL *model = &ATOMIC_MODELS[iCount];
	*(int*)(g_libGTASA+0x7802C4) = iCount+1;

    // CClumpModelInfo::CClumpModelInit()
    (( uintptr_t (*)(ATOMIC_MODEL*))(*(void**)(model->vtable+0x1C)))(model);
	
	// CModelInfo::ms_modelInfoPtrs
	ATOMIC_MODEL **ms_modelInfoPtrs = (ATOMIC_MODEL**)(g_libGTASA + 0x87BF48);
	ms_modelInfoPtrs[id] = model;
	return model;
}

uint32_t (*CRadar__GetRadarTraceColor)(uint32_t color, uint8_t bright, uint8_t friendly);
uint32_t CRadar__GetRadarTraceColor_hook(uint32_t color, uint8_t bright, uint8_t friendly)
{
	return TranslateColorCodeToRGBA(color);
}

int (*CRadar__SetCoordBlip)(int r0, float X, float Y, float Z, int r4, int r5, char* name);
int CRadar__SetCoordBlip_hook(int r0, float X, float Y, float Z, int r4, int r5, char* name)
{
	if(pNetGame && !strncmp(name, "CODEWAY", 7))
	{
		float findZ = (( float (*)(float, float))(g_libGTASA+0x3C3DD8+1))(X, Y);
		findZ += 1.5f;

		RakNet::BitStream bsSend;
		bsSend.Write(X);
		bsSend.Write(Y);
		bsSend.Write(findZ);
		pNetGame->GetRakClient()->RPC(&RPC_MapMarker, &bsSend, HIGH_PRIORITY, RELIABLE, 0, false, UNASSIGNED_NETWORK_ID, nullptr);
	}

	return CRadar__SetCoordBlip(r0, X, Y, Z, r4, r5, name);
}

uint8_t bGZ = 0;
void (*CRadar__DrawRadarGangOverlay)(uint8_t v1);
void CRadar__DrawRadarGangOverlay_hook(uint8_t v1)
{
	bGZ = v1;
	if (pNetGame && pNetGame->GetGangZonePool()) 
		pNetGame->GetGangZonePool()->Draw();
}

uint32_t dwParam1, dwParam2;
extern "C" void pickup_ololo()
{
	if(pNetGame && pNetGame->GetPickupPool())
	{
		CPickupPool *pPickups = pNetGame->GetPickupPool();
		pPickups->PickedUp( ((dwParam1-(g_libGTASA+0x70E264))/0x20) );
	}
}

__attribute__((naked)) void PickupPickUp_hook()
{
	// calculate and save ret address
	__asm__ volatile("push {lr}\n\t"
					"push {r0}\n\t"
					"blx get_lib\n\t"
					"add r0, #0x2D0000\n\t"
					"add r0, #0x009A00\n\t"
					"add r0, #1\n\t"
					"mov r1, r0\n\t"
					"pop {r0}\n\t"
					"pop {lr}\n\t"
					"push {r1}\n\t");
	
	// 
	__asm__ volatile("push {r0-r11, lr}\n\t"
					"mov %0, r4" : "=r" (dwParam1));

	__asm__ volatile("blx pickup_ololo\n\t");


	__asm__ volatile("pop {r0-r11, lr}\n\t");

	// restore
	__asm__ volatile("ldrb r1, [r4, #0x1C]\n\t"
					"sub.w r2, r1, #0xD\n\t"
					"sub.w r2, r1, #8\n\t"
					"cmp r1, #6\n\t"
					"pop {pc}\n\t");
}

extern "C" bool NotifyEnterVehicle(VEHICLE_TYPE *_pVehicle)
{
    if(!pNetGame) return false;
 
    CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
    CVehicle *pVehicle;
    VEHICLEID VehicleID = pVehiclePool->FindIDFromGtaPtr(_pVehicle);
 
    if(VehicleID == INVALID_VEHICLE_ID) return false;
    if(!pVehiclePool->GetSlotState(VehicleID)) return false;
    pVehicle = pVehiclePool->GetAt(VehicleID);
    if(pVehicle->m_bDoorsLocked) return false;
    if(pVehicle->m_pVehicle->entity.nModelIndex == TRAIN_PASSENGER) return false;
 
    if(pVehicle->m_pVehicle->pDriver &&
        pVehicle->m_pVehicle->pDriver->dwPedType != 0)
        return false;
 
    CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
 
    if(pLocalPlayer->GetPlayerPed() && pLocalPlayer->GetPlayerPed()->GetCurrentWeapon() == WEAPON_PARACHUTE)
     pLocalPlayer->GetPlayerPed()->SetArmedWeapon(0);
 
    pLocalPlayer->SendEnterVehicleNotification(VehicleID, false);
 
    return true;
}

void (*TaskEnterVehicle)(uint32_t thiz, uint32_t pVehicle);
extern "C" void call_TaskEnterVehicle(uintptr_t a, uint32_t b)
{
	TaskEnterVehicle(a, b);
}
void __attribute__((naked)) TaskEnterVehicle_hook(uint32_t thiz, uint32_t pVehicle)
{
    __asm__ volatile("push {r0-r11, lr}\n\t"
                    "mov r2, lr\n\t"
                    "blx get_lib\n\t"
                    "add r0, #0x3A0000\n\t"
                    "add r0, #0xEE00\n\t"
                    "add r0, #0xF7\n\t"
                    "cmp r2, r0\n\t"
                    "bne 1f\n\t" // !=
                    "mov r0, r1\n\t"
                    "blx NotifyEnterVehicle\n\t" // call NotifyEnterVehicle
                    "1:\n\t"  // call orig
                    "pop {r0-r11, lr}\n\t"
    				"push {r0-r11, lr}\n\t"
    				"blx call_TaskEnterVehicle\n\t"
    				"pop {r0-r11, pc}");
}

 void (*CTaskComplexLeaveCar)(uintptr_t** thiz, VEHICLE_TYPE *pVehicle, int iTargetDoor, int iDelayTime, bool bSensibleLeaveCar, bool bForceGetOut);
 void CTaskComplexLeaveCar_hook(uintptr_t** thiz, VEHICLE_TYPE *pVehicle, int iTargetDoor, int iDelayTime, bool bSensibleLeaveCar, bool bForceGetOut) 
 {
 	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;
 
 	if (dwRetAddr == 0x3AE905 || dwRetAddr == 0x3AE9CF) 
 	{
 		if (pNetGame) 
 		{
 			if (GamePool_FindPlayerPed()->pVehicle == (uint32_t)pVehicle) 
 			{
 				CVehiclePool *pVehiclePool=pNetGame->GetVehiclePool();
 				VEHICLEID VehicleID=pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE *)GamePool_FindPlayerPed()->pVehicle);
 				CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
 				pLocalPlayer->SendExitVehicleNotification(VehicleID);
 			}
 		}
 	}
 
 	(*CTaskComplexLeaveCar)(thiz, pVehicle, iTargetDoor, iDelayTime, bSensibleLeaveCar, bForceGetOut);
 }

void (*CPools_Initialise)(void);
void CPools_Initialise_hook(void)
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "GTA pools initializing..");
	struct PoolAllocator
	{
		struct Pool
		{
			void *objects;
			uint8_t *flags;
			uint32_t count;
			uint32_t top;
			uint32_t bInitialized;
		};
		static_assert(sizeof(Pool) == 0x14);

		static Pool* Allocate(size_t count, size_t size)
		{
			Pool *p = new Pool;

			p->objects = new char[size*count];
			p->flags = new uint8_t[count];
			p->count = count;
			p->top = 0xFFFFFFFF;
			p->bInitialized = 1;

			for (size_t i = 0; i < count; i++)
			{
				p->flags[i] |= 0x80;
				p->flags[i] &= 0x80;
			}
			return p;
		}
	};
	
	// 600000 / 75000 = 8
	static auto ms_pPtrNodeSingleLinkPool	= PoolAllocator::Allocate(100000,	8);		// 75000
	// 72000 / 6000 = 12
	static auto ms_pPtrNodeDoubleLinkPool	= PoolAllocator::Allocate(20000,	12);	// 6000
	// 10000 / 500 = 20
	static auto ms_pEntryInfoNodePool		= PoolAllocator::Allocate(20000,	20);	// 500
	// 279440 / 140 = 1996
	static auto ms_pPedPool					= PoolAllocator::Allocate(240,		1996);	// 140
	// 286440 / 110 = 2604
	static auto ms_pVehiclePool				= PoolAllocator::Allocate(2000,		2604);	// 110
	// 840000 / 14000 = 60
	static auto ms_pBuildingPool			= PoolAllocator::Allocate(20000,	60);	// 14000
	// 147000 / 350 = 420
	static auto ms_pObjectPool				= PoolAllocator::Allocate(3000,		420);	// 350
	// 210000 / 3500 = 60
	static auto ms_pDummyPool				= PoolAllocator::Allocate(40000,	60);	// 3500
	// 487200 / 10150 = 48
	static auto ms_pColModelPool			= PoolAllocator::Allocate(50000,	48);	// 10150
	// 64000 / 500 = 128
	static auto ms_pTaskPool				= PoolAllocator::Allocate(5000,		128);	// 500
	// 13600 / 200 = 68
	static auto ms_pEventPool				= PoolAllocator::Allocate(1000,		68);	// 200
	// 6400 / 64 = 100
	static auto ms_pPointRoutePool			= PoolAllocator::Allocate(200,		100);	// 64
	// 13440 / 32 = 420
	static auto ms_pPatrolRoutePool			= PoolAllocator::Allocate(200,		420);	// 32
	// 2304 / 64 = 36
	static auto ms_pNodeRoutePool			= PoolAllocator::Allocate(200,		36);	// 64
	// 512 / 16 = 32
	static auto ms_pTaskAllocatorPool		= PoolAllocator::Allocate(3000,		32);	// 16
	// 92960 / 140 = 664
	static auto ms_pPedIntelligencePool		= PoolAllocator::Allocate(240,		664);	// 140
	// 15104 / 64 = 236
	static auto ms_pPedAttractorPool		= PoolAllocator::Allocate(200,		236);	// 64

	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93E0) = ms_pPtrNodeSingleLinkPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93DC) = ms_pPtrNodeDoubleLinkPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93D8) = ms_pEntryInfoNodePool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93D4) = ms_pPedPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93D0) = ms_pVehiclePool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93CC) = ms_pBuildingPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93C8) = ms_pObjectPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93C4) = ms_pDummyPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93C0) = ms_pColModelPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93BC) = ms_pTaskPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93B8) = ms_pEventPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93B4) = ms_pPointRoutePool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93B0) = ms_pPatrolRoutePool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93AC) = ms_pNodeRoutePool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93A8) = ms_pTaskAllocatorPool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93A4) = ms_pPedIntelligencePool;
	*(PoolAllocator::Pool**)(g_libGTASA + 0x8B93A0) = ms_pPedAttractorPool;
}

void (*CWorld_ProcessPedsAfterPreRender)();
void CWorld_ProcessPedsAfterPreRender_hook()
{
	CWorld_ProcessPedsAfterPreRender();
	if(pNetGame)
	{
		CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
		if(pPlayerPool)
		{
			pPlayerPool->ProcessAttachedObjects();
		}
	}
}

void (*CGame_Process)();
void CGame_Process_hook()
{
	CGame_Process();
	if(pNetGame)
	{
		if(pNetGame->GetObjectPool()) pNetGame->GetObjectPool()->Process();
		
		CTextDrawPool* pTextDrawPool = pNetGame->GetTextDrawPool();
		if(pTextDrawPool) pTextDrawPool->SnapshotProcess();
		
		CObjectPool *pObjectPool = pNetGame->GetObjectPool();
		if(pObjectPool)
			pObjectPool->ProcessMaterialText();
	}
}

uint32_t (*CWeapon_FireInstantHit)(WEAPON_SLOT_TYPE* _this, PED_TYPE* pFiringEntity, VECTOR* vecOrigin, VECTOR* muzzlePos, ENTITY_TYPE* targetEntity, VECTOR *target, VECTOR* originForDriveBy, int arg6, int muzzle);
uint32_t CWeapon_FireInstantHit_hook(WEAPON_SLOT_TYPE* _this, PED_TYPE* pFiringEntity, VECTOR* vecOrigin, VECTOR* muzzlePos, ENTITY_TYPE* targetEntity, VECTOR *target, VECTOR* originForDriveBy, int arg6, int muzzle)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));

 	dwRetAddr -= g_libGTASA;
 	if(	dwRetAddr == 0x569A84 + 1 ||
 		dwRetAddr == 0x569616 + 1 ||
 		dwRetAddr == 0x56978A + 1 ||
 		dwRetAddr == 0x569C06 + 1)
 	{
		PED_TYPE *pLocalPed = pGame->FindPlayerPed()->GetGtaActor();
		if(pLocalPed)
		{
			if(pFiringEntity != pLocalPed)
				return muzzle;

			if(pNetGame)
			{
				CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
				if(pPlayerPool)
				{
					pPlayerPool->ApplyCollisionChecking();
				}
			}

			if(pGame)
			{
				CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
				if(pPlayerPed)
				{
					pPlayerPed->FireInstant();
				}
			}

			if(pNetGame)
			{
				CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
				if(pPlayerPool)
				{
					pPlayerPool->ResetCollisionChecking();
				}
			}

			return muzzle;
		}
 	}

 	return CWeapon_FireInstantHit(_this, pFiringEntity, vecOrigin, muzzlePos, targetEntity, target, originForDriveBy, arg6, muzzle);
}

uint32_t (*CWeapon_FireSniper)(WEAPON_SLOT_TYPE* _this, PED_TYPE* pFiringEntity);
uint32_t CWeapon_FireSniper_hook(WEAPON_SLOT_TYPE* _this, PED_TYPE* pFiringEntity)
{
	if(GamePool_FindPlayerPed() == pFiringEntity)
	{
		if(pGame)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed) pPlayerPed->FireInstant();
		}
	}
	return 1;
}

extern CPlayerPed *g_pCurrentFiredPed;
extern BULLET_DATA *g_pCurrentBulletData;

void SendBulletSync(VECTOR *vecOrigin, VECTOR *vecEnd, VECTOR *vecPos, ENTITY_TYPE **ppEntity)
{
	static BULLET_DATA bulletData;
	memset(&bulletData, 0, sizeof(BULLET_DATA));

	bulletData.vecOrigin.X = vecOrigin->X;
  	bulletData.vecOrigin.Y = vecOrigin->Y;
  	bulletData.vecOrigin.Z = vecOrigin->Z;
  	bulletData.vecPos.X = vecPos->X;
  	bulletData.vecPos.Y = vecPos->Y;
  	bulletData.vecPos.Z = vecPos->Z;

  	if(ppEntity)
	{
  		static ENTITY_TYPE *pEntity;
  		pEntity = *ppEntity;
  		if(pEntity)
		{
  			if(pEntity->mat)
			{
  				if(g_iLagCompensationMode)
				{
  					bulletData.vecOffset.X = vecPos->X - pEntity->mat->pos.X;
		  			bulletData.vecOffset.Y = vecPos->Y - pEntity->mat->pos.Y;
		  			bulletData.vecOffset.Z = vecPos->Z - pEntity->mat->pos.Z;
  				}
				else
				{
  					static MATRIX4X4 mat1;
  					memset(&mat1, 0, sizeof(mat1));

  					static MATRIX4X4 mat2;
		  			memset(&mat2, 0, sizeof(mat2));

		  			RwMatrixOrthoNormalize(&mat2, pEntity->mat);
		  			RwMatrixInvert(&mat1, &mat2);
		  			ProjectMatrix(&bulletData.vecOffset, &mat1, vecPos);
  				}
  			}

  			bulletData.pEntity = pEntity;
  		}
  	}

  	pGame->FindPlayerPed()->ProcessBulletData(&bulletData);
}

uint32_t (*CWorld__ProcessLineOfSight)(VECTOR*,VECTOR*, VECTOR*, PED_TYPE**, bool, bool, bool, bool, bool, bool, bool, bool);
uint32_t CWorld__ProcessLineOfSight_hook(VECTOR* vecOrigin, VECTOR* vecEnd, VECTOR* vecPos, PED_TYPE** ppEntity, 
	bool b1, bool b2, bool b3, bool b4, bool b5, bool b6, bool b7, bool b8)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));

 	dwRetAddr -= g_libGTASA;
 	if(	dwRetAddr == 0x55E2FE + 1 || 
 		dwRetAddr == 0x5681BA + 1 ||  
 		dwRetAddr == 0x567AFC + 1)	
 	{
 		ENTITY_TYPE *pEntity = nullptr;
 		MATRIX4X4 *pMatrix = nullptr;
 		static VECTOR vecPosPlusOffset;

 		if(g_iLagCompensationMode != 2)
		{
 			if(g_pCurrentFiredPed != pGame->FindPlayerPed())
			{
 				if(g_pCurrentBulletData)
				{
					if(g_pCurrentBulletData->pEntity)
					{
						if(!pEntity->vtable != g_libGTASA+0x5C7358)
						{
							pMatrix = g_pCurrentBulletData->pEntity->mat;
							if(pMatrix)
							{
								if(g_iLagCompensationMode)
								{
									vecPosPlusOffset.X = pMatrix->pos.X + g_pCurrentBulletData->vecOffset.X;
									vecPosPlusOffset.Y = pMatrix->pos.Y + g_pCurrentBulletData->vecOffset.Y;
									vecPosPlusOffset.Z = pMatrix->pos.Z + g_pCurrentBulletData->vecOffset.Z;
								}
								else
								{
									ProjectMatrix(&vecPosPlusOffset, pMatrix, &g_pCurrentBulletData->vecOffset);
								}

								vecEnd->X = vecPosPlusOffset.X - vecOrigin->X + vecPosPlusOffset.X;
								vecEnd->Y = vecPosPlusOffset.Y - vecOrigin->Y + vecPosPlusOffset.Y;
								vecEnd->Z = vecPosPlusOffset.Z - vecOrigin->Z + vecPosPlusOffset.Z;
							}
						}
					}
 				}
 			}
 		}

 		static uint32_t result = 0;
 		result = CWorld__ProcessLineOfSight(vecOrigin, vecEnd, vecPos, ppEntity, b1, b2, b3, b4, b5, b6, b7, b8);

 		if(g_iLagCompensationMode == 2)
		{
 			if(g_pCurrentFiredPed)
			{
 				if(g_pCurrentFiredPed == pGame->FindPlayerPed())
				{
 					SendBulletSync(vecOrigin, vecEnd, vecPos, (ENTITY_TYPE**)ppEntity);
				}
 			}

 			return result;
 		}

 		if(g_pCurrentFiredPed)
		{
 			if(g_pCurrentFiredPed != pGame->FindPlayerPed())
			{
 				if(g_pCurrentBulletData)
				{
 					if(!g_pCurrentBulletData->pEntity)
					{
 						PED_TYPE *pLocalPed = pGame->FindPlayerPed()->GetGtaActor();
 						if(*ppEntity == pLocalPed || (IN_VEHICLE(pLocalPed) &&  *(uintptr_t*)ppEntity == pLocalPed->pVehicle))
						{
 							*ppEntity = nullptr;
 							vecPos->X = 0.0f;
 							vecPos->Y = 0.0f;
 							vecPos->Z = 0.0f;
 							return 0;
 						}
 					}
 				}
 			}
 		}

 		if(g_pCurrentFiredPed)
		{
 			if(g_pCurrentFiredPed == pGame->FindPlayerPed())
			{
 				SendBulletSync(vecOrigin, vecEnd, vecPos, (ENTITY_TYPE **)ppEntity);
			}
 		}

 		return result;
 	}

	return CWorld__ProcessLineOfSight(vecOrigin, vecEnd, vecPos, ppEntity, b1, b2, b3, b4, b5, b6, b7, b8);
}

extern int iBuildingToRemoveCount;
extern std::list<stRemoveBuilding> RemoveBuildingData;

void (*CEntity_Render)(ENTITY_TYPE* pEntity);
void CEntity_Render_hook(ENTITY_TYPE* pEntity)
{
	if(iBuildingToRemoveCount >= 1)
	{
		if(pEntity && pEntity->vtable != g_libGTASA+0x5C7358 && pEntity->mat)
		{
			for (auto &entry : RemoveBuildingData)
			{
				float fDistance = GetDistance(&entry.vecPos, &pEntity->mat->pos);
				if(fDistance <= entry.fRadius)
				{
					if(pEntity->nModelIndex == entry.wModel)
					{
						pEntity->dwProcessingFlags &= 0xFFFFFFFE;
						return;
					}
				}
			}
		}
	}
	return CEntity_Render(pEntity);
}

int32_t (*CObject_Render)(ENTITY_TYPE *object);
int32_t CObject_Render_hook(ENTITY_TYPE *object)
{
	if(object && pNetGame)
	{
		if(object->vtable != g_libGTASA+0x5C7358)
		{
			if(object->pdwRenderWare)
			{
				CObject* pObject = pNetGame->GetObjectPool()->GetObjectFromGtaPtr(object);
				if(pObject)
				{
					uintptr_t rwObject = pObject->GetRWObject();
					if(pObject->m_bHasMaterial && rwObject)
					{
						(( void (*)(uintptr_t, uintptr_t (*)(uintptr_t, uintptr_t*), uintptr_t*))(g_libGTASA+0x1AEE2C+1))(*(uintptr_t*)(rwObject + 4), AtomicCallback, pObject->m_MaterialTexture); // RwFrameForAllObjects
						
						// DeActivateDirectional
						(( void (*)())(g_libGTASA+0x559EF8+1))();
						int32_t retnValue = CObject_Render(object);
						// ActivateDirectional
						(( void (*)())(g_libGTASA+0x559F14+1))();
						return retnValue;
					}
				}
			}
		}
	}
	return CObject_Render(object);
}

void (*CPlaceable_InitMatrixArray)();
void CPlaceable_InitMatrixArray_hook()
{
	return (( void (*)(uintptr_t, signed int))(g_libGTASA+0x3AB2D8+1))(g_libGTASA+0x8B90A8, 10000);
}

int (*CCustomRoadsignMgr__RenderRoadsignAtomic)(uintptr_t thiz, float a2);
int CCustomRoadsignMgr__RenderRoadsignAtomic_hook(uintptr_t thiz, float a2)
{
	if(!thiz) return 0;
	return CCustomRoadsignMgr__RenderRoadsignAtomic(thiz, a2);
}

int (*MainMenuScreen_Update)(uintptr_t thiz, float a2);
int MainMenuScreen_Update_hook(uintptr_t thiz, float a2)
{
	if (!g_bPlaySAMP)
	{
		pGame->StartGame();
		
		g_bPlaySAMP = true;
		return 0;
	}
	return MainMenuScreen_Update(thiz, a2);
}

void (*StartGameScreen_OnNewGameCheck)();
void StartGameScreen_OnNewGameCheck_hook()
{
	if(g_bPlaySAMP)
	{
		// MainMenuScreen::OnResume() 
		(( void (*)())(g_libGTASA+0x261CBC+1))();
		return;
	}
	StartGameScreen_OnNewGameCheck();
}

void (*StartGameScreen_OnLoadGame)();
void StartGameScreen_OnLoadGame_hook()
{
	if(g_bPlaySAMP)
	{
		// MainMenuScreen::OnResume() 
		(( void (*)())(g_libGTASA+0x261CBC+1))();
		return;
	}
	StartGameScreen_OnLoadGame();
}

void (*CPed__ProcessControl)(uintptr_t thiz);
void CPed__ProcessControl_hook(uintptr_t thiz)
{
	dwCurPlayerActor = thiz;
	byteCurPlayer = FindPlayerNumFromPedPtr(dwCurPlayerActor);
	byteInternalPlayer = *pbyteCurrentPlayer;
	
	if(dwCurPlayerActor && (byteCurPlayer != 0) && 
		byteInternalPlayer == 0)
	{
		// REMOTE PLAYER
		
		// save the internal cammode, apply the context.
		byteSavedCameraMode = *pbyteCameraMode;
		*pbyteCameraMode = GameGetPlayerCameraMode(byteCurPlayer);
		
		// save the second internal cammode, apply the context
		wSavedCameraMode2 = *wCameraMode2;
		*wCameraMode2 = GameGetPlayerCameraMode(byteCurPlayer);
		if(*wCameraMode2 == 4) *wCameraMode2 = 0;

		// save the camera zoom factor, apply the context
		GameStoreLocalPlayerCameraExtZoomAndAspect();
		GameSetRemotePlayerCameraExtZoomAndAspect(byteCurPlayer);
		
		// aim & skills switching
		GameStoreLocalPlayerAim();
		GameSetRemotePlayerAim(byteCurPlayer);
		GameStoreLocalPlayerSkills();
		GameSetRemotePlayerSkills(byteCurPlayer);
		
		// *pbyteCurrentPlayer = byteCurPlayer;

		// CPed::UpdatePosition nulled from CPed::ProcessControl
		ARMHook::makeNOP(g_libGTASA+0x439B7A, 2);

		// call original
		CPed__ProcessControl(thiz);
		
		// restore
		ARMHook::writeMemory(g_libGTASA+0x439B7A, (uintptr_t)"\xFA\xF7\x1D\xF8", 4);
		
		// restore the skills
		GameSetLocalPlayerSkills();
		
		// restore the camera modes.
		*pbyteCameraMode = byteSavedCameraMode;
		*wCameraMode2 = wSavedCameraMode2;
		
		// remote the local player's camera zoom factor
		GameSetLocalPlayerCameraExtZoomAndAspect();
		
		*pbyteCurrentPlayer = 0;
		
		// restore the local player's keys and the internal ID.
		GameSetLocalPlayerAim();
	}
	else
	{
		// LOCAL PLAYER

		// Apply the original code to set ped rot from Cam
		ARMHook::writeMemory(g_libGTASA+0x4BED92, (uintptr_t)"\x10\x60", 2);

		(*CPed__ProcessControl)(thiz);

		// Reapply the no ped rots from Cam patch
		ARMHook::writeMemory(g_libGTASA+0x4BED92, (uintptr_t)"\x00\x46", 2);
	}

	return;
}

void AllVehicles__ProcessControl_hook(uintptr_t thiz)
{
	VEHICLE_TYPE *pVehicle = (VEHICLE_TYPE*)thiz;
	uintptr_t this_vtable = pVehicle->entity.vtable;
	this_vtable -= g_libGTASA;

	uintptr_t call_addr = 0;

	switch(this_vtable)
	{
		// CAutomobile
		case 0x5CC9F0:
		call_addr = 0x4E314C;
		break;

		// CBoat
		case 0x5CCD48:
		call_addr = 0x4F7408;
		break;

		// CBike
		case 0x5CCB18:
		call_addr = 0x4EE790;
		break;

		// CPlane
		case 0x5CD0B0:
		call_addr = 0x5031E8;
		break;

		// CHeli
		case 0x5CCE60:
		call_addr = 0x4FE62C;
		break;

		// CBmx
		case 0x5CCC30:
		call_addr = 0x4F3CE8;
		break;

		// CMonsterTruck
		case 0x5CCF88:
		call_addr = 0x500A34;
		break;

		// CQuadBike
		case 0x5CD1D8:
		call_addr = 0x505840;
		break;

		// CTrain
		case 0x5CD428:
		call_addr = 0x50AB24;
		break;
	}

	if(pVehicle && pVehicle->pDriver)
	{
		byteCurPlayer = FindPlayerNumFromPedPtr((uintptr_t)pVehicle->pDriver);
	}
	
	byteInternalPlayer = *pbyteCurrentPlayer;
	
	if(pVehicle->pDriver && pVehicle->pDriver->dwPedType == 0 &&
		pVehicle->pDriver != GamePool_FindPlayerPed() && 
		byteInternalPlayer == 0)
	{
		// save the internal cammode, apply the context.
		byteSavedCameraMode = *pbyteCameraMode;
		*pbyteCameraMode = GameGetPlayerCameraMode(byteCurPlayer);
		
		// save the second internal cammode, apply the context
		wSavedCameraMode2 = *wCameraMode2;
		*wCameraMode2 = GameGetPlayerCameraMode(byteCurPlayer);
		if(*wCameraMode2 == 4) *wCameraMode2 = 0;
		
		// aim switching
		GameStoreLocalPlayerAim();
		GameSetRemotePlayerAim(byteCurPlayer);
		
		*pbyteCurrentPlayer = 0;

		pVehicle->pDriver->dwPedType = 4;
		byteSavedControlFlags = pVehicle->entity.nControlFlags;
		pVehicle->entity.nControlFlags = 0x1A;
		
		// CAEVehicleAudioEntity::Service
		(( void (*)(uintptr_t))(g_libGTASA+0x364B64+1))(thiz+0x138);
		
		pVehicle->entity.nControlFlags = byteSavedControlFlags;
		pVehicle->pDriver->dwPedType = 0;
		
		*pbyteCurrentPlayer = byteCurPlayer;
		
		// VEHTYPE::ProcessControl()
		(( void (*)(VEHICLE_TYPE*))(g_libGTASA+call_addr+1))(pVehicle);
	
		*pbyteCurrentPlayer = 0;
		
		// restore the camera modes, internal id and local player's aim
		*pbyteCameraMode = byteSavedCameraMode;
		*wCameraMode2 = wSavedCameraMode2;
		
		// restore the local player's keys and the internal ID.
		GameSetLocalPlayerAim();
	}
	else
	{
		if(pVehicle->pDriver && pVehicle->pDriver->dwPedType == 0 && pVehicle->pDriver == GamePool_FindPlayerPed())
		{
			pVehicle->entity.nControlFlags |= 0x20;
			if(pVehicle->byteFlags & 0x10)
				pVehicle->entity.nControlFlags &= 0xDF;
		}
		
		// CAEVehicleAudioEntity::Service
		(( void (*)(uintptr_t))(g_libGTASA+0x364B64+1))(thiz+0x138);
		
		// VEHTYPE::ProcessControl()
		(( void (*)(VEHICLE_TYPE*))(g_libGTASA+call_addr+1))(pVehicle);
	}
}

void CTaskSimpleUseGun_SetPedPosition_hook(uintptr_t thiz, PED_TYPE *pPed)
{
	dwCurPlayerActor = (uintptr_t)pPed;
	byteCurPlayer = FindPlayerNumFromPedPtr((uintptr_t)pPed);
	byteInternalPlayer = *pbyteCurrentPlayer;
	
	if (dwCurPlayerActor && (byteCurPlayer != 0) && 
		byteInternalPlayer == 0) // not local player and local player's keys set.
	{
		// remote player
		
		// save the internal cammode, apply the context.
		byteSavedCameraMode = *pbyteCameraMode;
		*pbyteCameraMode = GameGetPlayerCameraMode(byteCurPlayer);
		
		// save the second internal cammode, apply the context
		wSavedCameraMode2 = *wCameraMode2;
		*wCameraMode2 = GameGetPlayerCameraMode(byteCurPlayer);
		if(*wCameraMode2 == 4) *wCameraMode2 = 0;
		
		// save the camera zoom factor, apply the context
		GameStoreLocalPlayerCameraExtZoomAndAspect();
		GameSetRemotePlayerCameraExtZoomAndAspect(byteCurPlayer);
		
		// aim & skills switching
		GameStoreLocalPlayerAim();
		GameSetRemotePlayerAim(byteCurPlayer);
		GameStoreLocalPlayerSkills();
		GameSetRemotePlayerSkills(byteCurPlayer);
		
		*pbyteCurrentPlayer = byteCurPlayer;

		// CTaskSimpleUseGun::SetPedPosition()
		(( void (*)(uintptr_t, PED_TYPE *))(g_libGTASA+0x46D6AC+1))(thiz, pPed);
		
		// restore the camera modes, internal id and local player's aim
		*pbyteCameraMode = byteSavedCameraMode;
		*wCameraMode2 = wSavedCameraMode2;
		
		// restore the skills
		GameSetLocalPlayerSkills();
		
		// remote the local player's camera zoom factor
		GameSetLocalPlayerCameraExtZoomAndAspect();

		*pbyteCurrentPlayer = 0;
		
		// restore the local player's keys and the internal ID.
		GameSetLocalPlayerAim();
	}
	else
	{
		// CTaskSimpleUseGun::SetPedPosition()
		(( void (*)(uintptr_t, PED_TYPE *))(g_libGTASA+0x46D6AC+1))(thiz, pPed);
	}
}

void (*CPedDamageResponseCalculator_ComputeDamageResponse)(stPedDamageResponse* thiz, PED_TYPE* pPed, uintptr_t damageResponse, bool bSpeak);
void CPedDamageResponseCalculator_ComputeDamageResponse_hook(stPedDamageResponse* thiz, PED_TYPE* pPed, uintptr_t damageResponse, bool bSpeak)
{
	if(pNetGame && damageResponse)
	{
		CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
		if(pPlayerPool)
		{
			PLAYERID damagedid = pPlayerPool->FindRemotePlayerIDFromGtaPtr(pPed);
			PLAYERID issuerid = pPlayerPool->FindRemotePlayerIDFromGtaPtr(pPed);

			// self damage like fall damage, drowned, etc
			if(issuerid == INVALID_PLAYER_ID && damagedid == INVALID_PLAYER_ID)
			{
				PLAYERID playerId = pPlayerPool->GetLocalPlayerID();
				pPlayerPool->GetLocalPlayer()->SendTakeDamageEvent(playerId, thiz->fDamage, thiz->dwWeapon, thiz->dwBodyPart);
			}

			// give player damage
			if(issuerid != INVALID_PLAYER_ID && damagedid == INVALID_PLAYER_ID)
				pPlayerPool->GetLocalPlayer()->SendGiveDamageEvent(issuerid, thiz->fDamage, thiz->dwWeapon, thiz->dwBodyPart);

			// player take damage
			else if(issuerid == INVALID_PLAYER_ID && damagedid != INVALID_PLAYER_ID)
				pPlayerPool->GetLocalPlayer()->SendTakeDamageEvent(damagedid, thiz->fDamage, thiz->dwWeapon, thiz->dwBodyPart);
		}
	}

	return CPedDamageResponseCalculator_ComputeDamageResponse(thiz, pPed, damageResponse, bSpeak);
}

uint16_t (*CPed_GetWeaponSkill)(PED_TYPE* pPed);
uint16_t CPed_GetWeaponSkill_hook(PED_TYPE* pPed)
{
	dwCurPlayerActor = (uintptr_t)pPed;
	byteCurPlayer = FindPlayerNumFromPedPtr((uintptr_t)pPed);
	byteInternalPlayer = *pbyteCurrentPlayer;
	
	if (dwCurPlayerActor && (byteCurPlayer != 0) && 
		byteInternalPlayer == 0)
	{
		GameStoreLocalPlayerSkills();
		GameSetRemotePlayerSkills(byteCurPlayer);
		g_iNeedStorePlayerSkill = 1;
	}
	
	uint16_t wWeaponSkill = (( uint16_t (*)(PED_TYPE*, WEAPON_SLOT_TYPE))(g_libGTASA+0x434E88+1))(pPed, pPed->WeaponSlots[pPed->byteCurWeaponSlot]);
	
	if(g_iNeedStorePlayerSkill)
	{
		g_iNeedStorePlayerSkill = 0;
		GameSetLocalPlayerSkills();
	}
	return wWeaponSkill;
}

signed int (*CBulletInfo_AddBullet)(ENTITY_TYPE* pEntity, WEAPON_SLOT_TYPE* pWeapon, VECTOR vec1, VECTOR vec2);
signed int CBulletInfo_AddBullet_hook(ENTITY_TYPE* pEntity, WEAPON_SLOT_TYPE* pWeapon, VECTOR vec1, VECTOR vec2)
{
	CBulletInfo_AddBullet(pEntity, pWeapon, vec1, vec2);
	
	// CBulletInfo::Update
	(( void (*)())(g_libGTASA+0x55E170+1))();
	return 1;
}

int (*RwFrameAddChild)(int a1, int a2);
int RwFrameAddChild_hook(int a1, int a2)
{
	if (!a1 || !a2)
		return 0;
	
	return RwFrameAddChild(a1, a2);
}

int (*CustomPipeRenderCB)(uintptr_t resEntry, uintptr_t object, uint8_t type, uint32_t flags);
int CustomPipeRenderCB_hook(uintptr_t resEntry, uintptr_t object, uint8_t type, uint32_t flags)
{
    uint16_t size = *(uint16_t *)(resEntry + 26);
    if(size)
    {
        RES_ENTRY_OBJ* arr = (RES_ENTRY_OBJ*)(resEntry + 28);
        uint32_t validFlag = flags & 0x84;
        for(int i = 0; i < size; i++)
        {
            if(!arr[i].validate) break;
            if(validFlag)
            {
                uintptr_t* v4 = *(uintptr_t **)(arr[i].validate);
                if(v4 > (uintptr_t*)0xFFFFFF00) return 0;
                if(v4)
                {
                    if(!*v4) return 0;
                }
            }
        }
    }
    return CustomPipeRenderCB(resEntry, object, type, flags);
}

int (*rxOpenGLDefaultAllInOneRenderCB)(uintptr_t resEntry, uintptr_t object, uint8_t type, uint32_t flags);
int rxOpenGLDefaultAllInOneRenderCB_hook(uintptr_t resEntry, uintptr_t object, uint8_t type, uint32_t flags)
{
    uint16_t size = *(uint16_t *)(resEntry + 26);
    if(size)
    {
        RES_ENTRY_OBJ* arr = (RES_ENTRY_OBJ*)(resEntry + 28);
        uint32_t validFlag = flags & 0x84;
        for(int i = 0; i < size; i++)
        {
            if(!arr[i].validate) break;
            if(validFlag)
            {
                uintptr_t* v4 = *(uintptr_t **)(arr[i].validate);
                if(v4 > (uintptr_t*)0xFFFFFF00) return 0;
                if(v4)
                {
                    if(!*v4) return 0;
                }
            }
        }
    }
    return rxOpenGLDefaultAllInOneRenderCB(resEntry, object, type, flags);
}

uint16_t (*CHud_DrawVitalStats)(uintptr_t thiz);
uint16_t CHud_DrawVitalStats_hook(uintptr_t thiz)
{
	if(pScoreBoard)
		pScoreBoard->setActive(true);
	
	return 0;
}

void InstallSAMPHooks()
{
	ARMHook::installMethodHook(g_libGTASA+0x5DDC60, (uintptr_t)Init_hook);
	ARMHook::installHook(g_libGTASA+0x39AEF4, (uintptr_t)Render2dStuff_hook, (uintptr_t*)&Render2dStuff);
	ARMHook::installHook(g_libGTASA+0x39B098, (uintptr_t)Render2dStuffAfterFade_hook, (uintptr_t*)&Render2dStuffAfterFade);
	ARMHook::installHook(g_libGTASA+0x239D5C, (uintptr_t)AND_TouchEvent_hook, (uintptr_t*)&AND_TouchEvent);
	ARMHook::installHook(g_libGTASA+0x3D7CA8, (uintptr_t)DisplayScreen_hook, (uintptr_t*)&DisplayScreen);
	ARMHook::installHook(g_libGTASA+0x3DAF84, (uintptr_t)CRadar__SetCoordBlip_hook, (uintptr_t*)&CRadar__SetCoordBlip);
	ARMHook::installHook(g_libGTASA+0x3DBA88, (uintptr_t)CRadar__GetRadarTraceColor_hook, (uintptr_t*)&CRadar__GetRadarTraceColor);
	ARMHook::installHook(g_libGTASA+0x3DE9A8, (uintptr_t)CRadar__DrawRadarGangOverlay_hook, (uintptr_t*)&CRadar__DrawRadarGangOverlay);
	ARMHook::installHook(g_libGTASA+0x391E20, (uintptr_t)CEntity_Render_hook, (uintptr_t*)&CEntity_Render);
	ARMHook::injectCode(g_libGTASA+0x2D99F4, (uintptr_t)PickupPickUp_hook, 1);
	ARMHook::installHook(g_libGTASA+0x3EF518, (uintptr_t)CObject_Render_hook, (uintptr_t*)&CObject_Render);
	ARMHook::installHook(g_libGTASA+0x3986CC, (uintptr_t)CGame_Process_hook, (uintptr_t*)&CGame_Process);
	ARMHook::installHook(g_libGTASA+0x482E60, (uintptr_t)TaskEnterVehicle_hook, (uintptr_t*)&TaskEnterVehicle);
	ARMHook::installHook(g_libGTASA+0x4833CC, (uintptr_t)CTaskComplexLeaveCar_hook, (uintptr_t*)&CTaskComplexLeaveCar);
	ARMHook::installHook(g_libGTASA+0x3C1BF8, (uintptr_t)CWorld_ProcessPedsAfterPreRender_hook, (uintptr_t*)&CWorld_ProcessPedsAfterPreRender);
	ARMHook::installMethodHook(g_libGTASA+0x5C8610, (uintptr_t)CTaskSimpleUseGun_SetPedPosition_hook);
	ARMHook::installHook(g_libGTASA+0x45A280, (uintptr_t)CPed__ProcessControl_hook, (uintptr_t*)&CPed__ProcessControl);
	ARMHook::installMethodHook(g_libGTASA+0x5CCA1C, (uintptr_t)AllVehicles__ProcessControl_hook); // CAutomobile::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CCD74, (uintptr_t)AllVehicles__ProcessControl_hook); // CBoat::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CCB44, (uintptr_t)AllVehicles__ProcessControl_hook); // CBike::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CD0DC, (uintptr_t)AllVehicles__ProcessControl_hook); // CPlane::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CCE8C, (uintptr_t)AllVehicles__ProcessControl_hook); // CHeli::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CCC5C, (uintptr_t)AllVehicles__ProcessControl_hook); // CBmx::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CCFB4, (uintptr_t)AllVehicles__ProcessControl_hook); // CMonsterTruck::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CD204, (uintptr_t)AllVehicles__ProcessControl_hook); // CQuadBike::ProcessControl
	ARMHook::installMethodHook(g_libGTASA+0x5CD454, (uintptr_t)AllVehicles__ProcessControl_hook); // CTrain::ProcessControl
	ARMHook::installHook(g_libGTASA+0x327528, (uintptr_t)CPedDamageResponseCalculator_ComputeDamageResponse_hook, (uintptr_t*)&CPedDamageResponseCalculator_ComputeDamageResponse);
	ARMHook::installHook(g_libGTASA+0x434F24, (uintptr_t)CPed_GetWeaponSkill_hook, (uintptr_t*)&CPed_GetWeaponSkill);
	ARMHook::installHook(g_libGTASA+0x567964, (uintptr_t)CWeapon_FireInstantHit_hook, (uintptr_t*)&CWeapon_FireInstantHit);
	ARMHook::installHook(g_libGTASA+0x3C70C0, (uintptr_t)CWorld__ProcessLineOfSight_hook, (uintptr_t*)&CWorld__ProcessLineOfSight);
	ARMHook::installHook(g_libGTASA+0x56668C, (uintptr_t)CWeapon_FireSniper_hook, (uintptr_t*)&CWeapon_FireSniper);
	ARMHook::installHook(g_libGTASA+0x55E090, (uintptr_t)CBulletInfo_AddBullet_hook, (uintptr_t*)&CBulletInfo_AddBullet);
	ARMHook::installHook(g_libGTASA+0x3D4EAC, (uintptr_t)CHud_DrawVitalStats_hook, (uintptr_t*)&CHud_DrawVitalStats);
	
	HookCPad();
}

void InstallGlobalHooks()
{
	ARMHook::installHook(g_libGTASA+0x23B3DC, (uintptr_t)NvFOpen_hook, (uintptr_t*)&NvFOpen);
	ARMHook::installHook(g_libGTASA+0x28E83C, (uintptr_t)CStream_InitImageList_hook, (uintptr_t*)&CStream_InitImageList);
	ARMHook::installHook(g_libGTASA+0x40C530, (uintptr_t)CGame_InitialiseRenderWare_hook, (uintptr_t*)&CGame_InitialiseRenderWare);
	ARMHook::installHook(g_libGTASA+0x336690, (uintptr_t)CModelInfo_AddPedModel_hook, (uintptr_t*)&CModelInfo_AddPedModel);
	ARMHook::installHook(g_libGTASA+0x336268, (uintptr_t)CModelInfo_AddAtomicModel_hook, (uintptr_t*)&CModelInfo_AddAtomicModel);
	ARMHook::installHook(g_libGTASA+0x3AF1A0, (uintptr_t)CPools_Initialise_hook, (uintptr_t*)&CPools_Initialise);
	ARMHook::installHook(g_libGTASA+0x3ABB08, (uintptr_t)CPlaceable_InitMatrixArray_hook, (uintptr_t*)&CPlaceable_InitMatrixArray);
	ARMHook::installHook(g_libGTASA+0x531118, (uintptr_t)CCustomRoadsignMgr__RenderRoadsignAtomic_hook, (uintptr_t*)&CCustomRoadsignMgr__RenderRoadsignAtomic);
	ARMHook::installHook(g_libGTASA+0x1AECC0, (uintptr_t)RwFrameAddChild_hook, (uintptr_t*)&RwFrameAddChild);
	ARMHook::installHook(g_libGTASA+0x28AAAC, (uintptr_t)CustomPipeRenderCB_hook, (uintptr_t*)&CustomPipeRenderCB);
	ARMHook::installHook(g_libGTASA+0x1EEC90, (uintptr_t)rxOpenGLDefaultAllInOneRenderCB_hook, (uintptr_t*)&rxOpenGLDefaultAllInOneRenderCB);
	
	ARMHook::installHook(g_libGTASA+0x4D3864, (uintptr_t)CText_Get_hook, (uintptr_t*)&CText_Get);
	ARMHook::installHook(g_libGTASA+0x5353B4, (uintptr_t)CFont_PrintString_hook, (uintptr_t*)&CFont_PrintString);
	ARMHook::installHook(g_libGTASA+0x25E660, (uintptr_t)MainMenuScreen_Update_hook, (uintptr_t*)&MainMenuScreen_Update);
	ARMHook::installHook(g_libGTASA+0x261C8C, (uintptr_t)StartGameScreen_OnNewGameCheck_hook, (uintptr_t*)&StartGameScreen_OnNewGameCheck);
	ARMHook::installHook(g_libGTASA+0x266B10, (uintptr_t)StartGameScreen_OnLoadGame_hook, (uintptr_t*)&StartGameScreen_OnLoadGame);
	InstallSAMPHooks();
}
