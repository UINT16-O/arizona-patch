#include "../main.h"
#include "game.h"
#include "RW/RenderWare.h"

extern CGame *pGame;
extern UI *pUI;

MaterialTextGenerator::MaterialTextGenerator()
{
	m_camera = 0;
	m_zBuffer = 0;
	SetUpScene();
}

void MaterialTextGenerator::SetUpScene()
{
	// RwCameraCreate
	m_camera = (( uintptr_t (*)())(g_libGTASA + 0x1ADA1C + 1))();
	
	// RwFrameCreate
	m_zBuffer = (( uintptr_t (*)())(g_libGTASA + 0x1AE9E0 + 1))();
	
	// RwObjectHasFrameSetFrame
	(( void (*)(uintptr_t, uintptr_t))(g_libGTASA + 0x1B2988 + 1))(m_camera, m_zBuffer);

	// RwCameraSetFarClipPlane
	(( void (*)(uintptr_t, float))(g_libGTASA + 0x1AD710 + 1))(m_camera, 300.0f);

	// RwCameraSetNearClipPlane
	(( void (*)(uintptr_t, float))(g_libGTASA + 0x1AD6F4 + 1))(m_camera, 0.01f);

	// RwCameraSetViewWindow
	float view[2] = { 0.5f, 0.5f };
	(( void (*)(uintptr_t, float*))(g_libGTASA + 0x1AD924 + 1))(m_camera, view);

	// RwCameraSetProjection
	(( void (*)(uintptr_t, int))(g_libGTASA + 0x1AD8DC+ 1))(m_camera, 1);

	// RpWorldAddCamera
	uintptr_t pRwWorld = *(uintptr_t*)(g_libGTASA + 0x95B060);
	if (pRwWorld) {
		(( void (*)(uintptr_t, uintptr_t))(g_libGTASA + 0x1EB118 + 1))(pRwWorld, m_camera);
	}
}

uintptr_t MaterialTextGenerator::Generate(uint8_t matSize, const char* fontname, uint8_t fontSize, uint8_t bold, uint32_t fontcol, uint32_t backcol, uint8_t align, const char* szText)
{
	int iSizeX, iSizeY;
	GetMaterialSize(matSize, &iSizeX, &iSizeY);
	
	// RwRasterCreate
	uintptr_t raster = (uintptr_t)RwRasterCreate(iSizeX, iSizeY, 32, rwRASTERFORMAT8888 | rwRASTERTYPECAMERATEXTURE);
	
	// RwTextureCreate
	uintptr_t bufferTexture = (( uintptr_t (*)(uintptr_t))(g_libGTASA + 0x1B1B4C + 1))(raster);
	
	if(!raster || !bufferTexture) return 0;
	
    // set camera frame buffer
	*(uintptr_t*)(m_camera + 0x60) = raster;
	
	// CVisibilityPlugins::SetRenderWareCamera
	(( void (*)(uintptr_t))(g_libGTASA + 0x55CFA4 + 1))(m_camera);
	
	// RwCameraClear
	(( void (*)(uintptr_t, unsigned int*, int))(g_libGTASA + 0x1AD8A0 + 1))(m_camera, &backcol, 3);
	
	// RwCameraBeginUpdate
	RwCameraBeginUpdate((RwCamera*)m_camera);
	
	// DefinedState
	(( void (*)(void))(g_libGTASA + 0x559008 + 1))();
	
	int backB = (backcol) & 0xFF;
	int backG = (backcol >> 8) & 0xFF;
	int backR = (backcol >> 16) & 0xFF;
	int backA = (backcol >> 24) & 0xFF;
	
	int fontB = (fontcol) & 0xFF;
	int fontG = (fontcol >> 8) & 0xFF;
	int fontR = (fontcol >> 16) & 0xFF;
	int fontA = (fontcol >> 24) & 0xFF;
	
	Render(fontname, ImVec2(iSizeX, iSizeY), fontSize, bold, ImColor(fontR, fontG, fontB, fontA), ImColor(backR, backG, backB, backA), align, szText);
	
	// RwCameraEndUpdate
	RwCameraEndUpdate((RwCamera*)m_camera);
	
	return bufferTexture;
}

void MaterialTextGenerator::Render(const char* fontname, ImVec2 size, uint8_t fontSize, uint8_t bold, ImColor fontcol, ImColor backcol, uint8_t align, const char* szText)
{
	if(!pUI) return;
	
	ImFont *pFont = ImGuiWrapper::loadFont(fontname, fontSize);
	
	ImGui::NewFrame();
	
	// text align
	ImVec2 vecPos;
	
	switch(align)
	{
		case OBJECT_MATERIAL_TEXT_ALIGN_LEFT:
		{
			vecPos = ImVec2(0.0f, 0.0f);
			ImGuiRenderer::drawText(pFont, vecPos, fontcol, false, (char *)szText, fontSize);
			break;
		}
		case OBJECT_MATERIAL_TEXT_ALIGN_CENTER:
		{
			int newLineCount = 0;
			std::string stText = szText;
			std::stringstream ssLine(stText);
			std::string tmpLine;
			while(std::getline(ssLine, tmpLine, '\n'))
			{
				if(newLineCount == 0)
					vecPos.y = (size.y - ImGuiRenderer::calculateTextSize(pFont, (char *)tmpLine.c_str(), fontSize).y) / 2;
				else vecPos.y -= ImGuiRenderer::calculateTextSize(pFont, (char *)tmpLine.c_str(), fontSize).y;
				newLineCount++;
			}

			if(vecPos.y < 0.0f)
				vecPos.y = 0.0f;

			stText = szText;
			std::stringstream ssLines(stText);
			std::string tmpLines;
			while(std::getline(ssLines, tmpLines, '\n'))
			{
				if(tmpLines[0] != 0)
				{
					vecPos.x = (size.x - ImGuiRenderer::calculateTextSize(pFont, (char *)tmpLines.c_str(), fontSize).x) / 2;
					ImGuiRenderer::drawText(pFont, vecPos, fontcol, false, (char *)tmpLines.c_str(), fontSize);
					vecPos.y += fontSize;
				}
			}
			break;
		}
		case OBJECT_MATERIAL_TEXT_ALIGN_RIGHT:
		{
			std::string stText = szText;
			std::stringstream ssLine(stText);
			std::string tmpLine;
			while(std::getline(ssLine, tmpLine, '\n'))
			{
				if(tmpLine[0] != 0)
				{
					vecPos.x = (size.x - ImGuiRenderer::calculateTextSize(pFont, (char *)tmpLine.c_str(), fontSize).x);
					ImGuiRenderer::drawText(pFont, vecPos, fontcol, false, (char *)tmpLine.c_str(), fontSize);
					vecPos.y += fontSize;
				}
			}
			break;
		}
	}

	ImGui::Render();
	ImGuiWrapper::renderDrawData(ImGui::GetDrawData());
}

void MaterialTextGenerator::GetMaterialSize(int iSize, int* iSizeX, int* iSizeY)
{
	static int sizes[14][2] = {
		{ 32, 32 }, { 64, 32 }, { 64, 64 }, { 128, 32 }, { 128, 64 }, { 128,128 }, { 256, 32 }, 
		{ 256, 64 }, { 256, 128 }, { 256, 256 }, { 512, 64 }, { 512,128 }, { 512,256 }, { 512,512 }
	};
	
	iSize = (iSize / 10) - 1;
	*iSizeX = sizes[iSize][0];
	*iSizeY = sizes[iSize][1];
}