#include "gui/ui.h"

#define OBJECT_MATERIAL_TEXT_ALIGN_LEFT		0
#define OBJECT_MATERIAL_TEXT_ALIGN_CENTER	1
#define OBJECT_MATERIAL_TEXT_ALIGN_RIGHT	2

class MaterialTextGenerator
{
public:
	MaterialTextGenerator();

	uintptr_t Generate(uint8_t matSize, const char* fontname, uint8_t fontSize, uint8_t bold, uint32_t fontcol, uint32_t backcol, uint8_t align, const char* szText);

private:
	void SetUpScene();
	void Render(const char* fontname, ImVec2 size, uint8_t fontSize, uint8_t bold, ImColor fontcol, ImColor backcol, uint8_t align, const char* szText);
	void GetMaterialSize(int iSize, int* iSizeX, int* iSizeY);
	
	uintptr_t m_camera;
	uintptr_t m_zBuffer;
};
