#include <android/log.h>
#include <cmath>

#include "main.h"
#include "game.h"
#include "net/netgame.h"

extern CGame *pGame;
extern CNetGame *pNetGame;
extern MaterialTextGenerator *pMaterialTextGenerator;

CObject::CObject(int iModel, float fPosX, float fPosY, float fPosZ, VECTOR vecRot, float fDrawDistance)
{
	uint32_t dwRetID 	= 0;
	m_pEntity 			= 0;
	m_dwGTAId 			= 0;

	if(iModel > 0 && iModel < 20000)
	{
		uintptr_t *dwModelArray = (uintptr_t*)(g_libGTASA+0x87BF48);
    	if(dwModelArray[iModel] == 0)
    		iModel = 18631;
	}
	else iModel = 18631;
	
	ScriptCommand(&create_object, iModel, fPosX, fPosY, fPosZ, &dwRetID);

	m_byteMoving = 0;
	m_fMoveSpeed = 0.0;
	m_vecRot = vecRot;
	
	if(GamePool_Object_GetAt(dwRetID))
	{
		m_dwGTAId = dwRetID;
		m_pEntity = GamePool_Object_GetAt(dwRetID);
		
		MATRIX4X4 mat;
		GetMatrix(&mat);
		mat.pos.X = fPosX;
		mat.pos.Y = fPosY;
		mat.pos.Z = fPosZ;

		SetMatrix(mat);
		SetRotation(vecRot.X, vecRot.Y, vecRot.Z);
	}
	
	m_wAttachVehicle = INVALID_VEHICLE_ID;
	m_vecAttachVehOffset = {0.0f, 0.0f, 0.0f};
	m_vecAttachVehRot = {0.0f, 0.0f, 0.0f};
	
	m_wAttachObject = INVALID_OBJECT_ID;
	m_vecAttachObjectOffset = {0.0f, 0.0f, 0.0f};
	m_vecAttachObjectRot = {0.0f, 0.0f, 0.0f};
	
	for(int i = 0; i < MAX_MATERIALS_PER_MODEL; i++)
	{
		m_MaterialTexture[i] = 0;
		memset(&m_MaterialInfo[i], 0, sizeof(MaterialInfo));
	}
	m_bHasMaterial = false;
}

CObject::~CObject()
{
	m_pEntity = GamePool_Object_GetAt(m_dwGTAId);
	if(m_pEntity)
	{
		if(m_pEntity->vtable != g_libGTASA+0x5C7358)
		{
			ScriptCommand(&destroy_object, m_dwGTAId);
			
			int nModelIndex = m_pEntity->nModelIndex;
			if(!GetModelRefCounts(nModelIndex))
				pGame->RemoveModel(nModelIndex, 0);
		}
	}
}

void CObject::Process(float fElapsedTime)
{
	if(!m_dwGTAId) return;
	if(!GamePool_Object_GetAt(m_dwGTAId)) return;
	
	float distance = (fElapsedTime*m_fMoveSpeed);
	if (m_byteMoving & 1)
	{
		MATRIX4X4 matPos;
		GetMatrix(&matPos);
		
		float remaining = DistanceRemaining(&matPos);
		if (distance >= remaining)
		{
			m_byteMoving &= ~1;
			TeleportTo(m_matTarget.pos.X, m_matTarget.pos.Y, m_matTarget.pos.Z);
			SetRotation(m_vecRot.X, m_vecRot.Y, m_vecRot.Z);
		}
		else
		{
			remaining /= distance;
			
			matPos.pos.X += (m_matTarget.pos.X - matPos.pos.X) / remaining;
			matPos.pos.Y += (m_matTarget.pos.Y - matPos.pos.Y) / remaining;
			matPos.pos.Z += (m_matTarget.pos.Z - matPos.pos.Z) / remaining;
			
			TeleportTo(matPos.pos.X, matPos.pos.Y, matPos.pos.Z);
			SetRotation(m_vecRot.X, m_vecRot.Y, m_vecRot.Z);
		}
	}
	
	if(m_wAttachVehicle != INVALID_VEHICLE_ID)
	{
		CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
		if (pVehiclePool->GetSlotState(m_wAttachVehicle))
		{
			CVehicle *pVehicle = pVehiclePool->GetAt(m_wAttachVehicle);
			if(pVehicle)
			{
				if(pVehicle->IsAdded())
					AttachToVehicle(pVehicle);
			}
		}
	}
	
	if(m_wAttachObject != INVALID_OBJECT_ID)
	{
		CObjectPool *pObjectPool = pNetGame->GetObjectPool();
		if (pObjectPool->GetSlotState(m_wAttachObject))
		{
			CObject *pObject = pObjectPool->GetAt(m_wAttachObject);
			if(pObject)
			{
				if(IsAdded())
					AttachToObject(pObject);
			}
		}
	}
}

void CObject::ProcessMaterialText()
{
	if(!m_dwGTAId) return;
	if(!GamePool_Object_GetAt(m_dwGTAId)) return;
	
	for(int i = 0; i < MAX_MATERIALS_PER_MODEL; i++)
	{
		if(m_MaterialInfo[i].m_bProcessCreate && m_MaterialInfo[i].m_iType == MATERIAL_TYPE_TEXT)
		{
			if(!m_MaterialTexture[i])
			{
				uintptr_t Material = pMaterialTextGenerator->Generate(m_MaterialInfo[i].m_byteMaterialSize, m_MaterialInfo[i].m_szFontName, m_MaterialInfo[i].m_byteFontSize, m_MaterialInfo[i].m_byteFontBold, m_MaterialInfo[i].m_dwFontColor, m_MaterialInfo[i].m_dwBackgroundColor, m_MaterialInfo[i].m_byteAlign, m_MaterialInfo[i].m_szText);
				
				m_MaterialTexture[i] = Material;
				m_bHasMaterial = true;
				// m_MaterialInfo[i].m_bProcessCreate = false;
			}
		}
	}
}

float CObject::DistanceRemaining(MATRIX4X4 *matPos)
{
	float fSX,fSY,fSZ;
	fSX = (matPos->pos.X - m_matTarget.pos.X) * (matPos->pos.X - m_matTarget.pos.X);
	fSY = (matPos->pos.Y - m_matTarget.pos.Y) * (matPos->pos.Y - m_matTarget.pos.Y);
	fSZ = (matPos->pos.Z - m_matTarget.pos.Z) * (matPos->pos.Z - m_matTarget.pos.Z);
	return (float)sqrt(fSX + fSY + fSZ);
}

void CObject::SetPos(float x, float y, float z)
{
	if(!m_dwGTAId) return;
	if(!GamePool_Object_GetAt(m_dwGTAId)) return;
	
	ScriptCommand(&put_object_at, m_dwGTAId, x, y, z);
}

void CObject::MoveTo(float X, float Y, float Z, float speed, float rX, float rY, float rZ)
{
	m_matTarget.pos.X = X;
	m_matTarget.pos.Y = Y;
	m_matTarget.pos.Z = Z;
	m_vecTargetRot.X = rX;
	m_vecTargetRot.Y = rY;
	m_vecTargetRot.Z = rZ;
	m_fMoveSpeed = speed;
	if(m_byteMoving)
		m_byteMoving = 0;
	m_byteMoving |= 1;
}

void CObject::SetRotation(float x, float y, float z)
{
	if(!m_dwGTAId) return;
	if(!GamePool_Object_GetAt(m_dwGTAId)) return;
	
	ScriptCommand(&set_object_rotation, m_dwGTAId, x, y, z);
	m_vecRot.X = x;
	m_vecRot.Y = y;
	m_vecRot.Z = z;
}

void CObject::SetMaterial(int iModel, int iMaterialIndex, char* txdname, char* texturename, uint32_t dwColor)
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "SetMaterial: model: %d, %s, %s 0x%X", iModel, txdname, texturename, dwColor);
	if (iMaterialIndex <= MAX_MATERIALS_PER_MODEL)
	{
		if(m_MaterialTexture[iMaterialIndex])
		{
			// DeleteRWTexture(&m_MaterialTexture[iMaterialIndex]);
			m_MaterialTexture[iMaterialIndex] = 0;
		}
		m_MaterialTexture[iMaterialIndex] = LoadTextureFromTxd(txdname, texturename);
		m_MaterialInfo[iMaterialIndex].m_dwMaterialColor = dwColor;
		m_MaterialInfo[iMaterialIndex].m_iType = MATERIAL_TYPE_TEXTURE;
		m_bHasMaterial = true;
	}
}

void CObject::SetMaterialText(int iMaterialIndex, uint8_t byteMaterialSize, const char *szFontName, uint8_t byteFontSize, uint8_t byteFontBold, uint32_t dwFontColor, uint32_t dwBackgroundColor, uint8_t byteAlign, const char *szText)
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "SetMaterialText: [%d]: %s, matSize: %d, %s, fontSize: %d, bold: %d, fontcol: 0x%X, backcol:  0x%X, align: %d", iMaterialIndex, szText, byteMaterialSize, szFontName, byteFontSize, byteFontBold, dwFontColor, dwBackgroundColor, byteAlign);
	if(iMaterialIndex <= MAX_MATERIALS_PER_MODEL)
	{
		if(m_MaterialTexture[iMaterialIndex])
		{
			// DeleteRWTexture(&m_MaterialTexture[iMaterialIndex]);
			m_MaterialTexture[iMaterialIndex] = 0;
		}
		m_MaterialInfo[iMaterialIndex].m_iType = MATERIAL_TYPE_TEXT;
		m_MaterialInfo[iMaterialIndex].m_byteMaterialSize = byteMaterialSize;
		m_MaterialInfo[iMaterialIndex].m_byteFontSize = byteFontSize;
		m_MaterialInfo[iMaterialIndex].m_byteFontBold = byteFontBold;
		m_MaterialInfo[iMaterialIndex].m_dwFontColor = dwFontColor;
		m_MaterialInfo[iMaterialIndex].m_dwBackgroundColor = dwBackgroundColor;
		m_MaterialInfo[iMaterialIndex].m_byteAlign = byteAlign;
		
		memset(m_MaterialInfo[iMaterialIndex].m_szFontName, 0, 32);
		strcpy(m_MaterialInfo[iMaterialIndex].m_szFontName, szFontName);
		
		memset(m_MaterialInfo[iMaterialIndex].m_szText, 0, 2048);
		strcpy(m_MaterialInfo[iMaterialIndex].m_szText, szText);
		m_MaterialInfo[iMaterialIndex].m_bProcessCreate = true;
	}
}

void CObject::AttachToVehicle(CVehicle *pVehicle)
{
	if(!ScriptCommand(&is_object_attached, m_dwGTAId))
	{
		ScriptCommand(&attach_object_to_vehicle, m_dwGTAId, pVehicle->m_dwGTAId, m_vecAttachVehOffset.X, m_vecAttachVehOffset.Y, m_vecAttachVehOffset.Z, m_vecAttachVehRot.X, m_vecAttachVehRot.Y, m_vecAttachVehRot.Z);
	}
}
	
void CObject::SetAttachedVehicle(uint16_t wAttachedVehicleId, VECTOR vecAttachOffset, VECTOR vecAttachRot)
{
	if(wAttachedVehicleId == INVALID_VEHICLE_ID)
	{
		m_wAttachVehicle = INVALID_VEHICLE_ID;
		m_vecAttachVehOffset = {0.0f, 0.0f, 0.0f};
		m_vecAttachVehRot = {0.0f, 0.0f, 0.0f};
	}
	else
	{
		m_wAttachVehicle = wAttachedVehicleId;
		m_vecAttachVehOffset = vecAttachOffset;
		m_vecAttachVehRot = vecAttachRot;
	}
}

void CObject::AttachToObject(CObject *pObject)
{
	if(!ScriptCommand(&is_object_attached, m_dwGTAId))
	{
		ScriptCommand(&attach_object_to_object, m_dwGTAId, pObject->m_dwGTAId, m_vecAttachObjectOffset.X, m_vecAttachObjectOffset.Y, m_vecAttachObjectOffset.Z, m_vecAttachObjectRot.X, m_vecAttachObjectRot.Y, m_vecAttachObjectRot.Z);
	}
}

void CObject::SetAttachedObject(uint16_t wAttachedObjectId, VECTOR vecAttachOffset, VECTOR vecAttachRot)
{
	if(wAttachedObjectId == INVALID_OBJECT_ID)
	{
		m_wAttachObject = INVALID_OBJECT_ID;
		m_vecAttachObjectOffset = {0.0f, 0.0f, 0.0f};
		m_vecAttachObjectRot = {0.0f, 0.0f, 0.0f};
	}
	else
	{
		m_wAttachObject = wAttachedObjectId;
		m_vecAttachObjectOffset = vecAttachOffset;
		m_vecAttachObjectRot = vecAttachRot;
	}
}

void CObject::SetNoCameraCol(uint8_t byteNoCamCol)
{
	// CCollision::bCamCollideWithObjects
	if(byteNoCamCol)
	{
		*(uint8_t*)(g_libGTASA+0x685FB5) = 0;
	}
	else
	{
		*(uint8_t*)(g_libGTASA+0x685FB5) = *(uint8_t*)(g_libGTASA+0x685FB5);
	}
}