#pragma once

#include "vehicle.h"

#define MAX_MATERIALS_PER_MODEL 15
#define MATERIAL_TYPE_NONE 0
#define MATERIAL_TYPE_TEXTURE 1
#define MATERIAL_TYPE_TEXT 2

class CObject : public CEntity
{
public:
	CObject(int iModel, float fPosX, float fPosY, float fPosZ, VECTOR vecRot, float fDrawDistance);
	~CObject();

	void Process(float fElapsedTime);
	void ProcessMaterialText();
	
	float DistanceRemaining(MATRIX4X4 *matPos);

	void SetPos(float x, float y, float z);
	void MoveTo(float x, float y, float z, float speed);

	void SetRotation(float x, float y, float z);
	void GetRotation(float *x, float *y, float *z);
	
	void MoveTo(float X, float Y, float Z, float speed, float rX, float rY, float rZ);
	
	void SetMaterial(int iModel, int iMaterialIndex, char* txdname, char* texturename, uint32_t dwColor);
	void SetMaterialText(int byteMaterialIndex, uint8_t byteMaterialSize, const char *szFontName, uint8_t byteFontSize, uint8_t byteFontBold, uint32_t dwFontColor, uint32_t dwBackgroundColor, uint8_t byteAlign, const char *szText);

	void AttachToVehicle(CVehicle *pVehicle);
	void SetAttachedVehicle(uint16_t wAttachedVehicleId, VECTOR vecAttachOffset, VECTOR vecAttachRot);
	
	void AttachToObject(CObject *pObject);
	void SetAttachedObject(uint16_t wAttachedObjectId, VECTOR vecAttachOffset, VECTOR vecAttachRot);
	
	void SetNoCameraCol(uint8_t byteNoCamCol = 0);
	
public:
	MATRIX4X4	m_matTarget;
	MATRIX4X4	m_matCurrent;
	uint8_t		m_byteMoving;
	float		m_fMoveSpeed;
	VECTOR		m_vecRot;
	VECTOR		m_vecTargetRot;
	
	struct MaterialInfo
	{
		int m_iType;
		uint8_t m_byteMaterialSize;
		char m_szFontName[32];
		uint8_t m_byteFontSize;
		uint8_t m_byteFontBold;
		uint32_t m_dwFontColor;
		uint32_t m_dwBackgroundColor;
		uint8_t m_byteAlign;
		char m_szText[2048];
		
		uint32_t m_dwMaterialColor;
		bool m_bProcessCreate;
	};
	MaterialInfo m_MaterialInfo[MAX_MATERIALS_PER_MODEL];
	uintptr_t	m_MaterialTexture[MAX_MATERIALS_PER_MODEL];
	bool		m_bHasMaterial;
	
	// Vehicle attach
	uint16_t	m_wAttachVehicle;
	VECTOR		m_vecAttachVehOffset;
	VECTOR		m_vecAttachVehRot;
	
	// Object attach
	uint16_t	m_wAttachObject;
	VECTOR		m_vecAttachObjectOffset;
	VECTOR		m_vecAttachObjectRot;
};