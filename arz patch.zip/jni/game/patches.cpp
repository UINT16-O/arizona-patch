#include <android/log.h>

#include "../main.h"
#include "../util/ARMHook.h"
#include "common.h"

char* WORLD_PLAYERS = nullptr;
ATOMIC_MODEL *ATOMIC_MODELS = nullptr;

void ApplyGlobalPatches()
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Applying global patches..");
	
	// reallocate CWorld::Players[]
	WORLD_PLAYERS = new char[1004*PLAYER_PED_SLOTS];
	ARMHook::unprotect(g_libGTASA+0x5D021C);
	*(char**)(g_libGTASA+0x5D021C) = WORLD_PLAYERS;
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "CWorld::Player new address = 0x%X", WORLD_PLAYERS);

	ATOMIC_MODELS = new ATOMIC_MODEL[1200000];
	for(int i = 0; i < 1200000; i++)
	{
		// CBaseModelInfo::CBaseModelInfo
		(( void (*)(ATOMIC_MODEL*))(g_libGTASA+0x33559C+1))(&ATOMIC_MODELS[i]);
		ATOMIC_MODELS[i].vtable = g_libGTASA+0x5C6C68;
		memset(ATOMIC_MODELS[i].data, 0, sizeof(ATOMIC_MODELS->data));
	}
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "AtomicModelsPool new address = 0x%X", ATOMIC_MODELS);
	
	// DefaultPCSaveFileName
	char* DefaultPCSaveFileName = (char*)(g_libGTASA+0x60EAE8);
	memcpy((char*)DefaultPCSaveFileName, "GTASAMP", 8);
	
	// CAudioEngine::StartLoadingTune
	ARMHook::makeNOP(g_libGTASA+0x56C150, 2);

	// NOP calling CRealTimeShadowManager::ReturnRealTimeShadow from ~CPhysical
	ARMHook::makeNOP(g_libGTASA+0x3A019C, 2);

	// ReapplyPlayerAnimation (�� �����)
	ARMHook::makeNOP(g_libGTASA+0x45477E, 5);

	// radar draw blips
    ARMHook::makeNOP(g_libGTASA+0x3DCA90, 2);
    ARMHook::makeNOP(g_libGTASA+0x3DD4A4, 2);

    // no vehicle audio processing
    ARMHook::makeNOP(g_libGTASA+0x4E31A6, 2);
    ARMHook::makeNOP(g_libGTASA+0x4EE7D2, 2);
    ARMHook::makeNOP(g_libGTASA+0x4F741E, 2);
    ARMHook::makeNOP(g_libGTASA+0x50AB4A, 2);
	
    // CCamera::CamShake from CExplosion::AddExplosion
    ARMHook::makeNOP(g_libGTASA+0x55EFB8, 2);
    ARMHook::makeNOP(g_libGTASA+0x55F8F8, 2);
	
    // CPed::RemoveWeaponWhenEnteringVehicle (GetPlayerInfoForThisPlayerPed)
    ARMHook::makeNOP(g_libGTASA+0x434D94, 6);

    // camera_on_actor path
    ARMHook::unprotect(g_libGTASA+0x2F7B68);
    *(uint8_t*)(g_libGTASA+0x2F7B6B) = 0xBE;

    // CBike::ProcessAI
    ARMHook::unprotect(g_libGTASA+0x4EE200);
    *(uint8_t*)(g_libGTASA+0x4EE200) = 0x9B;

	// ��������� ��� MaxHealth
	ARMHook::unprotect(g_libGTASA+0x3BAC68);
	*(float*)(g_libGTASA+0x3BAC68) = 176.0f;
	
	// ��������� ��� Armour
	ARMHook::unprotect(g_libGTASA+0x27D884);
	*(float*)(g_libGTASA+0x27D884) = 176.0f;

    // CTaskSimplePlayerOnFoot::PlayIdleAnimations
	ARMHook::makeRET(g_libGTASA+0x4BDB18);

	// CWidgetRegionSteeringSelection::Draw
	ARMHook::makeRET(g_libGTASA+0x284BB8);

	// CHud::SetHelpMessage
	ARMHook::makeRET(g_libGTASA+0x3D4244);
	
	// CHud::SetHelpMessageStatUpdate
	ARMHook::makeRET(g_libGTASA+0x3D42A8);
	
	// CVehicleRecording::Load
	ARMHook::makeRET(g_libGTASA+0x2DC8E0);

    // Interior_c::AddPickups
    ARMHook::makeRET(g_libGTASA+0x3E17F0);
	
	// InteriorGroup_c::Exit
    ARMHook::makeRET(g_libGTASA+0x3E42E0);
	
	// CAEGlobalWeaponAudioEntity::ServiceAmbientGunFire
    ARMHook::makeRET(g_libGTASA+0x3474E0);
	
	// CHud::DrawVehicleName
    ARMHook::makeRET(g_libGTASA+0x3D541C);
	
	// CFileLoader::LoadPickup
    ARMHook::makeRET(g_libGTASA+0x401BAC);
	
	// CPopulation::AddPed
    ARMHook::makeRET(g_libGTASA+0x45F1A4);
	
	// CPlaceName::Process
    ARMHook::makeRET(g_libGTASA+0x45F1A4);
	
	// CPlane::DoPlaneGenerationAndRemoval
    ARMHook::makeRET(g_libGTASA+0x504DB8);
	
	// CCarEnterExit::SetPedInCarDirect
    ARMHook::makeRET(g_libGTASA+0x494FE4);
	
	// CRealTimeShadowManager::Update
    ARMHook::makeRET(g_libGTASA+0x541AC4);
	
	// CPlayerInfo::FindObjectToSteal
    ARMHook::makeRET(g_libGTASA+0x3AC114);

	// CarCtrl::GenerateRandomCars nulled from CGame::Process
    ARMHook::makeRET(g_libGTASA+0x2B5C24);

	// CTheCarGenerators::Process nulled from CGame::Process
    ARMHook::makeRET(g_libGTASA+0x4F90AC);

	// CEntryExit::GenerateAmbientPeds
    ARMHook::makeRET(g_libGTASA+0x2C1CB0);

	// CHud::DrawBustedWastedMessage
	ARMHook::makeRET(g_libGTASA+0x3D62FC);
	
	// NOP calling CMessages::AddBigMessage from CPlayerInfo::KillPlayer
	ARMHook::makeNOP(g_libGTASA+0x3AC8B2, 2);

    // CWidgetPlayerInfo::DrawWanted
    ARMHook::writeMemory(g_libGTASA+0x27D8D0, (uintptr_t)"\x4F\xF0\x00\x08", 4);
	
	// 90 FPS
	ARMHook::writeMemory(g_libGTASA+0x463FE8, (uintptr_t)"\x5A", 1);
	ARMHook::writeMemory(g_libGTASA+0x56C1F6, (uintptr_t)"\x5A", 1);
	ARMHook::writeMemory(g_libGTASA+0x56C126, (uintptr_t)"\x5A", 1);
	ARMHook::writeMemory(g_libGTASA+0x95B074, (uintptr_t)"\x5A", 1);
	
	// CTxdStore::Initialise
	ARMHook::writeMemory(g_libGTASA+0x55BA9A, (uintptr_t)"\x4F\xF4\xB8\x50\xC0\xF2\x11\x00", 8);
	ARMHook::writeMemory(g_libGTASA+0x55BA9E, (uintptr_t)"\xC0\xF2\x11\x00", 4);
	ARMHook::writeMemory(g_libGTASA+0x55BAA8, (uintptr_t)"\x44\xF6\x20\x60", 4);
	ARMHook::writeMemory(g_libGTASA+0x55BAB0, (uintptr_t)"\x44\xF6\x20\x62", 4);

 	// VehicleStruct increase (0x0032C*0x0050 = 0x00FDC0)
    ARMHook::writeMemory(g_libGTASA+0x405338, (uintptr_t)"\x4F\xF6\xC0\x50", 4);	// MOV  R0, #0x00FDC0
    ARMHook::writeMemory(g_libGTASA+0x405342, (uintptr_t)"\x50\x20", 2);			// MOVS R0, #0x0050
    ARMHook::writeMemory(g_libGTASA+0x405348, (uintptr_t)"\x50\x22", 2);			// MOVS R2, #0x0050
    ARMHook::writeMemory(g_libGTASA+0x405374, (uintptr_t)"\x50\x2B", 2);			// CMP  R3, #0x0050
	
	// reallocate RQRenderTarget::Create from _rwOpenGLRasterCreate
	ARMHook::writeMemory(g_libGTASA+0x1859FC, (uintptr_t)"\x01\x22", 2);
	
	// CPlayerPed::CPlayerPed task fix
	ARMHook::writeMemory(g_libGTASA+0x458ED1, (uintptr_t)"\xE0", 1);
}

void ApplySAMPPatchesInGame()
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Applying samp patches.. (ingame)");
	
	/* ������������� ����� */
	// CTheZones::ZonesVisited[100]
	memset((void*)(g_libGTASA+0x8EA7B0), 1, 100);
	
	// CTheZones::ZonesRevealed
	*(uint32_t*)(g_libGTASA+0x8EA7A8) = 100;
	
	// Show FPS
	*(uint8_t*)(g_libGTASA+0x8ED875) = 1;
}