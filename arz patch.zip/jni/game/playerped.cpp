#include "../main.h"
#include "game.h"
#include "net/netgame.h"
#include "util/armhook.h"

extern CGame* pGame;
extern CNetGame *pNetGame;

extern bool bIgnoreNextEntry;

CPlayerPed::CPlayerPed()
{
	m_dwGTAId = 1;
	m_pPed = (PED_TYPE*)GamePool_FindPlayerPed();
	m_pEntity = (ENTITY_TYPE*)GamePool_FindPlayerPed();

	m_bytePlayerNumber = 0;
	SetPlayerPedPtrRecord(m_bytePlayerNumber,(uintptr_t)m_pPed);
	ScriptCommand(&set_actor_weapon_droppable, m_dwGTAId, 1);
	ScriptCommand(&set_actor_can_be_decapitated, m_dwGTAId, 0);
	
	m_dwArrow = 0;
	m_bHaveBulletData = false;
	memset(&m_bulletData, 0, sizeof(BULLET_DATA));
}

CPlayerPed::CPlayerPed(uint8_t bytePlayerNumber, int iSkin, float fX, float fY, float fZ, float fRotation)
{
	uint32_t dwPlayerActorID = 0;
	int iPlayerNum = bytePlayerNumber;

	m_pPed = nullptr;
	m_dwGTAId = 0;

	ScriptCommand(&create_player, &iPlayerNum, fX, fY, fZ, &dwPlayerActorID);
	ScriptCommand(&create_actor_from_player, &iPlayerNum, &dwPlayerActorID);

	m_dwGTAId = dwPlayerActorID;
	m_pPed = GamePool_Ped_GetAt(m_dwGTAId);
	m_pEntity = (ENTITY_TYPE*)GamePool_Ped_GetAt(m_dwGTAId);

	m_bytePlayerNumber = bytePlayerNumber;
	SetPlayerPedPtrRecord(m_bytePlayerNumber, (uintptr_t)m_pPed);
	ScriptCommand(&set_actor_weapon_droppable, m_dwGTAId, 1);
	ScriptCommand(&set_actor_immunities, m_dwGTAId, 0, 0, 1, 0, 0);
	ScriptCommand(&set_actor_can_be_decapitated, m_dwGTAId, 0);

	if(pNetGame)
	{
		ScriptCommand(&set_actor_money, m_dwGTAId, 0);
		ScriptCommand(&set_actor_money, m_dwGTAId, pNetGame->m_iDeathDropMoney);
	}

	SetModelIndex(iSkin);
	SetTargetRotation(fRotation);

	MATRIX4X4 mat;
	GetMatrix(&mat);
	mat.pos.X = fX;
	mat.pos.Y = fY;
	mat.pos.Z = fZ + 0.15f;
	SetMatrix(mat);
	
	m_dwArrow = 0;
	m_bHaveBulletData = false;
	memset(&m_bulletData, 0, sizeof(BULLET_DATA));
	memset(&RemotePlayerKeys[m_bytePlayerNumber], 0, sizeof(PAD_KEYS));
}

CPlayerPed::~CPlayerPed()
{
	memset(&RemotePlayerKeys[m_bytePlayerNumber], 0, sizeof(PAD_KEYS));
	SetPlayerPedPtrRecord(m_bytePlayerNumber, 0);

	if(!m_pPed || !GamePool_Ped_GetAt(m_dwGTAId) || m_pPed->entity.vtable == 0x5C7358)
	{
		m_pPed = nullptr;
		m_pEntity = nullptr;
		m_dwGTAId = 0;
		return;
	}

	if(m_dwParachuteObject)
	{
		ScriptCommand(&disassociate_object, m_dwParachuteObject, 0.0f, 0.0f, 0.0f, 0);
		ScriptCommand(&destroy_object_with_fade, m_dwParachuteObject);
		m_dwParachuteObject = 0;
	}

	if(IN_VEHICLE(m_pPed))
		RemoveFromVehicleAndPutAt(100.0f, 100.0f, 10.0f);

	uintptr_t dwPedPtr = (uintptr_t)m_pPed;
	*(uint32_t*)(*(uintptr_t*)(dwPedPtr + 1088) + 76) = 0;
	
	// CPlayerPed::Destructor
	(( void (*)(PED_TYPE*))(*(void**)(m_pPed->entity.vtable+0x4)))(m_pPed);

	m_pPed = nullptr;
	m_pEntity = nullptr;
}

bool CPlayerPed::IsOnGround()
{
	if(m_pPed)
	{
		if(m_pPed->dwStateFlags & 3)
		{
			return true;
		}
	}
	return false;
}

// 0.3.7
bool CPlayerPed::IsInVehicle()
{
	if(!m_pPed) return false;

	if(IN_VEHICLE(m_pPed))
		return true;

	return false;
}

// 0.3.7
bool CPlayerPed::IsAPassenger()
{
	if(m_pPed->pVehicle && IN_VEHICLE(m_pPed))
	{
		VEHICLE_TYPE *pVehicle = (VEHICLE_TYPE *)m_pPed->pVehicle;

		if(	pVehicle->pDriver != m_pPed ||
			pVehicle->entity.nModelIndex == TRAIN_PASSENGER ||
			pVehicle->entity.nModelIndex == TRAIN_FREIGHT )
			return true;
	}

	return false;
}

// 0.3.7
VEHICLE_TYPE* CPlayerPed::GetGtaVehicle()
{
	return (VEHICLE_TYPE*)m_pPed->pVehicle;
}

// 0.3.7
void CPlayerPed::RemoveFromVehicleAndPutAt(float fX, float fY, float fZ)
{
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	if(m_pPed && IN_VEHICLE(m_pPed))
		ScriptCommand(&remove_actor_from_car_and_put_at, m_dwGTAId, fX, fY, fZ);
}

// 0.3.7
void CPlayerPed::SetInitialState()
{
	(( void (*)(PED_TYPE*))(g_libGTASA+0x458D1C+1))(m_pPed);
}

// 0.3.7
void CPlayerPed::SetHealth(float fHealth)
{
	if(!m_pPed) return;
	m_pPed->fHealth = fHealth;
}

// 0.3.7
float CPlayerPed::GetHealth()
{
	if(!m_pPed) return 0.0f;
	return m_pPed->fHealth;
}

// 0.3.7
void CPlayerPed::SetArmour(float fArmour)
{
	if(!m_pPed) return;
	m_pPed->fArmour = fArmour;
}

float CPlayerPed::GetArmour()
{
	if(!m_pPed) return 0.0f;
	return m_pPed->fArmour;
}

void CPlayerPed::SetInterior(uint8_t byteID)
{
	if(!m_pPed) return;

	ScriptCommand(&select_interior, byteID);
	ScriptCommand(&link_actor_to_interior, m_dwGTAId, byteID);

	MATRIX4X4 mat;
	GetMatrix(&mat);
	ScriptCommand(&refresh_streaming_at, mat.pos.X, mat.pos.Y);
}

void CPlayerPed::PutDirectlyInVehicle(int iVehicleID, int iSeat)
{
	if(!m_pPed) return;
	if(!GamePool_Vehicle_GetAt(iVehicleID)) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	// ��������
	if(GetCurrentWeapon() == WEAPON_PARACHUTE)
	{
		SetArmedWeapon(0);
	}

	VEHICLE_TYPE *pVehicle = GamePool_Vehicle_GetAt(iVehicleID);

	if(pVehicle->fHealth == 0.0f) return;
	// check is cplaceable
	if (pVehicle->entity.vtable == g_libGTASA+0x5C7358) return;
	// check seatid (��������)

	if(iSeat == 0)
	{
		if(pVehicle->pDriver && IN_VEHICLE(pVehicle->pDriver)) return;
		ScriptCommand(&put_actor_in_car, m_dwGTAId, iVehicleID);
	}
	else
	{
		iSeat--;
		ScriptCommand(&put_actor_in_car2, m_dwGTAId, iVehicleID, iSeat);
	}

	if(m_pPed == GamePool_FindPlayerPed() && IN_VEHICLE(m_pPed))
		pGame->GetCamera()->SetBehindPlayer();

	if(pNetGame)
	{
		CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
		VEHICLEID TrainVehicleId = pVehiclePool->FindIDFromGtaPtr(pVehicle);
		if(TrainVehicleId == INVALID_VEHICLE_ID || TrainVehicleId > MAX_VEHICLES) return;

		CVehicle* pTrain = pVehiclePool->GetAt(TrainVehicleId);

		if(pTrain && pTrain->IsATrainPart() && this == pNetGame->GetPlayerPool()->GetLocalPlayer()->GetPlayerPed())
			ScriptCommand(&camera_on_vehicle, pTrain->m_dwGTAId, 3, 2);
	}
}

void CPlayerPed::EnterVehicle(int iVehicleID, bool bPassenger)
{
	if(!m_pPed) return;
	VEHICLE_TYPE* ThisVehicleType;
	if((ThisVehicleType = GamePool_Vehicle_GetAt(iVehicleID)) == 0) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	
	bIgnoreNextEntry = true;
	
	if(bPassenger)
	{
		if(ThisVehicleType->entity.nModelIndex == TRAIN_PASSENGER &&
			(m_pPed == GamePool_FindPlayerPed()))
		{
			*pbyteCurrentPlayer = m_bytePlayerNumber;
			GameStoreLocalPlayerSkills();
			GameSetRemotePlayerSkills(m_bytePlayerNumber);
			ScriptCommand(&put_actor_in_car2, m_dwGTAId, iVehicleID, -1);
			GameSetLocalPlayerSkills();
			*pbyteCurrentPlayer = 0;
		}
		else
		{
			ScriptCommand(&send_actor_to_car_passenger,m_dwGTAId,iVehicleID, 3000, -1);
		}
	}
	else
		ScriptCommand(&send_actor_to_car_driverseat, m_dwGTAId, iVehicleID, 3000);
}

// 0.3.7
void CPlayerPed::ExitCurrentVehicle()
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	VEHICLE_TYPE* ThisVehicleType = 0;

	if(IN_VEHICLE(m_pPed))
	{
		if(GamePool_Vehicle_GetIndex((VEHICLE_TYPE*)m_pPed->pVehicle))
		{
			int index = GamePool_Vehicle_GetIndex((VEHICLE_TYPE*)m_pPed->pVehicle);
			ThisVehicleType = GamePool_Vehicle_GetAt(index);
			if(ThisVehicleType)
			{
				if(	ThisVehicleType->entity.nModelIndex != TRAIN_PASSENGER &&
					ThisVehicleType->entity.nModelIndex != TRAIN_PASSENGER_LOCO)
				{
					ScriptCommand(&make_actor_leave_car, m_dwGTAId, GetCurrentVehicleID());
				}
			}
		}
	}
}

// 0.3.7
int CPlayerPed::GetCurrentVehicleID()
{
	if(!m_pPed) return 0;

	VEHICLE_TYPE *pVehicle = (VEHICLE_TYPE *)m_pPed->pVehicle;
	return GamePool_Vehicle_GetIndex(pVehicle);
}

int CPlayerPed::GetVehicleSeatID()
{
	VEHICLE_TYPE *pVehicle;

	if( GetActionTrigger() == ACTION_INCAR && (pVehicle = (VEHICLE_TYPE *)m_pPed->pVehicle) != 0 ) 
	{
		if(pVehicle->pDriver == m_pPed) return 0;
		if(pVehicle->pPassengers[0] == m_pPed) return 1;
		if(pVehicle->pPassengers[1] == m_pPed) return 2;
		if(pVehicle->pPassengers[2] == m_pPed) return 3;
		if(pVehicle->pPassengers[3] == m_pPed) return 4;
		if(pVehicle->pPassengers[4] == m_pPed) return 5;
		if(pVehicle->pPassengers[5] == m_pPed) return 6;
		if(pVehicle->pPassengers[6] == m_pPed) return 7;
	}

	return (-1);
}

// 0.3.7
void CPlayerPed::TogglePlayerControllable(bool bToggle)
{
	MATRIX4X4 mat;

	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if(!bToggle)
	{
		ScriptCommand(&toggle_player_controllable, m_bytePlayerNumber, 0);
		ScriptCommand(&lock_actor, m_dwGTAId, 1);
	}
	else
	{
		ScriptCommand(&toggle_player_controllable, m_bytePlayerNumber, 1);
		ScriptCommand(&lock_actor, m_dwGTAId, 0);
		if(!IsInVehicle()) 
		{
			GetMatrix(&mat);
			TeleportTo(mat.pos.X, mat.pos.Y, mat.pos.Z);
		}
	}
}

// 0.3.7
void CPlayerPed::SetModelIndex(unsigned int uiModel)
{
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	if(!IsPedModel(uiModel))
		uiModel = 0;

	if(m_pPed)
	{
		// CClothes::RebuildPlayer nulled
		ARMHook::makeRET(g_libGTASA+0x3F1030);
		DestroyFollowPedTask();
		CEntity::SetModelIndex(uiModel);

		// reset the Ped Audio Attributes
		(( void (*)(uintptr_t, uintptr_t))(g_libGTASA+0x34B2A8+1))(((uintptr_t)m_pPed+660), (uintptr_t)m_pPed);
	}
}

// ��������
void CPlayerPed::DestroyFollowPedTask()
{

}

// ��������
void CPlayerPed::ClearWeapons()
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	
	*pbyteCurrentPlayer = m_bytePlayerNumber;
	(( void (*)(uintptr_t))(g_libGTASA+0x4345AC+1))((uintptr_t)m_pPed);
	*pbyteCurrentPlayer = 0;
}

// ��������
void CPlayerPed::ResetDamageEntity()
{

}

// 0.3.7
void CPlayerPed::RestartIfWastedAt(VECTOR *vecRestart, float fRotation)
{	
	ScriptCommand(&restart_if_wasted_at, vecRestart->X, vecRestart->Y, vecRestart->Z, fRotation, 0);
}

// 0.3.7
void CPlayerPed::SetTargetRotation(float fRotation)
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	m_pPed->fRotation1 = DegToRad(fRotation);
	m_pPed->fRotation2 = DegToRad(fRotation);
}

void CPlayerPed::SetRotation(float fRotation)
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	m_pPed->fRotation1 = DegToRad(fRotation);
	m_pPed->fRotation2 = DegToRad(fRotation);
}

// 0.3.7
uint8_t CPlayerPed::GetActionTrigger()
{
	return (uint8_t)m_pPed->dwAction;
}

// 0.3.7
bool CPlayerPed::IsDead()
{
	if(!m_pPed) return true;
	if(m_pPed->fHealth > 0.0f) return false;
	return true;
}

// 0.3.7
void CPlayerPed::ShowMarker(uint32_t iMarkerColorID)
{
	if(m_dwArrow)
	{
		ScriptCommand(&disable_marker, m_dwArrow);
		m_dwArrow = 0;
	}
	
	ScriptCommand(&create_arrow_above_actor, m_dwGTAId, &m_dwArrow);
	ScriptCommand(&set_marker_color, m_dwArrow, iMarkerColorID);
	ScriptCommand(&show_on_radar2, m_dwArrow, 2);
}

// 0.3.7
void CPlayerPed::HideMarker()
{
	if(m_dwArrow) ScriptCommand(&disable_marker, m_dwArrow);
	m_dwArrow = 0;
}

// 0.3.7
void CPlayerPed::SetFightingStyle(int iStyle)
{
	if(!m_pPed) return;
	ScriptCommand( &set_fighting_style, m_dwGTAId, iStyle, 6 );
}

// 0.3.7
void CPlayerPed::ApplyAnimation( char *szAnimName, char *szAnimFile, float fT,
								 int opt1, int opt2, int opt3, int opt4, int iUnk )
{
	int iWaitAnimLoad = 0;

	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if(!strcasecmp(szAnimFile,"SEX")) return;

	if(!pGame->IsAnimationLoaded(szAnimFile))
	{
		pGame->RequestAnimation(szAnimFile);
		while(!pGame->IsAnimationLoaded(szAnimFile))
		{
			usleep(1000);
			iWaitAnimLoad++;
			if(iWaitAnimLoad > 15) return;
		}
	}

	ScriptCommand(&apply_animation, m_dwGTAId, szAnimName, szAnimFile, fT, opt1, opt2, opt3, opt4, iUnk);
}

unsigned char CPlayerPed::FindDeathReasonAndResponsiblePlayer(PLAYERID *nPlayer)
{
	unsigned char byteDeathReason;
	PLAYERID bytePlayerIDWhoKilled;
	CVehiclePool *pVehiclePool;
	CPlayerPool *pPlayerPool;

	// grab the vehicle/player pool now anyway, even though we may not need it.
	if(pNetGame) {
		pVehiclePool = pNetGame->GetVehiclePool();
		pPlayerPool = pNetGame->GetPlayerPool();
	}
	else { // just leave if there's no netgame.
		*nPlayer = INVALID_PLAYER_ID;
		return WEAPON_UNKNOWN;
	}

	if(m_pPed) 
	{
		byteDeathReason = (unsigned char)m_pPed->dwWeaponUsed;
		if(byteDeathReason < WEAPON_CAMERA || byteDeathReason == WEAPON_HELIBLADES || byteDeathReason == WEAPON_EXPLOSION) { // It's a weapon of some sort.

			if(m_pPed->pdwDamageEntity) { // check for a player pointer.
				
				bytePlayerIDWhoKilled = pPlayerPool->
					FindRemotePlayerIDFromGtaPtr((PED_TYPE *)m_pPed->pdwDamageEntity);

				if(bytePlayerIDWhoKilled != INVALID_PLAYER_ID) {
					// killed by another player with a weapon, this is all easy.
					*nPlayer = bytePlayerIDWhoKilled;
					return byteDeathReason;
				} else { // could be a vehicle
					if(pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE *)m_pPed->pdwDamageEntity) != INVALID_VEHICLE_ID) {
						VEHICLE_TYPE *pGtaVehicle = (VEHICLE_TYPE *)m_pPed->pdwDamageEntity;
						bytePlayerIDWhoKilled = pPlayerPool->
							FindRemotePlayerIDFromGtaPtr((PED_TYPE *)pGtaVehicle->pDriver);
												
						if(bytePlayerIDWhoKilled != INVALID_PLAYER_ID) {
							*nPlayer = bytePlayerIDWhoKilled;
							return byteDeathReason;
						}
					}
				}
			}
			//else { // weapon was used but who_killed is 0 (?)
			*nPlayer = INVALID_PLAYER_ID;
			return WEAPON_UNKNOWN;
			//}
		}
		else if(byteDeathReason == WEAPON_DROWN) {
			*nPlayer = INVALID_PLAYER_ID;
			return WEAPON_DROWN;
		}
		else if(byteDeathReason == WEAPON_VEHICLE) {

			if(m_pPed->pdwDamageEntity) {
				// now, if we can find the vehicle
				// we can probably derive the responsible player.
				// Look in the vehicle pool for this vehicle.
				if(pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE *)m_pPed->pdwDamageEntity) != INVALID_VEHICLE_ID)
				{
					VEHICLE_TYPE *pGtaVehicle = (VEHICLE_TYPE *)m_pPed->pdwDamageEntity;

					bytePlayerIDWhoKilled = pPlayerPool->
						FindRemotePlayerIDFromGtaPtr((PED_TYPE *)pGtaVehicle->pDriver);
											
					if(bytePlayerIDWhoKilled != INVALID_PLAYER_ID) {
						*nPlayer = bytePlayerIDWhoKilled;
						return WEAPON_VEHICLE;
					}
				}									
			}
		}
		else if(byteDeathReason == WEAPON_COLLISION) {

			if(m_pPed->pdwDamageEntity) {
				if(pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE *)m_pPed->pdwDamageEntity) != INVALID_VEHICLE_ID)
				{
					VEHICLE_TYPE *pGtaVehicle = (VEHICLE_TYPE *)m_pPed->pdwDamageEntity;
										
					bytePlayerIDWhoKilled = pPlayerPool->
						FindRemotePlayerIDFromGtaPtr((PED_TYPE *)pGtaVehicle->pDriver);
						
					if(bytePlayerIDWhoKilled != INVALID_PLAYER_ID) {
						*nPlayer = bytePlayerIDWhoKilled;
						return WEAPON_COLLISION;
					}
				}
				else {
					*nPlayer = INVALID_PLAYER_ID;
					return WEAPON_COLLISION;
				}
			}
		}
	}

	// Unhandled death type.
	*nPlayer = INVALID_PLAYER_ID;
	return WEAPON_UNKNOWN;
}

// 0.3.7
void CPlayerPed::GetBonePosition(int iBoneID, VECTOR* vecOut)
{
	if(!m_pPed) return;
	if(m_pPed->entity.vtable == 0x5C7358) return;

	(( void (*)(PED_TYPE*, VECTOR*, int, int))(g_libGTASA+0x436590+1))(m_pPed, vecOut, iBoneID, 0);
}

// 0.3.7
void CPlayerPed::GetTransformedBonePosition(int iBoneID, VECTOR* vecOut)
{
	if(!m_pPed) return;
	if(m_pPed->entity.vtable == 0x5C7358) return;

	(( void (*)(PED_TYPE*, VECTOR*, int, int))(g_libGTASA+0x4383C0+1))(m_pPed, vecOut, iBoneID, 0);
}

void CPlayerPed::GetBoneMatrix(MATRIX4X4 *matOut, int iBoneID)
{
	if(!m_pPed) return;
	if(m_pPed->entity.vtable == 0x5C7358) return;
	if(!m_pPed->entity.pdwRenderWare) return;
	
	// GetAnimHierarchyFromSkinClump
	uintptr_t animHierarchy = (( uintptr_t (*)(uintptr_t))(g_libGTASA+0x559338+1))(m_pPed->entity.pdwRenderWare);
	
	// RpHAnimIDGetIndex
	int iAnimIndex = (( uintptr_t (*)(uintptr_t, uintptr_t))(g_libGTASA+0x19A448+1))(animHierarchy, iBoneID) << 6;
	
	MATRIX4X4 *tempMatOut = (MATRIX4X4*)(iAnimIndex + *(uintptr_t*)(animHierarchy+8));
	if(tempMatOut) memcpy(matOut, tempMatOut, sizeof(MATRIX4X4));
}

void CPlayerPed::ClumpUpdateAnimations(float step, int flag)
{
	if(m_pPed)
	{
		uintptr_t rwObject = GetRWObject();
		if(rwObject)
		{
			// RpAnimBlendClumpUpdateAnimations
			(( void (*)(uintptr_t, float, int))(g_libGTASA+0x33D6E4+1))(rwObject, step, flag);
		}
	}
}

// ��������
uint16_t CPlayerPed::GetKeys(uint16_t *lrAnalog, uint16_t *udAnalog, uint8_t *exKeys)
{
	*lrAnalog = LocalPlayerKeys.wKeyLR;
	*udAnalog = LocalPlayerKeys.wKeyUD;
	uint16_t wRet = 0;
	
	if(*exKeys)
	{
		*exKeys = 0;
		
		// KEY_YES
		if(LocalPlayerKeys.bKeys[ePadKeys::KEY_YES]) *exKeys = 1;
	
		// KEY_NO
		if(LocalPlayerKeys.bKeys[ePadKeys::KEY_NO]) *exKeys = 2;
	
		// KEY_CTRL_BACK
		if(LocalPlayerKeys.bKeys[ePadKeys::KEY_CTRL_BACK]) *exKeys = 3;
	}
	
	// KEY_ANALOG_RIGHT
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_RIGHT]) wRet |= 1;
	wRet <<= 1;
	// KEY_ANALOG_LEFT
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_LEFT]) wRet |= 1;
	wRet <<= 1;
	// KEY_ANALOG_DOWN
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_DOWN]) wRet |= 1;
	wRet <<= 1;
	// KEY_ANALOG_UP
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_UP]) wRet |= 1;
	wRet <<= 1;
	// KEY_WALK
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_WALK]) wRet |= 1;
	wRet <<= 1;
	// KEY_SUBMISSION
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_SUBMISSION]) wRet |= 1;
	wRet <<= 1;
	// KEY_LOOK_LEFT
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_LOOK_LEFT]) wRet |= 1;
	wRet <<= 1;
	// KEY_HANDBRAKE
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE]) wRet |= 1;
	wRet <<= 1;
	// KEY_LOOK_RIGHT
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_LOOK_RIGHT]) wRet |= 1;
	wRet <<= 1;
	// KEY_JUMP
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP]) wRet |= 1;
	wRet <<= 1;
	// KEY_SECONDARY_ATTACK
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK]) wRet |= 1;
	wRet <<= 1;
	// KEY_SPRINT
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_SPRINT]) wRet |= 1;
	wRet <<= 1;
	// KEY_FIRE
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE]) wRet |= 1;
	wRet <<= 1;
	// KEY_CROUCH
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH]) wRet |= 1;
	wRet <<= 1;
	// KEY_ACTION
	if(LocalPlayerKeys.bKeys[ePadKeys::KEY_ACTION]) wRet |= 1;
	
	memset(LocalPlayerKeys.bKeys, 0, ePadKeys::SIZE);

	return wRet;
}

void CPlayerPed::SetKeys(uint16_t wKeys, uint16_t lrAnalog, uint16_t udAnalog)
{
	PAD_KEYS *pad = &RemotePlayerKeys[m_bytePlayerNumber];

	// LEFT/RIGHT
	pad->wKeyLR = lrAnalog;
	// UP/DOWN
	pad->wKeyUD = udAnalog;

	// KEY_ACTION
	pad->bKeys[ePadKeys::KEY_ACTION] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_CROUCH
	pad->bKeys[ePadKeys::KEY_CROUCH] = (wKeys & 1);
	if(!pad->bKeys[ePadKeys::KEY_CROUCH]) pad->bIgnoreCrouch = false;
	wKeys >>= 1;
	// KEY_FIRE
	pad->bKeys[ePadKeys::KEY_FIRE] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_SPRINT
	pad->bKeys[ePadKeys::KEY_SPRINT] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_SECONDARY_ATTACK
	pad->bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_JUMP
	pad->bKeys[ePadKeys::KEY_JUMP] = (wKeys & 1);
	if(!pad->bKeys[ePadKeys::KEY_JUMP]) pad->bIgnoreJump = false;
	wKeys >>= 1;
	// KEY_LOOK_RIGHT
	pad->bKeys[ePadKeys::KEY_LOOK_RIGHT] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_HANDBRAKE
	pad->bKeys[ePadKeys::KEY_HANDBRAKE] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_LOOK_LEFT
	pad->bKeys[ePadKeys::KEY_LOOK_LEFT] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_SUBMISSION
	pad->bKeys[ePadKeys::KEY_SUBMISSION] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_WALK
	pad->bKeys[ePadKeys::KEY_WALK] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_ANALOG_UP
	pad->bKeys[ePadKeys::KEY_ANALOG_UP] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_ANALOG_DOWN
	pad->bKeys[ePadKeys::KEY_ANALOG_DOWN] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_ANALOG_LEFT
	pad->bKeys[ePadKeys::KEY_ANALOG_LEFT] = (wKeys & 1);
	wKeys >>= 1;
	// KEY_ANALOG_RIGHT
	pad->bKeys[ePadKeys::KEY_ANALOG_RIGHT] = (wKeys & 1);

	return;
}

void CPlayerPed::SetAttachedObject(int iSlot, NEW_ATTACHED_OBJECT attachedObjectData)
{
	if(!m_pPed || !GamePool_Ped_GetAt(m_dwGTAId)) return;
	if(m_pPed->entity.vtable == g_libGTASA+0x5C7358) return;
	
	if(iSlot < 0 || iSlot >= MAX_PED_ATTACHED_OBJECT)
		return;
	
	RemoveAttachedObjects(iSlot);
	
	MATRIX4X4 matrix;
	GetMatrix(&matrix);
	m_AttachedObjects.m_info[iSlot] = attachedObjectData;
	m_AttachedObjects.m_pObject[iSlot] = new CObject(m_AttachedObjects.m_info[iSlot].iModel, matrix.pos.X, matrix.pos.Y, matrix.pos.Z, {0.0f, 0.0f, 0.0f}, 150.0f);
	if(m_AttachedObjects.m_info[iSlot].dwMaterialColor1)
		m_AttachedObjects.m_pObject[iSlot]->SetMaterial(-1, 0, nullptr, nullptr, m_AttachedObjects.m_info[iSlot].dwMaterialColor1);
	if(m_AttachedObjects.m_info[iSlot].dwMaterialColor2)
		m_AttachedObjects.m_pObject[iSlot]->SetMaterial(-1, 1, nullptr, nullptr, m_AttachedObjects.m_info[iSlot].dwMaterialColor2);
	m_AttachedObjects.m_pObject[iSlot]->SetCollisionChecking(false);
	m_bObjectSlotUsed[iSlot] = true;
}

void CPlayerPed::RemoveAttachedObjects(int iSlot)
{
	if(iSlot < 0 || iSlot >= MAX_PED_ATTACHED_OBJECT)
		return;
	
	if(GetObjectSlotState(iSlot))
		if(m_AttachedObjects.m_pObject[iSlot])
			delete m_AttachedObjects.m_pObject[iSlot];
	
	m_bObjectSlotUsed[iSlot] = false;
	m_AttachedObjects.m_pObject[iSlot] = nullptr;
}

void CPlayerPed::RemoveAllAttachedObjects()
{
	for(int i = 0; i < MAX_PED_ATTACHED_OBJECT; i++)
	{
		RemoveAttachedObjects(i);
	}
}

bool CPlayerPed::IsHaveAttachedObject()
{
	for(int i = 0; i < MAX_PED_ATTACHED_OBJECT; i++)
	{
		if(m_bObjectSlotUsed[i] && m_AttachedObjects.m_pObject[i])
			return true;
	}
	return false;
}

bool CPlayerPed::GetObjectSlotState(int iSlot)
{
	if(iSlot < 0 && iSlot >= MAX_PED_ATTACHED_OBJECT)
		return false;
	
	return m_bObjectSlotUsed[iSlot];
}

void CPlayerPed::ProcessAttachedObjects()
{
	if(!m_pPed || !GamePool_Ped_GetAt(m_dwGTAId)) 
		return;
	
	VECTOR vecProject;
	MATRIX4X4 boneMat;

	(( void (*)(ENTITY_TYPE *))(g_libGTASA+0x391968+1))(m_pEntity);

	for(int i = 0; i < MAX_PED_ATTACHED_OBJECT; i++)
	{
		if(!m_AttachedObjects.m_pObject[i]) continue;
		if(!m_AttachedObjects.m_pObject[i]->m_pEntity) continue;
		if(!m_pPed->pPedBones[m_AttachedObjects.m_info[i].iBone]) continue;
		
		if(!IsAdded())
		{
			m_AttachedObjects.m_pObject[i]->TeleportTo(0.0f, 0.0f, 0.0f);
			continue;
		}
		
		if(m_dwGTAId && GamePool_Object_GetAt(m_AttachedObjects.m_pObject[i]->m_dwGTAId))
		{
			(( void (*)(ENTITY_TYPE *))(*(void **)(m_pEntity->vtable+0x10)))(m_AttachedObjects.m_pObject[i]->m_pEntity);
			
			GetBoneMatrix(&boneMat, m_pPed->pPedBones[m_AttachedObjects.m_info[i].iBone]->iNodeId);
			ProjectMatrix(&vecProject, &boneMat, &m_AttachedObjects.m_info[i].vecOffset);
			
			boneMat.pos = vecProject;
			
			VECTOR *vecRot = &m_AttachedObjects.m_info[i].vecRotation;
			if(!vecRot) continue;
			
			if(vecRot->X != 0.0f)
				RwMatrixRotate(&boneMat, 0, vecRot->X);
			
			if(vecRot->Y != 0.0f)
				RwMatrixRotate(&boneMat, 1, vecRot->Y);
			
			if(vecRot->Z != 0.0f)
				RwMatrixRotate(&boneMat, 2, vecRot->Z);
			
			VECTOR *vecScale = &m_AttachedObjects.m_info[i].vecScale;
			if(!vecScale) continue;
			
			RwMatrixScale(&boneMat, vecScale);
						
			m_AttachedObjects.m_pObject[i]->SetMatrix(boneMat);
			m_AttachedObjects.m_pObject[i]->UpdateRwMatrixAndFrame();
						
			(( void (*)(ENTITY_TYPE *))(*(void **)(m_pEntity->vtable+0x8)))(m_AttachedObjects.m_pObject[i]->m_pEntity);
		}
	}
}

void CPlayerPed::ProcessCuffAndCarry()
{
	
}

void CPlayerPed::SetDead()
{
	if(m_pPed && GamePool_Ped_GetAt(m_dwGTAId))
	{
		MATRIX4X4 mat;
		GetMatrix(&mat);
		// will reset the tasks
		TeleportTo(mat.pos.X,mat.pos.Y,mat.pos.Z);
		
		*pbyteCurrentPlayer = m_bytePlayerNumber;
		ScriptCommand(&kill_actor, m_dwGTAId);
		*pbyteCurrentPlayer = 0;
	}
}

CAMERA_AIM * CPlayerPed::GetCurrentAim()
{
	return GameGetInternalAim();
}

void CPlayerPed::SetCurrentAim(CAMERA_AIM * pAim)
{
	GameStoreRemotePlayerAim(m_bytePlayerNumber, pAim);
}

uint16_t CPlayerPed::GetCameraMode()
{
	return GameGetLocalPlayerCameraMode();
}

void CPlayerPed::SetCameraMode(uint16_t byteCamMode)
{
	GameSetPlayerCameraMode(byteCamMode, m_bytePlayerNumber);
}

float CPlayerPed::GetCameraExtendedZoom()
{
	return GameGetLocalPlayerCameraExtZoom();
}

void CPlayerPed::SetCameraZoomAndAspect(float fZoom, float fAspectRatio)
{
	GameSetPlayerCameraExtZoomAndAspect(m_bytePlayerNumber, fZoom, fAspectRatio);
}

void CPlayerPed::GiveWeapon(int iWeaponID, int iAmmo)
{
	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;
	
	int iModelID = 0;
	iModelID = GameGetWeaponModelIDFromWeaponID(iWeaponID);
	
	if (iModelID == -1) return;
	
	if (!pGame->IsModelLoaded(iModelID)) 
	{
		pGame->RequestModel(iModelID);
		pGame->LoadRequestedModels();
		while (!pGame->IsModelLoaded(iModelID)) sleep(1);
	}
	
	*pbyteCurrentPlayer = m_bytePlayerNumber;
	GameStoreLocalPlayerSkills();
	GameSetRemotePlayerSkills(m_bytePlayerNumber);
	ScriptCommand(&give_actor_weapon, m_dwGTAId, iWeaponID, iAmmo);
	GameSetLocalPlayerSkills();
	SetArmedWeapon(iWeaponID);
	*pbyteCurrentPlayer = 0;
}

void CPlayerPed::SetArmedWeapon(int iWeaponID)
{
	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;
	
	*pbyteCurrentPlayer = m_bytePlayerNumber;
	GameStoreLocalPlayerSkills();
	GameSetRemotePlayerSkills(m_bytePlayerNumber);
	ScriptCommand(&set_actor_armed_weapon, m_dwGTAId, iWeaponID);
	GameSetLocalPlayerSkills();
	*pbyteCurrentPlayer = 0;
}

uint8_t CPlayerPed::GetCurrentWeapon()
{
	if (!m_pPed) return 0;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return 0;

	uint32_t dwRetVal;
	ScriptCommand(&get_actor_armed_weapon, m_dwGTAId, &dwRetVal);
	return (uint8_t)dwRetVal;
}

void CPlayerPed::SetAimZ(float fAimZ)
{
	if(m_pPed)
		*(float*)((m_pPed->dwPlayerInfoOffset) + 84) = fAimZ;
}

float CPlayerPed::GetAimZ()
{
	if(m_pPed)
		return *(float*)((m_pPed->dwPlayerInfoOffset) + 84);
	
	return 0.0f;
}

WEAPON_SLOT_TYPE * CPlayerPed::GetCurrentWeaponSlot()
{
	if (m_pPed)
		return &m_pPed->WeaponSlots[m_pPed->byteCurWeaponSlot];
	
	return NULL;
}

WEAPON_SLOT_TYPE *CPlayerPed::FindWeaponSlot(uint32_t dwWeapon)
{
	if(m_pPed)
	{
		uint8_t i;
		for(i = 0; i < 13; i++)
		{
			if(m_pPed->WeaponSlots[i].dwType == dwWeapon)
				return &m_pPed->WeaponSlots[i];
		}
	}
	return NULL;
}

void CPlayerPed::GetWeaponInfoForFire(int bLeft, VECTOR *vecBone, VECTOR *vecOut)
{
	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;
	if(m_pPed->entity.vtable == g_libGTASA+0x5C7358) return;
	
	VECTOR *pFireOffset = GetCurrentWeaponFireOffset();
	if(pFireOffset && vecBone && vecOut)
	{
		vecOut->X = pFireOffset->X;
		vecOut->Y = pFireOffset->Y;
		vecOut->Z = pFireOffset->Z;

		int bone_id = 24;
		if(bLeft)
			bone_id = 34;
		
		GetBonePosition(bone_id, vecBone);

		vecBone->Z += pFireOffset->Z + 0.15f;

		GetTransformedBonePosition(bone_id, vecOut);
	}
}

VECTOR* CPlayerPed::GetCurrentWeaponFireOffset()
{
	if(!m_pPed) return nullptr;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return nullptr;

	WEAPON_SLOT_TYPE *pSlot = GetCurrentWeaponSlot();
	if(pSlot)
		return (VECTOR *)(GetWeaponInfo(pSlot->dwType, 1) + 0x24);
	
	return nullptr;
}

CPlayerPed *g_pCurrentFiredPed = nullptr;
BULLET_DATA *g_pCurrentBulletData = nullptr;
extern uint32_t (*CWeapon_FireInstantHit)(WEAPON_SLOT_TYPE* thiz, PED_TYPE* pFiringEntity, VECTOR* vecOrigin, VECTOR* muzzlePos, ENTITY_TYPE* targetEntity, VECTOR *target, VECTOR* originForDriveBy, int arg6, int muzzle);
void CPlayerPed::FireInstant()
{
	uint8_t byteSavedCameraMode = 0;
	uint16_t wSavedCameraMode2 = 0;
	
	if(!m_pPed) return;
	if(m_bytePlayerNumber != 0)
	{
		byteSavedCameraMode = *pbyteCameraMode;
		*pbyteCameraMode = GameGetPlayerCameraMode(m_bytePlayerNumber);
		
		wSavedCameraMode2 = *wCameraMode2;
		*wCameraMode2 = GameGetPlayerCameraMode(m_bytePlayerNumber);
		if(*wCameraMode2 == 4) *wCameraMode2 = 0;

		GameStoreLocalPlayerCameraExtZoomAndAspect();
		GameSetRemotePlayerCameraExtZoomAndAspect(m_bytePlayerNumber);

		GameStoreLocalPlayerAim();
		GameSetRemotePlayerAim(m_bytePlayerNumber);
		GameStoreLocalPlayerSkills();
		GameSetRemotePlayerSkills(m_bytePlayerNumber);
	}

	g_pCurrentFiredPed = this;

	if(m_bHaveBulletData)
	{
		g_pCurrentBulletData = &m_bulletData;
	}
	else
	{
		g_pCurrentBulletData = nullptr;
	}

	WEAPON_SLOT_TYPE *pSlot = GetCurrentWeaponSlot();
	if(pSlot)
	{
		if(GetCurrentWeapon() != 0)
		{
			VECTOR vecBone;
			VECTOR vecOut;

			GetWeaponInfoForFire(false, &vecBone, &vecOut);
			CWeapon_FireInstantHit(pSlot, m_pPed, &vecBone, &vecOut, nullptr, nullptr, nullptr, 0, 1);
		}
	}

	g_pCurrentFiredPed = nullptr;
	g_pCurrentBulletData = nullptr;

	if(m_bytePlayerNumber)
	{
		*pbyteCameraMode = byteSavedCameraMode;
		*wCameraMode2 = wSavedCameraMode2;

		GameSetLocalPlayerCameraExtZoomAndAspect();
		GameSetLocalPlayerAim();
		GameSetLocalPlayerSkills();
	}
}

void CPlayerPed::ProcessBulletData(BULLET_DATA *btData)
{
	if(!m_pPed) return;
	
	BULLET_SYNC_DATA bulletSyncData;

	if(btData)
	{
		m_bHaveBulletData = true;
		m_bulletData.pEntity = btData->pEntity;
		m_bulletData.vecOrigin.X = btData->vecOrigin.X;
		m_bulletData.vecOrigin.Y = btData->vecOrigin.Y;
		m_bulletData.vecOrigin.Z = btData->vecOrigin.Z;

		m_bulletData.vecPos.X = btData->vecPos.X;
		m_bulletData.vecPos.Y = btData->vecPos.Y;
		m_bulletData.vecPos.Z = btData->vecPos.Z;

		m_bulletData.vecOffset.X = btData->vecOffset.X;
		m_bulletData.vecOffset.Y = btData->vecOffset.Y;
		m_bulletData.vecOffset.Z = btData->vecOffset.Z;

		uint8_t byteHitType = 0;
		unsigned short InstanceID = 0xFFFF;

		if(m_bytePlayerNumber == 0)
		{
			if(pNetGame)
			{
				CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
				if(pPlayerPool)
				{
					CPlayerPed *pPlayerPed = pPlayerPool->GetLocalPlayer()->GetPlayerPed();
					if(pPlayerPed)
					{
						memset(&bulletSyncData, 0, sizeof(BULLET_SYNC_DATA));
						if(pPlayerPed->GetCurrentWeapon() != WEAPON_SNIPER || btData->pEntity)
						{
							if(btData->pEntity)
							{
								CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
								CObjectPool *pObjectPool = pNetGame->GetObjectPool();

								uint16_t PlayerID;
								uint16_t VehicleID;
								uint16_t ObjectID;

								if(pVehiclePool && pObjectPool)
								{
									PlayerID = pPlayerPool->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)btData->pEntity);
									if(PlayerID == INVALID_PLAYER_ID)
									{
										VehicleID = pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE*)btData->pEntity);
										if(VehicleID == INVALID_VEHICLE_ID)
										{
											ObjectID = pObjectPool->FindIDFromGtaPtr(btData->pEntity);
											if(ObjectID == INVALID_OBJECT_ID)
											{
												VECTOR vecOut;
												vecOut.X = 0.0f;
												vecOut.Y = 0.0f;
												vecOut.Z = 0.0f;
												
												if(btData->pEntity->mat)
												{
													ProjectMatrix(&vecOut, btData->pEntity->mat, &btData->vecOffset);
													btData->vecOffset.X = vecOut.X;
													btData->vecOffset.Y = vecOut.Y;
													btData->vecOffset.Z = vecOut.Z;
												}
												else
												{
													btData->vecOffset.X = btData->pEntity->mat->pos.X + btData->vecOffset.X;
													btData->vecOffset.Y = btData->pEntity->mat->pos.Y + btData->vecOffset.Y;
													btData->vecOffset.Z = btData->pEntity->mat->pos.Z + btData->vecOffset.Z;
												}
											}
											else
											{
												// object
												byteHitType = 3;
												InstanceID = ObjectID;
											}
										}
										else
										{
											// vehicle
											byteHitType = 2;
											InstanceID = VehicleID;
										}
									}
									else
									{
										// player
										byteHitType = 1;
										InstanceID = PlayerID;
									}
								}
							}

							bulletSyncData.vecOrigin.X = btData->vecOrigin.X;
							bulletSyncData.vecOrigin.Y = btData->vecOrigin.Y;
							bulletSyncData.vecOrigin.Z = btData->vecOrigin.Z;

							bulletSyncData.vecPos.X = btData->vecPos.X;
							bulletSyncData.vecPos.Y = btData->vecPos.Y;
							bulletSyncData.vecPos.Z = btData->vecPos.Z;

							bulletSyncData.vecOffset.X = btData->vecOffset.X;
							bulletSyncData.vecOffset.Y = btData->vecOffset.Y;
							bulletSyncData.vecOffset.Z = btData->vecOffset.Z;

							bulletSyncData.byteHitType = byteHitType;
							bulletSyncData.PlayerID = InstanceID;
							bulletSyncData.byteWeaponID = pPlayerPed->GetCurrentWeapon();

							RakNet::BitStream bsBullet;
							bsBullet.Write((char)ID_BULLET_SYNC);
							bsBullet.Write((char*)&bulletSyncData, sizeof(BULLET_SYNC_DATA));
							pNetGame->GetRakClient()->Send(&bsBullet, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
						}
					}
				}
			}
		}
	}
	else
	{
		m_bHaveBulletData = false;
		memset(&m_bulletData, 0, sizeof(BULLET_DATA));
	}
}

void CPlayerPed::SetStateFlags(uint32_t dwState)
{	
	if(!m_pPed) return;
	m_pPed->dwStateFlags = dwState;
}

uint32_t CPlayerPed::GetStateFlags()
{	
	if(!m_pPed) return 0;
	return m_pPed->dwStateFlags;
}

void CPlayerPed::CheckVehicleParachute()
{
	if(m_dwParachuteObject)
	{
		ScriptCommand(&disassociate_object,m_dwParachuteObject,0.0f,0.0f,0.0f,0);
		ScriptCommand(&destroy_object,m_dwParachuteObject);
		m_dwParachuteObject = 0;
	}
}

void CPlayerPed::SetSkillLevel(int iSkillType, uint16_t wSkillLevel)
{
	if(m_bytePlayerNumber)
	{
		GameStoreRemotePlayerSkill(m_bytePlayerNumber, iSkillType, wSkillLevel);
	}
	else
	{
		GameUpdateLocalPlayerSkill(iSkillType, wSkillLevel);
	}
}

void CPlayerPed::ToggleCellphone(int iOn)
{
	if(!m_pPed) return;
	
	m_bCellPhoneEnabled = iOn;
	ScriptCommand(&toggle_actor_cellphone, m_dwGTAId, iOn);
}

bool CPlayerPed::IsCellphoneEnabled()
{
    return m_bCellPhoneEnabled;
}

void CPlayerPed::HandsUp()
{
	if(!m_pPed || IN_VEHICLE(m_pPed)) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	
	m_bHasHandsUp = true;
	ScriptCommand(&task_hands_up, m_dwGTAId, 20000);
}

void CPlayerPed::StopHandsUp()
{
	if(!m_pPed || IN_VEHICLE(m_pPed)) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	if(!m_bHasHandsUp) return;
	
	MATRIX4X4 mat;
	GetMatrix(&mat);
	TeleportTo(mat.pos.X, mat.pos.Y, mat.pos.Z);
	m_bHasHandsUp = false;
}

bool CPlayerPed::HasHandsUp()
{
	return m_bHasHandsUp;
}

void CPlayerPed::StartPissing()
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if(m_bPissingState)
		StopPissing();
	
	m_dwPissParticlesHandle = 0;
	
	ApplyAnimation("PISS_LOOP", "PAULNMAC", 4.0f, 1, 0, 0, 0, -1);

	ScriptCommand(&attach_particle_to_actor2, "PETROLCAN", m_dwGTAId, 
		0.0f, 0.58f, -0.08f, 0.0f, 0.01f, 0.0f, 1, &m_dwPissParticlesHandle);

	ScriptCommand(&make_particle_visible, m_dwPissParticlesHandle);

	m_bPissingState = true;
}

void CPlayerPed::StopPissing()
{
	if(!m_pPed) return;
	if(!GamePool_Ped_GetAt(m_dwGTAId)) return;
	if(!m_bPissingState) return;

	if(m_dwPissParticlesHandle)
	{
		ScriptCommand(&destroy_particle, m_dwPissParticlesHandle);
		m_dwPissParticlesHandle = 0;
	}

	MATRIX4X4 mat;
	GetMatrix(&mat);
	TeleportTo(mat.pos.X, mat.pos.Y, mat.pos.Z);

	m_bPissingState = false;
}

bool CPlayerPed::IsPissing()
{
	return m_bPissingState;
}

void CPlayerPed::ExtinguishFire()
{
	
}

void CPlayerPed::RemoveWeaponWhenEnteringVehicle()
{
	if(!m_pPed) return;
	// CPed::RemoveWeaponWhenEnteringVehicle
	(( void (*)(PED_TYPE*, int))(g_libGTASA+0x434D44+1))(m_pPed, 0);
}