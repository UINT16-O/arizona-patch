#pragma once

#include "object.h"

#define FALL_SKYDIVE		1
#define FALL_SKYDIVE_ACCEL	2
#define PARA_DECEL			3
#define PARA_FLOAT			4

#define MAX_PED_ATTACHED_OBJECT 10

struct PED_ATTACHED_OBJECT
{
	NEW_ATTACHED_OBJECT		m_info[MAX_PED_ATTACHED_OBJECT];
	CObject					*m_pObject[MAX_PED_ATTACHED_OBJECT];
	
	PED_ATTACHED_OBJECT()
	{
		for(int i = 0; i < MAX_PED_ATTACHED_OBJECT; i++)
		{
			m_pObject[i] = nullptr;
			memset(&m_info[i], 0, sizeof(m_info[i]));
		}
	}
};

class CPlayerPed : public CEntity
{
public:
	CPlayerPed();	// local
	CPlayerPed(uint8_t bytePlayerNumber, int iSkin, float fX, float fY, float fZ, float fRotation); // remote
	~CPlayerPed();

	bool IsOnGround();
	// 0.3.7
	bool IsInVehicle();
	// 0.3.7
	bool IsAPassenger();
	// 0.3.7
	VEHICLE_TYPE* GetGtaVehicle();
	// 0.3.7
	void RemoveFromVehicleAndPutAt(float fX, float fY, float fZ);
	// 0.3.7
	void SetInitialState();
	// 0.3.7
	void SetHealth(float fHealth);
	void SetArmour(float fArmour);
	// 0.3.7
	float GetHealth();
	float GetArmour();
	// 0.3.7
	void TogglePlayerControllable(bool bToggle);
	// 0.3.7
	void SetModelIndex(unsigned int uiModel);

	void SetInterior(uint8_t byteID);

	void PutDirectlyInVehicle(int iVehicleID, int iSeat);
	void EnterVehicle(int iVehicleID, bool bPassenger);
	// 0.3.7
	void ExitCurrentVehicle();
	// 0.3.7
	int GetCurrentVehicleID();
	int GetVehicleSeatID();

	// ��������
	void ClearWeapons();
	// ��������
	void DestroyFollowPedTask();
	// ��������
	void ResetDamageEntity();

	// 0.3.7
	void RestartIfWastedAt(VECTOR *vecRestart, float fRotation);
	// 0.3.7
	void SetTargetRotation(float fRotation);
	// 0.3.7
	uint8_t GetActionTrigger();
	// 0.3.7
	bool IsDead();
	uint16_t GetKeys(uint16_t *lrAnalog, uint16_t *udAnalog, uint8_t *exKeys);
	void SetKeys(uint16_t wKeys, uint16_t lrAnalog, uint16_t udAnalog);
	// 0.3.7
	void ShowMarker(uint32_t iMarkerColorID);
	// 0.3.7
	void HideMarker();
	// 0.3.7
	void SetFightingStyle(int iStyle);
	// 0.3.7
	void SetRotation(float fRotation);
	// 0.3.7
	void ApplyAnimation( char *szAnimName, char *szAnimFile, float fT, int opt1, int opt2, int opt3, int opt4, int iUnk );
	// 0.3.7
	void GetBonePosition(int iBoneID, VECTOR* vecOut);
	void GetTransformedBonePosition(int iBoneID, VECTOR* vecOut);
	void GetBoneMatrix(MATRIX4X4 *matOut, int iBoneID);
	void ClumpUpdateAnimations(float step, int flag);
	// roflan
	uint8_t FindDeathReasonAndResponsiblePlayer(PLAYERID *nPlayer);

	PED_TYPE * GetGtaActor() { return m_pPed; };
	
	void SetAttachedObject(int iSlot, NEW_ATTACHED_OBJECT attachedObjectData);
	void RemoveAttachedObjects(int iSlot);
	void RemoveAllAttachedObjects();
	bool IsHaveAttachedObject();
	bool GetObjectSlotState(int iSlot);
	void ProcessAttachedObjects();
	
	void ProcessCuffAndCarry();
	
	void SetDead();
	
	CAMERA_AIM *GetCurrentAim();
	void SetCurrentAim(CAMERA_AIM * pAim);
	uint16_t GetCameraMode();
	void SetCameraMode(uint16_t byteCamMode);
	float GetCameraExtendedZoom();
	void SetCameraZoomAndAspect(float fZoom, float fAspectRatio);
	
	void GiveWeapon(int iWeaponID, int iAmmo);
	void SetArmedWeapon(int iWeaponID);
	uint8_t GetCurrentWeapon();
	
	void SetAimZ(float fAimZ);
	float GetAimZ();
	
	WEAPON_SLOT_TYPE *GetCurrentWeaponSlot();
	WEAPON_SLOT_TYPE *FindWeaponSlot(uint32_t dwWeapon);
	void GetWeaponInfoForFire(int bLeft, VECTOR *vecBone, VECTOR *vecOut);
	VECTOR* GetCurrentWeaponFireOffset();
	
	void FireInstant();
	void ProcessBulletData(BULLET_DATA *btData);
	
	void SetStateFlags(uint32_t dwState);
	uint32_t GetStateFlags();
	
	void CheckVehicleParachute();
	
	void SetSkillLevel(int iSkillType, uint16_t wSkillLevel);
	
	void ToggleCellphone(int iOn);
	bool IsCellphoneEnabled();
	
	void HandsUp();
	void StopHandsUp();
	bool HasHandsUp();
	
	void StartPissing();
	void StopPissing();
	bool IsPissing();
	
	void ExtinguishFire();
	void RemoveWeaponWhenEnteringVehicle();
	
public:
	PED_TYPE*	m_pPed;
	uint8_t		m_bytePlayerNumber;
	uint32_t	m_dwArrow;
	
	BULLET_DATA 	m_bulletData;
	bool			m_bHaveBulletData;
	
	PED_ATTACHED_OBJECT	m_AttachedObjects;
	bool 				m_bObjectSlotUsed[MAX_PED_ATTACHED_OBJECT];
	
	int			m_iParachuteAnim;
	int			m_iParachuteState;
	uint32_t	m_dwParachuteObject;
	
	bool		m_bCellPhoneEnabled;
	bool		m_bHasHandsUp;
	bool		m_bPissingState;
	uint32_t	m_dwPissParticlesHandle;
};