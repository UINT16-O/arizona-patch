#include "main.h"
#include "game.h"
#include "net/netgame.h"

extern CGame *pGame;
extern CNetGame *pNetGame;

VEHICLE_TYPE *pLastVehicle;
uint8_t bInProcessDetachTrailer;

CVehicle::CVehicle(int iType, float fPosX, float fPosY, float fPosZ, float fRotation)
{
	MATRIX4X4 mat;
	uint32_t dwRetID = 0;

	m_pVehicle = nullptr;
	m_dwGTAId = 0;
	m_pTrailer = nullptr;

	if( (iType != TRAIN_PASSENGER_LOCO) &&
		(iType != TRAIN_FREIGHT_LOCO) &&
		(iType != TRAIN_PASSENGER) &&
		(iType != TRAIN_FREIGHT) &&
		(iType != TRAIN_TRAM))
	{
		// normal vehicle
		if(!pGame->IsModelLoaded(iType))
		{
			pGame->RequestModel(iType);
			pGame->LoadRequestedModels();
			while(!pGame->IsModelLoaded(iType)) usleep(10);
		}

		ScriptCommand(&create_car, iType, fPosX, fPosY, fPosZ, &dwRetID);
		ScriptCommand(&set_car_z_angle, dwRetID, fRotation);
		ScriptCommand(&car_gas_tank_explosion,dwRetID, 0);
		ScriptCommand(&set_car_hydraulics, dwRetID, 0);
		ScriptCommand(&toggle_car_tires_vulnerable, dwRetID, 0);

		m_pVehicle = (VEHICLE_TYPE*)GamePool_Vehicle_GetAt(dwRetID);
		m_pEntity = (ENTITY_TYPE*)m_pVehicle;
		m_dwGTAId = dwRetID;

		if(m_pVehicle)
		{
			m_pVehicle->dwDoorsLocked = 0;
			m_bIsLocked = false;

			GetMatrix(&mat);
			mat.pos.X = fPosX;
			mat.pos.Y = fPosY;
			mat.pos.Z = fPosZ;

			if( GetVehicleSubtype() != VEHICLE_SUBTYPE_BIKE && 
				GetVehicleSubtype() != VEHICLE_SUBTYPE_PUSHBIKE)
				mat.pos.Z += 0.25f;

			SetMatrix(mat);
		}
	}
	else if( (iType == TRAIN_PASSENGER_LOCO) || 
		(iType == TRAIN_FREIGHT_LOCO) ||
		(iType == TRAIN_TRAM))
	{
		// TRAIN LOCOMOTIVES

		if(iType == TRAIN_PASSENGER_LOCO) iType = 5;
		else if(iType == TRAIN_FREIGHT_LOCO) iType = 3;
		else if(iType == TRAIN_TRAM) iType = 9;

		pGame->RequestModel(TRAIN_PASSENGER_LOCO);
		pGame->RequestModel(TRAIN_PASSENGER);
		pGame->RequestModel(TRAIN_FREIGHT_LOCO);
		pGame->RequestModel(TRAIN_FREIGHT);
		pGame->RequestModel(TRAIN_TRAM);
		pGame->LoadRequestedModels();
		while(!pGame->IsModelLoaded(TRAIN_PASSENGER_LOCO)) sleep(0);
		while(!pGame->IsModelLoaded(TRAIN_PASSENGER)) sleep(0);
		while(!pGame->IsModelLoaded(TRAIN_FREIGHT_LOCO)) sleep(0);
		while(!pGame->IsModelLoaded(TRAIN_FREIGHT)) sleep(0);
		while(!pGame->IsModelLoaded(TRAIN_TRAM)) sleep(0);
		
		uint32_t dwDirection = 0;
		if(fRotation > 180.0f)
			dwDirection = 1;
		
		ScriptCommand(&create_train, iType, fPosX, fPosY, fPosZ, dwDirection, &dwRetID);

		m_pVehicle = GamePool_Vehicle_GetAt(dwRetID);
		m_pEntity = (ENTITY_TYPE *)m_pVehicle; 
		m_dwGTAId = dwRetID;
		pLastVehicle = m_pVehicle;

		GamePrepareTrain(m_pVehicle);
	}
	else if((iType == TRAIN_PASSENGER) ||
			(iType == TRAIN_FREIGHT) )
	{
		if(!pLastVehicle)
		{
			m_pEntity = 0;
			m_pVehicle = 0;
			return;
		}

		m_pVehicle = (VEHICLE_TYPE *)pLastVehicle->dwVehAttachedBottom;

		if(!m_pVehicle)
		{
			m_pEntity = 0;
			m_pVehicle = 0;
			pLastVehicle = 0;
			return;
		}

		dwRetID = GamePool_Vehicle_GetIndex(m_pVehicle);
		m_pEntity = (ENTITY_TYPE *)m_pVehicle;
		m_dwGTAId = dwRetID;
		pLastVehicle = m_pVehicle;
	}

	m_byteObjectiveVehicle = 0;
	m_bSpecialMarkerEnabled = false;
	m_bDoorsLocked = false;
	m_dwMarkerID = 0;
	m_bIsInvulnerable = false;
}

CVehicle::~CVehicle()
{
	m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

	if(m_pVehicle)
	{
		if(m_dwMarkerID)
		{
			ScriptCommand(&disable_marker, m_dwMarkerID);
			m_dwMarkerID = 0;
		}

		RemoveEveryoneFromVehicle();

		if(m_pTrailer)
		{
			bInProcessDetachTrailer = 1;
			ScriptCommand(&detach_trailer_from_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
			m_pTrailer = NULL;
		}

		if( m_pVehicle->entity.nModelIndex == TRAIN_PASSENGER_LOCO ||
			m_pVehicle->entity.nModelIndex == TRAIN_FREIGHT_LOCO )
		{
			ScriptCommand(&destroy_train, m_dwGTAId);
		}
		else
		{
			int nModelIndex = m_pVehicle->entity.nModelIndex;
			ScriptCommand(&destroy_car, m_dwGTAId);

			if( !GetModelRefCounts(nModelIndex) &&
				pGame->IsModelLoaded(nModelIndex))
			{
				pGame->RemoveModel(nModelIndex, 1);
			}
		}
	}
}

void CVehicle::LinkToInterior(int iInterior)
{
	if(GamePool_Vehicle_GetAt(m_dwGTAId)) 
	{
		ScriptCommand(&link_vehicle_to_interior, m_dwGTAId, iInterior);
	}
}

void CVehicle::SetColor(int iColor1, int iColor2)
{
	if(m_pVehicle)
	{
		if(GamePool_Vehicle_GetAt(m_dwGTAId))
		{
			m_pVehicle->byteColor1 = (uint8_t)iColor1;
			m_pVehicle->byteColor2 = (uint8_t)iColor2;
		}
	}

	m_byteColor1 = (uint8_t)iColor1;
	m_byteColor2 = (uint8_t)iColor2;
	m_bColorChanged = true;
}

void CVehicle::SetHealth(float fHealth)
{
	if(m_pVehicle)
	{
		m_pVehicle->fHealth = fHealth;
	}
}

float CVehicle::GetHealth()
{
	if(m_pVehicle) return m_pVehicle->fHealth;
	else return 0.0f;
}

// 0.3.7
void CVehicle::SetInvulnerable(bool bInv)
{
	if(!m_pVehicle) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	if(m_pVehicle->entity.vtable == g_libGTASA+0x5C7358) return;

	if(bInv) 
	{
		ScriptCommand(&set_car_immunities, m_dwGTAId, 1,1,1,1,1);
		ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 0);
		m_bIsInvulnerable = true;
	} 
	else 
	{ 
		ScriptCommand(&set_car_immunities, m_dwGTAId, 0,0,0,0,0);
		ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 1);
		m_bIsInvulnerable = false;
	}
}

// 0.3.7
bool CVehicle::IsDriverLocalPlayer()
{
	if(m_pVehicle)
	{
		if((PED_TYPE*)m_pVehicle->pDriver == GamePool_FindPlayerPed())
			return true;
	}

	return false;
}

// 0.3.7
bool CVehicle::HasSunk()
{
	if(!m_pVehicle) return false;
	return ScriptCommand(&has_car_sunk, m_dwGTAId);
}

bool CVehicle::HasADriver()
{	
	if(!m_pVehicle) return false;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return false;

	if(m_pVehicle->pDriver && IN_VEHICLE(m_pVehicle->pDriver))
		return true;

	return false;
}

void CVehicle::RemoveEveryoneFromVehicle()
{
	if(!m_pVehicle) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

	float fPosX = m_pVehicle->entity.mat->pos.X;
	float fPosY = m_pVehicle->entity.mat->pos.Y;
	float fPosZ = m_pVehicle->entity.mat->pos.Z;

	int iPlayerID = 0;
	if(m_pVehicle->pDriver)
	{
		iPlayerID = GamePool_Ped_GetIndex( m_pVehicle->pDriver );
		ScriptCommand(&remove_actor_from_car_and_put_at, iPlayerID, fPosX, fPosY, fPosZ + 2.0f);
	}

	for(int i = 0; i<7; i++)
	{
		if(m_pVehicle->pPassengers[i] != nullptr)
		{
			iPlayerID = GamePool_Ped_GetIndex( m_pVehicle->pPassengers[i] );
			ScriptCommand(&remove_actor_from_car_and_put_at, iPlayerID, fPosX, fPosY, fPosZ + 2.0f);
		}
	}
}

// 0.3.7
bool CVehicle::IsOccupied()
{
	if(m_pVehicle)
	{
		if(m_pVehicle->pDriver) return true;
		if(m_pVehicle->pPassengers[0]) return true;
		if(m_pVehicle->pPassengers[1]) return true;
		if(m_pVehicle->pPassengers[2]) return true;
		if(m_pVehicle->pPassengers[3]) return true;
		if(m_pVehicle->pPassengers[4]) return true;
		if(m_pVehicle->pPassengers[5]) return true;
		if(m_pVehicle->pPassengers[6]) return true;
	}

	return false;
}

void CVehicle::ProcessMarkers()
{
	if(!m_pVehicle) return;

	if(m_byteObjectiveVehicle)
	{
		if(!m_bSpecialMarkerEnabled)
		{
			if(m_dwMarkerID)
			{
				ScriptCommand(&disable_marker, m_dwMarkerID);
				m_dwMarkerID = 0;
			}

			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 3, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1006);
			ScriptCommand(&show_on_radar, m_dwMarkerID, 3);
			m_bSpecialMarkerEnabled = true;
		}

		return;
	}

	if(m_byteObjectiveVehicle && m_bSpecialMarkerEnabled)
	{
		if(m_dwMarkerID)
		{
			ScriptCommand(&disable_marker, m_dwMarkerID);
			m_bSpecialMarkerEnabled = false;
			m_dwMarkerID = 0;
		}
	}

	if(GetDistanceFromLocalPlayerPed() < 200.0f && !IsOccupied())
	{
		if(!m_dwMarkerID)
		{
			// show
			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 2, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1004);
		}
	}

	else if(IsOccupied() || GetDistanceFromLocalPlayerPed() >= 200.0f)
	{
		// remove
		if(m_dwMarkerID)
		{
			ScriptCommand(&disable_marker, m_dwMarkerID);
			m_dwMarkerID = 0;
		}
	}
}

void CVehicle::SetDoorState(int iState)
{
	if(!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	if(iState == 1) 
	{
		m_pVehicle->dwDoorsLocked = 2;
		m_bDoorsLocked = true;
	} 
	else 
	{
		m_pVehicle->dwDoorsLocked = 0;
		m_bDoorsLocked = false;
	}
}

void CVehicle::ApplyEngineState(bool bState)
{
	if(!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

	if(!bState) {
		m_bEngineState = false;
		m_pVehicle->byteFlags &= 0xEF;
	} else {
		m_bEngineState = true;
		m_pVehicle->byteFlags |= 0x10;
	}
}

bool CVehicle::AreEngineEnabled()
{
	return m_bEngineState;
}

void CVehicle::ApplyLightState(int iState)
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

	if(iState == 1) {
		m_bLightsState = true;
		ScriptCommand(&force_car_lights, m_dwGTAId, 2);
	} else {
		m_bLightsState = false;
		ScriptCommand(&force_car_lights, m_dwGTAId, 0);
	}
}

bool CVehicle::AreLightsEnabled()
{
	return m_bLightsState;
}

void CVehicle::SetComponentOpenState(int iState, int iCompID)
{
	if(!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	if(iState == 1) {
		ScriptCommand(&open_car_component, m_dwGTAId, iCompID);
	} else {
		ScriptCommand(&set_car_component_rotate, m_dwGTAId, iCompID, 0.0f);
	}
}

void CVehicle::OpenWindow(uint8_t byteWindow)
{
	
}

void CVehicle::CloseWindow(uint8_t byteWindow)
{
	
}

void CVehicle::SetSirenOn(uint8_t byteSiren)
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

	if (byteSiren == 1) {
		m_pVehicle->byteSirenOn |= 0x80;
	} else {
		m_pVehicle->byteSirenOn &= 0x7F;
	}
}

uint8_t CVehicle::IsSirenOn()
{
	if (!m_pVehicle) return 0;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return 0;

	if (m_pVehicle->byteSirenOn & 0x80)
		return 1;

	return 0;
}

void CVehicle::SetDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage)
{
	
}

void CVehicle::SetTireDamageStatus(uint8_t byteTire)
{
	
}

void CVehicle::AttachTrailer()
{
	if (m_pTrailer)
		ScriptCommand(&put_trailer_on_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
	
	bInProcessDetachTrailer = 0;
}

void CVehicle::DetachTrailer()
{
	if (m_pTrailer)
		ScriptCommand(&detach_trailer_from_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
	
	bInProcessDetachTrailer = 1;
}

void CVehicle::SetTrailer(CVehicle *pTrailer)
{
	m_pTrailer = pTrailer;
}

CVehicle* CVehicle::GetTrailer()
{
	if (!m_pVehicle) return NULL;

	// Try to find associated trailer
	uint32_t dwTrailerGTAPtr = m_pVehicle->dwTrailer;

	if(pNetGame && dwTrailerGTAPtr)
	{
		CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
		VEHICLEID TrailerID = (VEHICLEID)pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE*)dwTrailerGTAPtr);
		if(TrailerID < MAX_VEHICLES && pVehiclePool->GetSlotState(TrailerID))
		{
			return pVehiclePool->GetAt(TrailerID);
		}
	}

	return NULL;
}

void CVehicle::SetTrainSpeed(float fSpeed)
{
	m_pVehicle->fTrainSpeed = fSpeed;
}

float CVehicle::GetTrainSpeed()
{
	return m_pVehicle->fTrainSpeed;
}

int CVehicle::GetBikeLean()
{
	return 0;
}

void CVehicle::SetHydraThrusters(uint32_t dwDirection)
{
	if(m_pVehicle)
		m_pVehicle->dwHydraThrusters = dwDirection;
}

uint32_t CVehicle::GetHydraThrusters()
{
	if(!m_pVehicle) return 0;
	return m_pVehicle->dwHydraThrusters;
}

void CVehicle::AddComponent(int iComponent)
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	uint32_t v = 0; // handle
	if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		pGame->RequestModel(iComponent);
		pGame->LoadRequestedModels();
		ScriptCommand(&request_car_component, iComponent);
		
		if(ScriptCommand(&is_component_available, iComponent))
			ScriptCommand(&add_car_component, m_dwGTAId, iComponent, &v);
	}
}

void CVehicle::RemoveComponent(int iComponent)
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	ScriptCommand(&remove_component, m_dwGTAId, iComponent);
}

void CVehicle::SetPaintJob(int iPaintJob)
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		if(iPaintJob > 0 || iPaintJob < 2)
			ScriptCommand(&change_car_skin, m_dwGTAId, iPaintJob);
	}
}

unsigned int CVehicle::GetVehicleSubtype()
{
	if(m_pVehicle)
	{
		if(m_pVehicle->entity.vtable == g_libGTASA+0x5CC9F0) // 0x871120
		{
			return VEHICLE_SUBTYPE_CAR;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCD48) // 0x8721A0
		{
			return VEHICLE_SUBTYPE_BOAT;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCB18) // 0x871360
		{
			return VEHICLE_SUBTYPE_BIKE;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CD0B0) // 0x871948
		{
			return VEHICLE_SUBTYPE_PLANE;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCE60) // 0x871680
		{
			return VEHICLE_SUBTYPE_HELI;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCC30) // 0x871528
		{
			return VEHICLE_SUBTYPE_PUSHBIKE;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CD428) // 0x872370
		{
			return VEHICLE_SUBTYPE_TRAIN;
		}
	}

	return 0;
}

bool CVehicle::IsRCVehicle()
{
	if (!m_pVehicle) return false;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return false;
	
	if( m_pVehicle->entity.nModelIndex == 441 || 
		m_pVehicle->entity.nModelIndex == 464 ||
		m_pVehicle->entity.nModelIndex == 465 || 
		m_pVehicle->entity.nModelIndex == 594 ||
		m_pVehicle->entity.nModelIndex == 501 || 
		m_pVehicle->entity.nModelIndex == 564 )
		return true;

	return false;
}

bool CVehicle::IsATrainPart()
{
	int nModel;
	if(m_pVehicle) {
		nModel = m_pVehicle->entity.nModelIndex;
		if(nModel == TRAIN_PASSENGER_LOCO) return true;
		if(nModel == TRAIN_PASSENGER) return true;
		if(nModel == TRAIN_FREIGHT_LOCO) return true;
		if(nModel == TRAIN_FREIGHT) return true;
		if(nModel == TRAIN_TRAM) return true;
	}
	return false;
}

bool CVehicle::IsATowTruck()
{
	if (!m_pVehicle) return false;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return false;
	
	if( m_pVehicle->entity.nModelIndex == 525 )
		return true;

	return false;
}

bool CVehicle::IsATrailer()
{
	if (!m_pVehicle) return false;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return false;
	
	if( m_pVehicle->entity.nModelIndex == 435 || 
		m_pVehicle->entity.nModelIndex == 450 )
		return true;

	return false;
}

bool CVehicle::VerifyInstance()
{
	if(GamePool_Vehicle_GetAt(m_dwGTAId)) {
		return true;
	}
	return false;
}
