#pragma once

class CVehicle : public CEntity
{
public:
	CVehicle(int iType, float fPosX, float fPosY, float fPosZ, float fRotation = 0.0f);
	~CVehicle();

	void LinkToInterior(int iInterior);
	void SetColor(int iColor1, int iColor2);

	void SetHealth(float fHealth);
	float GetHealth();

	// 0.3.7
	bool IsOccupied();

	// 0.3.7
	void SetInvulnerable(bool bInv);
	// 0.3.7
	bool IsDriverLocalPlayer();
	// 0.3.7
	bool HasSunk();
	bool HasADriver();

	void ProcessMarkers();

	void RemoveEveryoneFromVehicle();

	void SetDoorState(int iState);
	void ApplyEngineState(bool bState);
	bool AreEngineEnabled();
	void ApplyLightState(int iState);
	bool AreLightsEnabled();
	void SetComponentOpenState(int iState, int iCompID);
	void OpenWindow(uint8_t byteWindow);
	void CloseWindow(uint8_t byteWindow);
	void SetSirenOn(uint8_t byteSiren);
	uint8_t IsSirenOn();
	
	void SetDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage);
	void SetTireDamageStatus(uint8_t byteTire);
	
	void AttachTrailer();
	void DetachTrailer();
	void SetTrailer(CVehicle *pTrailer);
	CVehicle* GetTrailer();
	
	void SetTrainSpeed(float fSpeed);
	float GetTrainSpeed();
	
	int GetBikeLean();
	
	void SetHydraThrusters(uint32_t dwDirection);
	uint32_t GetHydraThrusters();
	
	void AddComponent(int iComponent);
	void RemoveComponent(int iComponent);
	void SetPaintJob(int iPaintJob);
	
	unsigned int GetVehicleSubtype();
	bool IsRCVehicle();
	bool IsATrainPart();
	bool IsATowTruck();
	bool IsATrailer();
	
	bool VerifyInstance();

public:
	VEHICLE_TYPE	*m_pVehicle;
	bool 			m_bIsLocked;
	CVehicle		*m_pTrailer;
	uint32_t		m_dwMarkerID;
	bool 			m_bIsInvulnerable;
	bool 			m_bDoorsLocked;
	uint8_t			m_byteObjectiveVehicle; // Is this a special objective vehicle? 0/1
	uint8_t			m_bSpecialMarkerEnabled;
	
	bool			m_bEngineState;
	bool			m_bLightsState;

	uint8_t			m_byteColor1;
	uint8_t			m_byteColor2;
	bool 			m_bColorChanged;
};
