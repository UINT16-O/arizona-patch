#include "main.h"
#include "ui.h"
#include "imguirenderer.h"

extern UI *pUI;

bool ImGuiRenderer::processInlineHexColor(const char* start, const char* end, ImVec4& color)
{
	const int hexCount = (int)(end-start);
	if(hexCount == 6 || hexCount == 8)
	{
		char hex[9];
		strncpy(hex, start, hexCount);
		hex[hexCount] = 0;

		unsigned int hexColor = 0;
		if(sscanf(hex, "%x", &hexColor)	> 0)
		{
			color.x = static_cast< float >((hexColor & 0x00FF0000) >> 16) / 255.0f;
			color.y = static_cast< float >((hexColor & 0x0000FF00) >> 8) / 255.0f;
			color.z = static_cast< float >((hexColor & 0x000000FF)) / 255.0f;
			color.w = 1.0f;

			if(hexCount == 8)
				color.w = static_cast< float >((hexColor & 0xFF000000) >> 24) / 255.0f;

			return true;
		}
	}

	return false;
}

void ImGuiRenderer::drawText(const char* fmt, ...)
{
	char tempStr[4096];

	va_list argPtr;
	va_start(argPtr, fmt);
	vsnprintf(tempStr, sizeof(tempStr), fmt, argPtr);
	va_end(argPtr);
	tempStr[sizeof(tempStr) - 1] = '\0';

	bool pushedColorStyle = false;
	const char* textStart = tempStr;
	const char* textCur = tempStr;
	while(textCur < (tempStr + sizeof(tempStr)) && *textCur != '\0')
	{
		if (*textCur == '{')
		{
			// Print accumulated text
			if (textCur != textStart)
			{
				ImGui::TextUnformatted(textStart, textCur);
				ImGui::SameLine(0.0f, 0.0f);
			}

			// Process color code
			const char* colorStart = textCur + 1;
			do
			{
				++textCur;
			} while (*textCur != '\0' && *textCur != '}');

			// Change color
			if (pushedColorStyle)
			{
				ImGui::PopStyleColor();
				pushedColorStyle = false;
			}

			ImVec4 textColor;
			if (processInlineHexColor(colorStart, textCur, textColor))
			{
				ImGui::PushStyleColor(ImGuiCol_Text, textColor);
				pushedColorStyle = true;
			}

			textStart = textCur + 1;
		}
		else if (*textCur == '\n')
		{
			// Print accumulated text an go to next line
			ImGui::TextUnformatted(textStart, textCur);
			textStart = textCur + 1;
		}

		++textCur;
	}

	if (textCur != textStart)
		ImGui::TextUnformatted(textStart, textCur);
	else
		ImGui::NewLine();

	if(pushedColorStyle)
		ImGui::PopStyleColor();
}

void ImGuiRenderer::drawText(ImFont *pFont, ImVec2 pos, ImColor col, bool bOutline, const char* szStr, const float font_size)
{
	if(!pFont) pFont = pUI->GetFont();
	
	char tempStr[4096];

	ImVec2 vecPos = pos;
	
	strcpy(tempStr, szStr);
	tempStr[sizeof(tempStr) - 1] = '\0';

	bool pushedColorStyle = false;
	const char* textStart = tempStr;
	const char* textCur = tempStr;
	while(textCur < (tempStr + sizeof(tempStr)) && *textCur != '\0')
	{
		if (*textCur == '{')
		{
			// Print accumulated text
			if (textCur != textStart)
			{
				pUI->RenderText(pFont, vecPos, col, bOutline, textStart, textCur, font_size);
				vecPos.x += (pFont->CalcTextSizeA(font_size, FLT_MAX, -1.0f, textStart, textCur).x+0.95f);
			}

			// Process color code
			const char* colorStart = textCur + 1;
			do
			{
				++textCur;
			} while (*textCur != '\0' && *textCur != '}');

			// Change color
			if (pushedColorStyle)
				pushedColorStyle = false;

			ImVec4 textColor;
			if (ImGuiRenderer::processInlineHexColor(colorStart, textCur, textColor))
			{
				col = textColor;
				pushedColorStyle = true;
			}

			textStart = textCur + 1;
		}
		else if (*textCur == '\n')
		{
			pUI->RenderText(pFont, vecPos, col, bOutline, textStart, textCur, font_size);
			vecPos.x = pos.x;
			vecPos.y += font_size;
			textStart = textCur + 1;
		}

		++textCur;
	}

	if (textCur != textStart)
	{
		pUI->RenderText(pFont, vecPos, col, bOutline, textStart, textCur, font_size);
		vecPos.x += (pFont->CalcTextSizeA(font_size, FLT_MAX, -1.0f, textStart, textCur).x+0.95f);
	}
	else
		vecPos.y += font_size;
}

void ImGuiRenderer::drawText(ImVec2 pos, char* utf8string, uint32_t dwColor)
{
	uint16_t linesCount = 0;
	std::string strUtf8 = utf8string;
	int size = strUtf8.length();
	std::string color;

	for(uint32_t i = 0; i < size; i++)
	{
		if(i+7 < strUtf8.length())
		{
			if(strUtf8[i] == '{' && strUtf8[i+7] == '}' )
			{
				color = strUtf8.substr(i, 7+1);
			}
		}
		if(strUtf8[i] == '\n')
		{
			linesCount++;
			if(i+1 < strUtf8.length() && !color.empty())
			{
				strUtf8.insert(i+1 , color);
				size += color.length();
				color.clear();
			}
		}
		if(strUtf8[i] == '\t')
		{
			strUtf8.replace(i, 1, " ");
		}
	}
	pos.y += pUI->GetFontSize()*(linesCount / 2);
	if(linesCount)
	{
		uint16_t curLine = 0;
		uint16_t curIt = 0;
		for(uint32_t i = 0; i < strUtf8.length(); i++)
		{
			if(strUtf8[i] == '\n')
			{
				if(strUtf8[curIt] == '\n' )
				{
					curIt++;
				}
				ImVec2 _pos = pos;
				_pos.x -= calculateTextSize((char*)strUtf8.substr(curIt, i-curIt).c_str()).x / 2;
				_pos.y -= ( pUI->GetFontSize()*(linesCount - curLine) );
				drawText(pUI->GetFont(), _pos, __builtin_bswap32(dwColor), false, (char*)strUtf8.substr(curIt, i-curIt).c_str(), pUI->GetFontSize());
				curIt = i;
				curLine++;
			}
		}
		if(strUtf8[curIt] == '\n')
		{
			curIt++;
		}
		if(strUtf8[curIt] != '\0')
		{
			ImVec2 _pos = pos;
			_pos.x -= calculateTextSize((char*)strUtf8.substr(curIt, strUtf8.size()-curIt).c_str()).x / 2;
			_pos.y -= ( pUI->GetFontSize()*(linesCount - curLine) );
			drawText(pUI->GetFont(), _pos, __builtin_bswap32(dwColor), false, (char*)strUtf8.substr(curIt, strUtf8.length()-curIt).c_str(), pUI->GetFontSize());
		}
	}
	else
	{
		pos.x -= calculateTextSize((char*)strUtf8.c_str()).x / 2;
		drawText(pUI->GetFont(), pos, __builtin_bswap32(dwColor), false, (char*)strUtf8.c_str());
	}
}

ImVec2 ImGuiRenderer::calculateTextSize(ImFont *pFont, char* szStr, float font_size)
{
	if(!szStr) return ImVec2(0, 0);
	if(!pFont) pFont = pUI->GetFont();
	
	char szNonColored[2048+1];
	int iNonColoredMsgLen = 0;

	for(int pos = 0; pos < strlen(szStr) && szStr[pos] != '\0'; pos++)
	{
		if(pos+7 < strlen(szStr))
		{
			if(szStr[pos] == '{' && szStr[pos+7] == '}')
			{
				pos += 7;
				continue;
			}
		}

		szNonColored[iNonColoredMsgLen] = szStr[pos];
		iNonColoredMsgLen++;
	}

	szNonColored[iNonColoredMsgLen] = 0;
	
	ImVec2 text_size;
	text_size = pFont->CalcTextSizeA(font_size, FLT_MAX, 0.0f, szNonColored);
	text_size.x = (float)(int)(text_size.x + 0.95f);
	return text_size;
}

ImVec2 ImGuiRenderer::calculateTextSize(char* szStr)
{
	if(!szStr) return ImVec2(0, 0);
	
	char szNonColored[2048+1];
	int iNonColoredMsgLen = 0;

	for(int pos = 0; pos < strlen(szStr) && szStr[pos] != '\0'; pos++)
	{
		if(pos+7 < strlen(szStr))
		{
			if(szStr[pos] == '{' && szStr[pos+7] == '}')
			{
				pos += 7;
				continue;
			}
		}

		szNonColored[iNonColoredMsgLen] = szStr[pos];
		iNonColoredMsgLen++;
	}

	szNonColored[iNonColoredMsgLen] = 0;
	
	return ImGui::CalcTextSize(szNonColored);
}

std::string ImGuiRenderer::removeColorTags(std::string line)
{
	std::string string;
	for(uint32_t it = 0; it < line.size(); it++)
	{
		if(it+7 < line.size())
		{
			if(line[it] == '{' && line[it+7] == '}')
			{
				it += 7;
				continue;
			}
		}
		string.push_back(line[it]);
	}
	return string;
}