#pragma once
#include "../vendor/imgui/imgui.h"

class ImGuiRenderer
{
	friend class UI;
public:
	static bool processInlineHexColor(const char* start, const char* end, ImVec4& color);
	static void drawText(const char* fmt, ...);
	static void drawText(ImFont *pFont, ImVec2 pos, ImColor col, bool bOutline, const char* szStr, const float font_size = 0.0f);
	static void drawText(ImVec2 pos, char* utf8string, uint32_t dwColor);
	
	static ImVec2 calculateTextSize(ImFont *pFont, char* szStr, float font_size = 0.0f);
	static ImVec2 calculateTextSize(char* szStr);
	static std::string removeColorTags(std::string line);
};