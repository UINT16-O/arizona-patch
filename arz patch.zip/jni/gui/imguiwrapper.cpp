#include "main.h"
#include "ui.h"
#include "game/game.h"
#include "game/RW/RenderWare.h"

extern UI *pUI;
extern CGame *pGame;

RwRaster* ImGuiWrapper::m_fontRaster;
RwIm2DVertex* ImGuiWrapper::m_vertexBuffer;
unsigned int ImGuiWrapper::m_vertexBufferSize;
ImVec4 ImGuiWrapper::m_scissorRect;
ImFont* ImGuiWrapper::m_font;
float ImGuiWrapper::m_fontSize;

ImGuiWrapper::ImGuiWrapper()
{
	
}

bool ImGuiWrapper::initialize(const char *fontname, float fontsize)
{
	m_fontRaster = nullptr;
	m_vertexBuffer = nullptr;
	m_vertexBufferSize = 5000;

	ImGuiIO &io = ImGui::GetIO();
	
	char path[0xFF];
	sprintf(path, "%sfonts/%s", pGame->GetDataDirectory(), fontname);
	
	const ImWchar *ranges = io.Fonts->GetGlyphRangesCyrillic();
	m_font = io.Fonts->AddFontFromFileTTF(path, fontsize, nullptr, ranges);
	if(m_font) {
		m_fontSize = fontsize;
		createFontTexture();
		return true;
	}
	return false;
}

ImFont* ImGuiWrapper::loadFont(const char *fontname, float fontsize)
{
	ImGuiIO &io = ImGui::GetIO();
	
	char path[0xFF];
	sprintf(path, "%sfonts/%s.ttf", pGame->GetDataDirectory(), fontname);
	
	const ImWchar *ranges = io.Fonts->GetGlyphRangesCyrillic();
	return io.Fonts->AddFontFromFileTTF(path, fontsize, nullptr, ranges);
}

bool ImGuiWrapper::createFontTexture()
{
	if(m_fontRaster)
		m_fontRaster = nullptr;
	
	// Build texture atlas
	ImGuiIO &io = ImGui::GetIO();
	unsigned char* pxs;
	int width, height, bytes_per_pixel;
	io.Fonts->GetTexDataAsRGBA32(&pxs, &width, &height, &bytes_per_pixel);

	RwImage *font_img = RwImageCreate(width, height, bytes_per_pixel*8);
	RwImageAllocatePixels(font_img);

	RwUInt8 *pixels = font_img->cpPixels;
	for(int y = 0; y < font_img->height; y++)
	{
		memcpy((unsigned char*)pixels, pxs + font_img->stride * y, font_img->stride);
		pixels += font_img->stride;
	}

	RwInt32 w, h, d, flags;
	RwImageFindRasterFormat(font_img, rwRASTERTYPETEXTURE, &w, &h, &d, &flags);
	m_fontRaster = RwRasterCreate(w, h, d, flags);
	m_fontRaster = RwRasterSetFromImage(m_fontRaster, font_img);
	RwImageDestroy(font_img);

	io.Fonts->TexID = (ImTextureID*)m_fontRaster;
	return true;
}

void ImGuiWrapper::destroyFontTexture()
{
	ImGuiIO &io = ImGui::GetIO();
	
	if(m_fontRaster)
	{
		RwRasterDestroy(m_fontRaster);
		m_fontRaster = nullptr;
		io.Fonts->TexID = nullptr;
		
		// destroy vertex buffer
		if(m_vertexBuffer) { delete m_vertexBuffer; m_vertexBuffer = nullptr; }
	}
}

void ImGuiWrapper::shutdown()
{
	ImGuiIO &io = ImGui::GetIO();
	
	if(m_fontRaster)
	{
		RwRasterDestroy(m_fontRaster);
		m_fontRaster = nullptr;
		io.Fonts->TexID = nullptr;
		
		// destroy vertex buffer
		if(m_vertexBuffer) { delete m_vertexBuffer; m_vertexBuffer = nullptr; }
	}
}

void ImGuiWrapper::renderDrawData(ImDrawData* draw_data)
{
	const RwReal nearScreenZ = getNearScreenZ();
	const RwReal recipNearClip = getRecipNearClip();

	if(!m_vertexBuffer || m_vertexBufferSize < draw_data->TotalVtxCount)
	{
		if(m_vertexBuffer) { delete m_vertexBuffer; m_vertexBuffer = nullptr; }
		m_vertexBufferSize = draw_data->TotalVtxCount + 5000;
		m_vertexBuffer = new RwIm2DVertex[m_vertexBufferSize];
		if(!m_vertexBuffer) return;
	}

	RwIm2DVertex* vtx_dst = m_vertexBuffer;
	int vtx_offset = 0;

	for(int n = 0; n < draw_data->CmdListsCount; n++)
	{
		const ImDrawList* cmd_list = draw_data->CmdLists[n];
        const ImDrawVert* vtx_src = cmd_list->VtxBuffer.Data;
        const ImDrawIdx* idx_src = cmd_list->IdxBuffer.Data;

        for(int i = 0; i < cmd_list->VtxBuffer.Size; i++)
        {
        	RwIm2DVertexSetScreenX(vtx_dst, vtx_src->pos.x);
        	RwIm2DVertexSetScreenY(vtx_dst, vtx_src->pos.y);
        	RwIm2DVertexSetScreenZ(vtx_dst, nearScreenZ);
        	RwIm2DVertexSetRecipCameraZ(vtx_dst, recipNearClip);
        	vtx_dst->emissiveColor = vtx_src->col;
        	RwIm2DVertexSetU(vtx_dst, vtx_src->uv.x, recipCameraZ);
        	RwIm2DVertexSetV(vtx_dst, vtx_src->uv.y, recipCameraZ);

        	vtx_dst++;
        	vtx_src++;
        }

        const ImDrawIdx* idx_buffer = cmd_list->IdxBuffer.Data;
        for(int cmd_i = 0; cmd_i < cmd_list->CmdBuffer.Size; cmd_i++)
        {
        	const ImDrawCmd* pcmd = &cmd_list->CmdBuffer[cmd_i];

        	if(pcmd->UserCallback)
        	{
        		pcmd->UserCallback(cmd_list, pcmd);
        	}
        	else
        	{
        		m_scissorRect.x = pcmd->ClipRect.x;
        		m_scissorRect.y = pcmd->ClipRect.w;
        		m_scissorRect.z = pcmd->ClipRect.z;
        		m_scissorRect.w = pcmd->ClipRect.y;
        		SetScissorRect((void*)&m_scissorRect);

        		RwRenderStateSet(rwRENDERSTATEZTESTENABLE, (void*)0);
  				RwRenderStateSet(rwRENDERSTATEZWRITEENABLE, (void*)0);
  				RwRenderStateSet(rwRENDERSTATEVERTEXALPHAENABLE, (void*)1);
  				RwRenderStateSet(rwRENDERSTATESRCBLEND, (void*)rwBLENDSRCALPHA);
  				RwRenderStateSet(rwRENDERSTATEDESTBLEND, (void*)rwBLENDINVSRCALPHA);
  				RwRenderStateSet(rwRENDERSTATEFOGENABLE, (void*)0);
  				RwRenderStateSet(rwRENDERSTATECULLMODE, (void*)rwCULLMODECULLNONE);
  				RwRenderStateSet(rwRENDERSTATEBORDERCOLOR, (void*)0);
  				RwRenderStateSet(rwRENDERSTATEALPHATESTFUNCTION, (void*)rwALPHATESTFUNCTIONGREATER);
  				RwRenderStateSet(rwRENDERSTATEALPHATESTFUNCTIONREF, (void*)2);
  				RwRenderStateSet(rwRENDERSTATETEXTUREFILTER, (void*)rwFILTERLINEAR);
  				RwRenderStateSet(rwRENDERSTATETEXTUREADDRESS, (void*)rwTEXTUREADDRESSCLAMP);
  				RwRenderStateSet(rwRENDERSTATETEXTURERASTER, (void*)pcmd->TextureId);
  				RwIm2DRenderIndexedPrimitive(rwPRIMTYPETRILIST, 
  					&m_vertexBuffer[vtx_offset], (RwInt32)cmd_list->VtxBuffer.Size,
  					(RwImVertexIndex*)idx_buffer, pcmd->ElemCount);
  				RwRenderStateSet(rwRENDERSTATETEXTURERASTER, (void*)0);

  				m_scissorRect.x = 0;
        		m_scissorRect.y = 0;
        		m_scissorRect.z = 0;
        		m_scissorRect.w = 0;
        		SetScissorRect((void*)&m_scissorRect);
        	}

        	idx_buffer += pcmd->ElemCount;
        }
        vtx_offset += cmd_list->VtxBuffer.Size;
	}

	return;
}