#pragma once
#include "../vendor/imgui/imgui.h"
#include "game/RW/RenderWare.h"

class ImGuiWrapper
{
	friend class UI;
private:
	static RwRaster *m_fontRaster;
	static RwIm2DVertex *m_vertexBuffer;
	static unsigned int m_vertexBufferSize;
	static ImVec4 m_scissorRect;
	static ImFont* m_font;
	static float m_fontSize;
	
public:
	ImGuiWrapper();
	static bool initialize(const char *fontname, float fontsize);
	static ImFont* loadFont(const char *fontname, float fontsize);
	static bool createFontTexture();
	static void destroyFontTexture();
	static void shutdown();
	static void renderDrawData(ImDrawData* draw_data = nullptr);
	static ImFont* getFont() { return m_font; }
	static float getFontSize() { return m_fontSize; }
};