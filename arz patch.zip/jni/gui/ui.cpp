#include "main.h"
#include "ui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "game/RW/RenderWare.h"
#include "chat.h"
#include "spawnscreen.h"
#include "playertags.h"
#include "dialog.h"
#include "keyboard.h"
#include "settings.h"
#include "scoreboard.h"
#include "buttonpanel.h"
#include "extButtonPanel.h"

#include "str_obfuscator_no_template.hpp"

// voice
#include "../voice/MicroIcon.h"
#include "../voice/SpeakerList.h"
#include "../voice/include/util/Render.h"

#include <time.h>
#include <ctime>
#include <stdio.h>
#include <string.h>

extern CChat *pChat;
extern CSpawnScreen *pSpawnScreen;
extern CPlayerTags *pPlayerTags;
extern CDialog *pDialog;
extern CScoreBoard *pScoreBoard;
extern CKeyBoard *pKeyBoard;
extern CSettings *pSettings;
extern CNetGame *pNetGame;
extern CGame *pGame;

extern ButtonPanel *pButtonPanel;
extern ExtButtonPanel *pExtButtonPanel;

bool bShowDebugLabels = false;
extern bool g_bNeedClearMousePos;

UI::UI()
{
	ImGuiIO &io = ImGui::GetIO();

	// scale
	m_vecScale.x = io.DisplaySize.x * 1/1920;
	m_vecScale.y = io.DisplaySize.y * 1/1080;

	// mouse/touch
	m_bMousePressed = false;
	m_vecMousePos = ImVec2(0, 0);

	// setup font
	m_font = ImGuiWrapper::getFont();
	m_fontSize = ImGuiWrapper::getFontSize();
	
		// voice
	for(const auto& deviceInitCallback : Render::deviceInitCallbacks)
    {
        if(deviceInitCallback != nullptr) 
			deviceInitCallback();
    }
}

UI::~UI()
{
		// voice 
	for(const auto& deviceFreeCallback : Render::deviceFreeCallbacks)
	{
		if(deviceFreeCallback != nullptr) 
			deviceFreeCallback();
	}
	
	ImGuiWrapper::shutdown();
	ImGui::DestroyContext();
}

void UI::Render()
{
	ImGuiIO& io = ImGui::GetIO();

	ImGui::NewFrame();
	
			// voice
	if(pNetGame)
	
		if(pDialog->m_bIsActive || pScoreBoard->m_bToggle)
		{
			SpeakerList::Hide();
			MicroIcon::Hide();
		}
		else 
		{
			if(MicroIcon::hasShowed)
			{
				SpeakerList::Show();
				MicroIcon::Show();
			}
		}

		for(const auto& renderCallback : Render::renderCallbacks)
		{
			if(renderCallback != nullptr) 
				renderCallback();
		}
	
	
	
	if(pPlayerTags) pPlayerTags->Render();
	
	if(pNetGame && pNetGame->GetLabelPool())
		pNetGame->GetLabelPool()->Draw();

	if(pNetGame && pNetGame->GetChatBubblePool())
		pNetGame->GetChatBubblePool()->Draw();
	
	if(pChat) pChat->Render();

	if(pScoreBoard) pScoreBoard->Draw();
	if(pDialog) pDialog->Draw();

	if(pSpawnScreen) pSpawnScreen->Render();
	if(pKeyBoard) pKeyBoard->Render();
	
	if(pButtonPanel) pButtonPanel->draw();
	if(pExtButtonPanel) pExtButtonPanel->draw();
		
		
		// Debug Labels
		if(bShowDebugLabels)
		{
			CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
			if(pVehiclePool)
			{
				for(uint16_t x = 0; x < MAX_VEHICLES; x++)
				{
					CVehicle *pVehicle = pVehiclePool->GetAt(x);
					if (pVehicle)
					{
						if(pVehicle->GetDistanceFromLocalPlayerPed() <= 20.0f)
						{
							MATRIX4X4 matVehicle;
							pVehicle->GetMatrix(&matVehicle);

							VECTOR InfoPos;
							InfoPos.X = matVehicle.pos.X;
							InfoPos.Y = matVehicle.pos.Y;
							InfoPos.Z = matVehicle.pos.Z;
							
							VECTOR Out;
							
							// CSprite::CalcScreenCoors
							(( void (*)(VECTOR*, VECTOR*, float*, float*, bool, bool))(g_libGTASA+0x54EEC0+1))(&InfoPos, &Out, 0, 0, 0, 0);
							
							if(Out.Z < 1.0f) return;
							
							char szText[255];
							sprintf(szText, "[ID: %d | Model: %d | Health: %.1f]\nDistance: %.2fm\nPosition: %.3f, %.3f, %.3f\nSpawned at: %.3f, %.3f, %.3f", x, pVehicle->GetModelIndex(), pVehicle->GetHealth(), pVehicle->GetDistanceFromLocalPlayerPed(), matVehicle.pos.X, matVehicle.pos.Y, matVehicle.pos.Z, pVehiclePool->m_vecSpawnPos[x].X, pVehiclePool->m_vecSpawnPos[x].Y, pVehiclePool->m_vecSpawnPos[x].Z);
							
							ImVec2 pos = ImVec2(Out.X, Out.Y);
							RenderText(m_font, pos, COLOR_ORANGE, true, szText, nullptr);
						}
					}
				}
			}
		}
	
	
	ImGui::Render();
	ImGuiWrapper::renderDrawData(ImGui::GetDrawData());
	
	if(g_bNeedClearMousePos)
	{
		io.MousePos = ImVec2(-1, -1);
		g_bNeedClearMousePos = false;
	}
}

void UI::RenderText(ImFont *pFont, ImVec2& posCur, ImU32 col, bool bOutline, const char* text_begin, const char* text_end, float fontsize)
{
	int iOffset = pSettings->Get().m_outlineSize;
	
	if (bOutline)
	{
		// left
		posCur.x -= iOffset;
		ImGui::GetBackgroundDrawList()->AddText(pFont, fontsize, posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.x += iOffset;
		// right
		posCur.x += iOffset;
		ImGui::GetBackgroundDrawList()->AddText(pFont, fontsize, posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.x -= iOffset;
		// above
		posCur.y -= iOffset;
		ImGui::GetBackgroundDrawList()->AddText(pFont, fontsize, posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.y += iOffset;
		// below
		posCur.y += iOffset;
		ImGui::GetBackgroundDrawList()->AddText(pFont, fontsize, posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.y -= iOffset;
	}

	ImGui::GetBackgroundDrawList()->AddText(pFont, fontsize, posCur, col, text_begin, text_end);
}

void UI::RenderText2(ImVec2& posCur, ImU32 col, bool bOutline, const char* text_begin, const char* text_end, float font_size)
{
	int iOffset = pSettings->Get().m_outlineSize;

	if (bOutline)
	{
		// left
		posCur.x -= iOffset;
		ImGui::GetBackgroundDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.x += iOffset;
		// right
		posCur.x += iOffset;
		ImGui::GetBackgroundDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.x -= iOffset;
		// above
		posCur.y -= iOffset;
		ImGui::GetBackgroundDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.y += iOffset;
		// below
		posCur.y += iOffset;
		ImGui::GetBackgroundDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.y -= iOffset;
	}

	ImGui::GetBackgroundDrawList()->AddText(NULL, font_size, posCur, col, text_begin, text_end);
}

void UI::RenderAuthor()
{
	const auto encVersion = cryptor::create("", 19);
	ImVec2 verpos = ImVec2(ScaleX(720), ScaleY(10));
	RenderText2(verpos, ImColor(0.96f, 0.56f, 0.19f, 1.0f), true, encVersion.decrypt());
}

void UI::SetupStyleColors()
{
	ImGuiStyle* style = &ImGui::GetStyle();
	ImVec4* colors = style->Colors;

	style->WindowPadding = ImVec2(4, 4);
	style->WindowRounding = 0.2f;
	style->FrameRounding = 0.0f;
	style->ItemSpacing = ImVec2(8, 1.3);
	style->ScrollbarSize = ScaleY(35.0f);
	style->ScrollbarRounding = 9.0f;
	style->WindowBorderSize = 0.0f;
	style->ChildBorderSize  = 0.4f;
	style->FrameBorderSize  = 0.0f;
	style->ChildRounding = 2.75f;

	colors[ImGuiCol_Text] = ImVec4(0.80f, 0.80f, 0.83f, 1.00f);
	colors[ImGuiCol_TextDisabled] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	colors[ImGuiCol_WindowBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.74f);
	colors[ImGuiCol_ChildBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
	colors[ImGuiCol_PopupBg] = ImVec4(0.07f, 0.07f, 0.09f, 1.00f);
	colors[ImGuiCol_Border] = ImVec4(0.12f, 0.12f, 0.12f, 0.78f);
	colors[ImGuiCol_BorderShadow] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
	colors[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	colors[ImGuiCol_FrameBgActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	colors[ImGuiCol_ScrollbarBg] = ImVec4(0.10f, 0.09f, 0.12f, 1.00f);
	colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.7f, 0.12f, 0.12f, 1.0f);
	colors[ImGuiCol_ScrollbarGrabHovered] = colors[ImGuiCol_ScrollbarGrab];
	colors[ImGuiCol_ScrollbarGrabActive] = colors[ImGuiCol_ScrollbarGrab];
	colors[ImGuiCol_Button] = ImVec4(0.078f, 0.078f, 0.078f, 1.0f);
	colors[ImGuiCol_ButtonHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	colors[ImGuiCol_ButtonActive] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	colors[ImGuiCol_Header] = ImVec4(0.7f, 0.12f, 0.12f, 1.0f);
	colors[ImGuiCol_HeaderHovered] = colors[ImGuiCol_Header];
	colors[ImGuiCol_HeaderActive] = colors[ImGuiCol_Header];
}
