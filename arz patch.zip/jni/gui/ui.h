#pragma once
#include "vendor/imgui/imgui.h"
#include "imguiwrapper.h"
#include "imguirenderer.h"
#include "scrollpanel.h"

enum eTouchType
{
	TOUCH_POP = 1,
	TOUCH_PUSH = 2,
	TOUCH_MOVE = 3
};

class UI
{
public:
	UI();
	~UI();

	void Render();
	float ScaleX(float x) { return m_vecScale.x * x; }
	float ScaleY(float y) { return m_vecScale.y * y; }
	ImFont* GetFont() { return m_font; }
	float GetFontSize() { return m_fontSize; }

	void RenderText(ImFont* pFont, ImVec2& posCur, ImU32 col, bool bOutline, const char* text_begin, const char* text_end = nullptr, float fontsize = 0.0f);

	void RenderText2(ImVec2& pos, ImU32 col, bool bOutline, const char* text_begin, const char* text_end = nullptr, float font_size = 0.0f);
	void SetupStyleColors();
	
public:
	bool		m_noPause;
	
private:
	void RenderAuthor();
	
private:
	ImFont* 	m_font;

	ImVec2		m_vecScale;
	float 		m_fontSize;

	bool 		m_bMousePressed;
	ImVec2		m_vecMousePos;
};
