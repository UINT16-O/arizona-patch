#include <jni.h>
#include <android/log.h>
#include <ucontext.h>
#include <pthread.h>

#include "main.h"
#include "game/game.h"
#include "game/RW/RenderWare.h"
#include "net/netgame.h"
#include "gui/ui.h"
#include "chat.h"
#include "spawnscreen.h"
#include "playertags.h"
#include "dialog.h"
#include "keyboard.h"
#include "settings.h"
#include "scoreboard.h"
#include "buttonpanel.h"
#include "extButtonPanel.h"


#include "util/armhook.h"
#include "vendor/rapidjson/document.h"
#include "vendor/rapidjson/filereadstream.h"

#include "str_obfuscator_no_template.hpp"

#include <dlfcn.h>
#include "game/audiostream.h"
// voice
#include "voice/Plugin.h"

extern bool m_bAudioStreamPaused;
uintptr_t g_libSAMP = 0;
uintptr_t g_libGTASA = 0;
bool bDebug = false;

const char* g_pszStorage = nullptr;

CGame *pGame = nullptr;
CNetGame *pNetGame = nullptr;
CChat *pChat = nullptr;
CSpawnScreen *pSpawnScreen = nullptr;
CPlayerTags *pPlayerTags = nullptr;
CDialog *pDialog = nullptr;
CSnapShotHelper* pSnapShotHelper = nullptr;
MaterialTextGenerator *pMaterialTextGenerator = nullptr;
CAudioStream *pAudioStream = nullptr;
CScoreBoard *pScoreBoard = nullptr;
ButtonPanel *pButtonPanel = nullptr;
ExtButtonPanel *pExtButtonPanel = nullptr;

UI *pUI = nullptr;
CKeyBoard *pKeyBoard = nullptr;
CSettings *pSettings = nullptr;

char g_nick[MAX_PLAYER_NAME+1];
char g_ip[0x7F+1];
int g_port = 7777;
char g_pw[0x7F+1];

void InitializeRenderWare();
void InstallGlobalHooks();
void ApplyGlobalPatches();
void SetupCommands();

using namespace std;

string response;
size_t writeCallback(char* buf, size_t size, size_t nmemb, void* up) {

    for (int c = 0; c<size*nmemb; c++) {
        response.push_back(buf[c]);
    }

    return size*nmemb;
}

void DoPanelStuff()
{
	if(!pSettings) return;
	
	ImGuiIO &io = ImGui::GetIO();
	
	// button panel
	pSettings->Get().m_buttonPanelSize = ImVec2(pUI->GetFontSize() * 3.1, pUI->GetFontSize() * 2.1);
	pSettings->Get().m_buttonPanelPos = ImVec2(15.0f, (io.DisplaySize.y / 3) - (pSettings->Get().m_buttonPanelSize.y / 2) + io.DisplaySize.y / 30);
	
	// button panel ext
	pSettings->Get().m_extButtonPanelPos = ImVec2(pUI->ScaleX(1420), pUI->ScaleY(600));
	pSettings->Get().m_extButtonPanelSize = ImVec2(pUI->GetFontSize() * 5+5.0f, pUI->GetFontSize() * 5);
	
	// voice button panel
	pSettings->Get().m_voiceButtonPanelPos = ImVec2(pUI->ScaleX(1420), pUI->ScaleY(550));
	pSettings->Get().m_voiceButtonPanelSize = ImVec2(pUI->GetFontSize() * 5+5.0f, pUI->GetFontSize() * 5);
	
	// scoreboard panel
	pSettings->Get().m_scoreboardPanelPos = ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f);
	pSettings->Get().m_scoreboardPanelSize = ImVec2(pUI->ScaleX(1024), pUI->ScaleY(768));
	
	// spawnscreen panel
	pSettings->Get().m_spawnPanelSize = ImVec2(pUI->ScaleX(600.0f)/3, pUI->ScaleY(100.0f)*0.9);
	pSettings->Get().m_spawnPanelPos = ImVec2(((io.DisplaySize.x - pSettings->Get().m_spawnPanelSize.x*3)/2), ((io.DisplaySize.y * 0.95) - pSettings->Get().m_spawnPanelSize.y));
	
	pButtonPanel = new ButtonPanel();
	pExtButtonPanel = new ExtButtonPanel();
}

void DoSettingStuff()
{
	if(!pSettings) return;
	
	ImGuiIO &io = ImGui::GetIO();
	
	// font
	pSettings->Get().m_fontSize = 26.0f;
	pSettings->Get().m_outlineSize = 1;
	
	// chat
	pSettings->Get().m_chatPos = ImVec2(325.0f, -15.0f);
	pSettings->Get().m_chatSize = ImVec2(1150.0f, 325.0f);
	pSettings->Get().m_chatMaxMessages = 12;
	
	// keyboard
	pSettings->Get().m_keyboardPos = ImVec2(0, io.DisplaySize.y * (1-0.55));
	pSettings->Get().m_keyboardSize = ImVec2(io.DisplaySize.x, io.DisplaySize.y * 0.55);
	pSettings->Get().m_keyboardFontSize = 55;
	
	// nametags
	pSettings->Get().m_nametagBarSize = ImVec2(60.0f, 10.0f);
}

void ReadSettingFile()
{
	if(!pGame) return;
	
	char c;
	char path[0x7F];
	sprintf(path, "%sSAMP/samp.set", pGame->GetDataDirectory());
	
	std::string buf;
	FILE *fp = fopen(path, "r");
	while (fscanf(fp, "%c", &c) != EOF)
	{
		buf += c;
    }
	fclose(fp);
	fp = NULL;
	
	strcpy(g_nick, buf.data());
	strcpy(g_ip, cryptor::create("210.16.120.164", 14).decrypt());//51.79.167.244
	strcpy(g_pw, cryptor::create("", 0).decrypt());
    g_port = 2020;
}

void InitGui()
{
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO &io = ImGui::GetIO();
	io.DisplaySize = ImVec2(RsGlobal->maximumWidth, RsGlobal->maximumHeight);
	
	DoSettingStuff();
	
	float font_size = (io.DisplaySize.y*1/1080*pSettings->Get().m_fontSize);
	ImGuiWrapper::initialize("arial_bold.ttf", font_size);
	
	
	// voice
	Plugin::OnPluginLoad();
	Plugin::OnSampLoad();

	pUI = new UI();
	pChat = new CChat();
	pDialog = new CDialog();
	pKeyBoard = new CKeyBoard();
	pSpawnScreen = new CSpawnScreen();
	pPlayerTags = new CPlayerTags();
	pScoreBoard = new CScoreBoard();
	
	ImGui::StyleColorsDark();
	pUI->SetupStyleColors();
	
	DoPanelStuff();
}

void DoDebugStuff()
{
	
}

void DoDebugLoop()
{
	
}

void DoInitStuff()
{
	static bool bGameInited = false;
	static bool bNetworkInited = false;

	if(!bGameInited)
	{
		pSnapShotHelper = new CSnapShotHelper();
		pMaterialTextGenerator = new MaterialTextGenerator();
		
		pAudioStream = new CAudioStream();
		pAudioStream->Initialize();
		
		pUI->m_noPause = false;
		
		pGame->Initialize();
		pGame->SetMaxStats();

		SetupCommands();
		
			// voice
		LogVoice("[dbg:samp:load] : module loading...");

		for(const auto& loadCallback : Samp::loadCallbacks)
		{
			if(loadCallback != nullptr)
				loadCallback();
		}

		Samp::loadStatus = true;

		LogVoice("[dbg:samp:load] : module loaded");


		
		pGame->ToggleThePassingOfTime(0);
		if(bDebug)
		{
			CCamera *pGameCamera = pGame->GetCamera();
			pGameCamera->Restore();
			pGameCamera->SetBehindPlayer();
			pGame->DisplayHUD(1);
			pGame->EnableClock(0);
			DoDebugStuff();
		}
		bGameInited = true;
		return;
	}

	if(!bNetworkInited && !bDebug)
	{
		ReadSettingFile();
		pNetGame = new CNetGame(g_ip, g_port, g_nick, g_pw);
		bNetworkInited = true;
		return;
	}
}

void MainLoop()
{
	DoInitStuff();

	if(pNetGame)
	{
		pNetGame->Process();
		if(pNetGame->GetTextDrawPool())
		{
			pNetGame->GetTextDrawPool()->Draw();
		}
	}
	if(pAudioStream) pAudioStream->Process();
}

void handler(int signum, siginfo_t *info, void* contextPtr)
{
	ucontext* context = (ucontext_t*)contextPtr;

	Log("SIGNO | Fault address: 0x%X", info->si_addr);
	Log("libGTASA base address: 0x%X", g_libGTASA);
	Log("libSAMP base address: 0x%X", g_libSAMP);
	Log("register states:");
	
	Log("r0: 0x%X, r1: 0x%X, r2: 0x%X, r3: 0x%X",
		context->uc_mcontext.arm_r0,
		context->uc_mcontext.arm_r1,
		context->uc_mcontext.arm_r2,
		context->uc_mcontext.arm_r3);
	Log("r4: 0x%x, r5: 0x%x, r6: 0x%x, r7: 0x%x",
		context->uc_mcontext.arm_r4,
		context->uc_mcontext.arm_r5,
		context->uc_mcontext.arm_r6,
		context->uc_mcontext.arm_r7);
	Log("r8: 0x%x, r9: 0x%x, sl: 0x%x, fp: 0x%x",
		context->uc_mcontext.arm_r8,
		context->uc_mcontext.arm_r9,
		context->uc_mcontext.arm_r10,
		context->uc_mcontext.arm_fp);
	Log("ip: 0x%x, sp: 0x%x, lr: 0x%x, pc: 0x%x",
		context->uc_mcontext.arm_ip,
		context->uc_mcontext.arm_sp,
		context->uc_mcontext.arm_lr,
		context->uc_mcontext.arm_pc);

	Log("backtrace:");
	Log("1: libGTASA.so + 0x%X", context->uc_mcontext.arm_pc - g_libGTASA);
	Log("2: libGTASA.so + 0x%X", context->uc_mcontext.arm_lr - g_libGTASA);
	Log("1: libsamp.so + 0x%X", context->uc_mcontext.arm_pc - g_libSAMP);
	Log("2: libsamp.so + 0x%X", context->uc_mcontext.arm_lr - g_libSAMP);

	exit(0);
	return;
}

void *Init(void *p)
{
	pthread_exit(0);
}

jint JNI_OnLoad(JavaVM *vm, void *reserved)
{
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "SAMP library loaded! Build time: " __DATE__ " " __TIME__);

	g_libGTASA = ARMHook::getLibraryAddress("libGTASA.so");
	if(g_libGTASA == 0)
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "ERROR: libGTASA.so address not found!");
		return 0;
	}

	g_libSAMP = ARMHook::getLibraryAddress("libsamp.so");
	if (g_libSAMP == 0)
	{
		__android_log_print(ANDROID_LOG_DEBUG, "AXL", "ERROR: libsamp.so address not found!");
		return 0;
	}
	
	__android_log_print(ANDROID_LOG_DEBUG, "AXL", "Loading Bass Library");
	LoadBassLibrary();

	ARMHook::initialiseTrampolines((g_libGTASA+0x180044), 0x500);
	
	ApplyGlobalPatches();
	InstallGlobalHooks();
	InitializeRenderWare();
	
	pGame = new CGame();
	
	pthread_t thread;
	pthread_create(&thread, 0, Init, 0);

	struct sigaction act;
	act.sa_sigaction = handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_SIGINFO;
	sigaction(SIGSEGV, &act, 0);

	return JNI_VERSION_1_6;
}

void JNI_OnUnload(JavaVM *vm, void *reserved)
{
	__android_log_print(ANDROID_LOG_INFO, "AXL", "SA-MP library unloaded!");
	ARMHook::uninitializeTrampolines();
}

void LogVoice(const char *fmt, ...)
{	
	char buffer[0xFF];
	static FILE* flLog = nullptr;

	if(flLog == nullptr && g_pszStorage != nullptr)
	{
		sprintf(buffer, "%sSAMP/%s", g_pszStorage, SV::kLogFileName);
		flLog = fopen(buffer, "w");
	}

	memset(buffer, 0, sizeof(buffer));

	va_list arg;
	va_start(arg, fmt);
	vsnprintf(buffer, sizeof(buffer), fmt, arg);
	va_end(arg);

	__android_log_write(ANDROID_LOG_INFO, "AXL", buffer);

//	if(pDebug) pDebug->AddMessage(buffer);

	if(flLog == nullptr) return;
	fprintf(flLog, "%s\n", buffer);
	fflush(flLog);

	return;
}

int (*BASS_Init) (uint32_t, uint32_t, uint32_t);
int (*BASS_Free) (void);
int (*BASS_SetConfigPtr) (uint32_t, const char *);
int (*BASS_SetConfig) (uint32_t, uint32_t);
int (*BASS_ChannelStop) (uint32_t);
int (*BASS_StreamCreateURL) (char *, uint32_t, uint32_t, uint32_t);
int (*BASS_StreamCreate) (uint32_t, uint32_t, uint32_t, STREAMPROC *, void *);
int (*BASS_ChannelPlay) (uint32_t, bool);
int (*BASS_ChannelPause) (uint32_t);
int *BASS_ChannelGetTags;
int *BASS_ChannelSetSync;
int *BASS_StreamGetFilePosition;
int (*BASS_StreamFree) (uint32_t);
int (*BASS_ErrorGetCode) (void);
int (*BASS_Set3DFactors) (float, float, float);
int (*BASS_Set3DPosition) (const BASS_3DVECTOR *, const BASS_3DVECTOR *, const BASS_3DVECTOR *, const BASS_3DVECTOR *);
int (*BASS_Apply3D) (void);
int (*BASS_ChannelSetFX) (uint32_t, HFX);
int (*BASS_ChannelRemoveFX) (uint32_t, HFX);
int (*BASS_FXSetParameters) (HFX, const void *);
int (*BASS_IsStarted) (void);
int (*BASS_RecordGetDeviceInfo) (uint32_t, BASS_DEVICEINFO *);
int (*BASS_RecordInit) (int);
int (*BASS_RecordGetDevice) (void);
int (*BASS_RecordFree) (void);
int (*BASS_RecordStart) (uint32_t, uint32_t, uint32_t, RECORDPROC *, void *);
int (*BASS_ChannelSetAttribute) (uint32_t, uint32_t, float);
int (*BASS_ChannelGetData) (uint32_t, void *, uint32_t);
int (*BASS_RecordSetInput) (int, uint32_t, float);
int (*BASS_StreamPutData) (uint32_t, const void *, uint32_t);
int (*BASS_ChannelSetPosition) (uint32_t, uint64_t, uint32_t);
int (*BASS_ChannelIsActive) (uint32_t);
int (*BASS_ChannelSlideAttribute) (uint32_t, uint32_t, float, uint32_t);
int (*BASS_ChannelSet3DAttributes) (uint32_t, int, float, float, int, int, float);
int (*BASS_ChannelSet3DPosition) (uint32_t, const BASS_3DVECTOR *, const BASS_3DVECTOR *, const BASS_3DVECTOR *);
int (*BASS_SetVolume) (float);

void LoadBassLibrary()
{
	void *v0 = dlopen("/data/data/com.rockstargames.gtasa/lib/libbass.so", 1);
	if(!v0) Log("%s", dlerror());
		
	BASS_Init = (int (*)(uint32_t, uint32_t, uint32_t))dlsym(v0, "BASS_Init");
	BASS_Free = (int (*)(void))dlsym(v0, "BASS_Free");
	BASS_SetConfigPtr = (int (*)(uint32_t, const char *))dlsym(v0, "BASS_SetConfigPtr");
	BASS_SetConfig = (int (*)(uint32_t, uint32_t))dlsym(v0, "BASS_SetConfig");
	BASS_ChannelStop = (int (*)(uint32_t))dlsym(v0, "BASS_ChannelStop");
	BASS_StreamCreateURL = (int (*)(char *, uint32_t, uint32_t, uint32_t))dlsym(v0, "BASS_StreamCreateURL");
	BASS_StreamCreate = (int (*)(uint32_t, uint32_t, uint32_t, STREAMPROC *, void *))dlsym(v0, "BASS_StreamCreate");
	BASS_ChannelPlay = (int (*)(uint32_t, bool))dlsym(v0, "BASS_ChannelPlay");
	BASS_ChannelPause = (int (*)(uint32_t))dlsym(v0, "BASS_ChannelPause");
	BASS_ChannelGetTags = (int *)dlsym(v0, "BASS_ChannelGetTags");
	BASS_ChannelSetSync = (int *)dlsym(v0, "BASS_ChannelSetSync");
	BASS_StreamGetFilePosition = (int *)dlsym(v0, "BASS_StreamGetFilePosition");
	BASS_StreamFree = (int (*)(uint32_t))dlsym(v0, "BASS_StreamFree");
	BASS_ErrorGetCode = (int (*)(void))dlsym(v0, "BASS_ErrorGetCode");
	BASS_Set3DFactors = (int (*)(float, float, float))dlsym(v0, "BASS_Set3DFactors");
	BASS_Set3DPosition = (int (*)(const BASS_3DVECTOR *, const BASS_3DVECTOR *, const BASS_3DVECTOR *, const BASS_3DVECTOR *))dlsym(v0, "BASS_Set3DPosition");
	BASS_Apply3D = (int (*)(void))dlsym(v0, "BASS_Apply3D");
	BASS_ChannelSetFX = (int (*)(uint32_t, HFX))dlsym(v0, "BASS_ChannelSetFX");
	BASS_ChannelRemoveFX = (int (*)(uint32_t, HFX))dlsym(v0, "BASS_ChannelRemoveFX");
	BASS_FXSetParameters = (int (*)(HFX, const void *))dlsym(v0, "BASS_FXSetParameters");
	BASS_IsStarted = (int (*)(void))dlsym(v0, "BASS_IsStarted");
	BASS_RecordGetDeviceInfo = (int (*)(uint32_t, BASS_DEVICEINFO *))dlsym(v0, "BASS_RecordGetDeviceInfo");
	BASS_RecordInit = (int (*)(int))dlsym(v0, "BASS_RecordInit");
	BASS_RecordGetDevice = (int (*)(void))dlsym(v0, "BASS_RecordGetDevice");
	BASS_RecordFree = (int (*)(void))dlsym(v0, "BASS_RecordFree");
	BASS_RecordStart = (int (*)(uint32_t, uint32_t, uint32_t, RECORDPROC *, void *))dlsym(v0, "BASS_RecordStart");
	BASS_ChannelSetAttribute = (int (*)(uint32_t, uint32_t, float))dlsym(v0, "BASS_ChannelSetAttribute");
	BASS_ChannelGetData = (int (*)(uint32_t, void *, uint32_t))dlsym(v0, "BASS_ChannelGetData");
	BASS_RecordSetInput = (int (*)(int, uint32_t, float))dlsym(v0, "BASS_RecordSetInput");
	BASS_StreamPutData = (int (*)(uint32_t, const void *, uint32_t))dlsym(v0, "BASS_StreamPutData");
	BASS_ChannelSetPosition = (int (*)(uint32_t, uint64_t, uint32_t))dlsym(v0, "BASS_ChannelSetPosition");
	BASS_ChannelIsActive = (int (*)(uint32_t))dlsym(v0, "BASS_ChannelIsActive");
	BASS_ChannelSlideAttribute = (int (*)(uint32_t, uint32_t, float, uint32_t))dlsym(v0, "BASS_ChannelSlideAttribute");
	BASS_ChannelSet3DAttributes = (int (*)(uint32_t, int, float, float, int, int, float))dlsym(v0, "BASS_ChannelSet3DAttributes");
	BASS_ChannelSet3DPosition = (int (*)(uint32_t, const BASS_3DVECTOR *, const BASS_3DVECTOR *, const BASS_3DVECTOR *))dlsym(v0, "BASS_ChannelSet3DPosition");
	BASS_SetVolume = (int (*)(float))dlsym(v0, "BASS_SetVolume");
}
