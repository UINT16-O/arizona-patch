#include "../main.h"
#include "game/game.h"
#include "netgame.h"

CActorPool::CActorPool()
{
	for(uint16_t actorId = 0; actorId < MAX_ACTORS; actorId++)
	{
		m_pActors[actorId] = nullptr;
		m_bActorSlotState[actorId] = 0;
	}
}

CActorPool::~CActorPool()
{
	for(uint16_t actorId = 0; actorId < MAX_ACTORS; actorId++)
	{
		Delete(actorId);
	}
}

bool CActorPool::New(NEW_ACTOR *pNewActor)
{
	Delete(pNewActor->actorId);
	
	CActor *pActor = new CActor(pNewActor->iSkin, pNewActor->vecPos.X, pNewActor->vecPos.Y, pNewActor->vecPos.Z, pNewActor->fRotation);
	
	if(pActor)
	{
		m_pActors[pNewActor->actorId] = pActor;
		m_bActorSlotState[pNewActor->actorId] = true;
		
		pActor->SetHealth(pNewActor->fHealth);
		pActor->SetInvulnerable(pNewActor->bInvulnerable);
		return true;
	}
	return false;
}

bool CActorPool::Delete(uint16_t actorId)
{
	if(m_pActors[actorId])
	{
		delete m_pActors[actorId];
		m_pActors[actorId] = nullptr;
		m_bActorSlotState[actorId] = false;
		return true;
	}
	return false;
}