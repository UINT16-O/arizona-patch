#pragma once

#define MAX_ACTORS 1000
#define INVALID_ACTOR_ID 0xFFFF

typedef struct _NEW_ACTOR
{
	uint16_t	actorId;
	int			iSkin;
	VECTOR		vecPos;
	float		fRotation;
	float		fHealth;
	bool		bInvulnerable;
} NEW_ACTOR;

class CActorPool
{
private:
	bool m_bActorSlotState[MAX_ACTORS];
	CActor *m_pActors[MAX_ACTORS];
	
public:
	CActorPool();
	~CActorPool();

	bool New(NEW_ACTOR *pNewActor);
	bool Delete(uint16_t actorId);

	bool GetSlotState(uint16_t actorId)
	{
		if(actorId > MAX_ACTORS) return false;
		return m_bActorSlotState[actorId];
	};

	CActor *GetAt(uint16_t actorId)
	{
		if(actorId > MAX_PLAYERS || !m_bActorSlotState[actorId]) return nullptr;
		return m_pActors[actorId];
	};
};