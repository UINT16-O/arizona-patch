#include "main.h"
#include "game/game.h"
#include "netgame.h"

extern CGame *pGame;

CPlayerPool::CPlayerPool()
{
	m_pLocalPlayer = new CLocalPlayer();

	for(PLAYERID playerId = 0; playerId < MAX_PLAYERS; playerId++)
	{
		m_bPlayerSlotState[playerId] = false;
		m_pPlayers[playerId] = nullptr;
	}
}

CPlayerPool::~CPlayerPool()
{
	delete m_pLocalPlayer;
	m_pLocalPlayer = nullptr;

	for(PLAYERID playerId = 0; playerId < MAX_PLAYERS; playerId++)
		Delete(playerId, 0);
}

bool CPlayerPool::Process()
{
	for(PLAYERID playerId = 0; playerId < MAX_PLAYERS; playerId++)
	{
		if(m_bPlayerSlotState[playerId])
			m_pPlayers[playerId]->Process();
	}

	m_pLocalPlayer->Process();	

	return true;
}

void CPlayerPool::ProcessAttachedObjects()
{
	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed)
	{
		pPlayerPed->ProcessCuffAndCarry();
		pPlayerPed->ProcessAttachedObjects();
	}

	for(int i = 0; i < MAX_PLAYERS; i++)
	{
		if(m_bPlayerSlotState[i])
		{
			pPlayerPed = m_pPlayers[i]->GetPlayerPed();
			if(pPlayerPed)
			{
				pPlayerPed->ProcessCuffAndCarry();
				pPlayerPed->ProcessAttachedObjects();
			}
		}
	}
}

bool CPlayerPool::New(PLAYERID playerId, char *szPlayerName, bool IsNPC)
{
	m_pPlayers[playerId] = new CRemotePlayer();

	if(m_pPlayers[playerId])
	{
		strcpy(m_szPlayerNames[playerId], szPlayerName);
		m_pPlayers[playerId]->SetID(playerId);
		m_pPlayers[playerId]->SetNPC(IsNPC);
		m_bPlayerSlotState[playerId] = true;

		return true;
	}

	return false;
}

bool CPlayerPool::Delete(PLAYERID playerId, uint8_t byteReason)
{
	if(!GetSlotState(playerId) || !m_pPlayers[playerId])
		return false;

	if(GetLocalPlayer()->IsSpectating() && GetLocalPlayer()->m_SpectateID == playerId)
		GetLocalPlayer()->ToggleSpectating(false);

	m_bPlayerSlotState[playerId] = false;
	delete m_pPlayers[playerId];
	m_pPlayers[playerId] = nullptr;

	return true;
}

PLAYERID CPlayerPool::FindRemotePlayerIDFromGtaPtr(PED_TYPE * pActor)
{
	CPlayerPed *pPlayerPed;

	for(PLAYERID playerId = 0; playerId < MAX_PLAYERS; playerId++)
	{
		if(true == m_bPlayerSlotState[playerId])
		{
			pPlayerPed = m_pPlayers[playerId]->GetPlayerPed();

			if(pPlayerPed) {
				PED_TYPE *pTestActor = pPlayerPed->GetGtaActor();
				if((pTestActor != NULL) && (pActor == pTestActor)) // found it
					return m_pPlayers[playerId]->GetID();
			}
		}
	}

	return INVALID_PLAYER_ID;	
}

PLAYERID CPlayerPool::GetCount()
{
	PLAYERID byteCount = 0;
	for(PLAYERID p = 0; p < MAX_PLAYERS; p++)
	{
		if(GetSlotState(p)) byteCount++;
	}
	return byteCount;
}

void CPlayerPool::DeactivateAll()
{
	m_pLocalPlayer->Deactivate();
	
	for(PLAYERID playerId = 0; playerId < MAX_PLAYERS; playerId++)
	{
		if(GetSlotState(playerId))
			m_pPlayers[playerId]->Deactivate();
	}
}

void CPlayerPool::ApplyCollisionChecking()
{
	for(int i = 0; i < MAX_PLAYERS; i++)
	{
		CRemotePlayer *pPlayer = GetAt(i);
		if(pPlayer)
		{
			CPlayerPed *pPlayerPed = pPlayer->GetPlayerPed();
			if(pPlayerPed)
			{
				if(!pPlayerPed->IsInVehicle())
				{
					m_bCollisionChecking[i] = pPlayerPed->GetCollisionChecking();
					pPlayerPed->SetCollisionChecking(true);
				}
			}
		}
	}
}

void CPlayerPool::ResetCollisionChecking()
{
	for(int i = 0; i < MAX_PLAYERS; i++)
	{
		CRemotePlayer *pPlayer = GetAt(i);
		if(pPlayer)
		{
			CPlayerPed *pPlayerPed = pPlayer->GetPlayerPed();
			if(pPlayerPed)
			{
				if(!pPlayerPed->IsInVehicle())
				{
					pPlayerPed->SetCollisionChecking(m_bCollisionChecking[i]);
				}
			}
		}
	}
}