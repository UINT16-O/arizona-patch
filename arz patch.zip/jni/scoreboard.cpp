#include "main.h"
#include "scoreboard.h"
#include "game/game.h"
#include "net/netgame.h"
#include "gui/ui.h"
#include "vendor/imgui/imgui_internal.h"
#include "settings.h"

extern UI *pUI;
extern CNetGame *pNetGame;
extern CGame *pGame;
extern CSettings *pSettings;

CScoreBoard::CScoreBoard()
{
	m_iOffset = 0;
	
    m_bSorted = false;
    m_bToggle = false;
}

void CScoreBoard::setActive(bool bToggle)
{
	m_bToggle = bToggle;
	pUI->m_noPause = bToggle;
	ScriptCommand(&lock_actor, pGame->FindPlayerPed()->m_dwGTAId, (int)bToggle);
}

void SwapPlayerInfo(PLAYER_SCORE_INFO* psi1, PLAYER_SCORE_INFO* psi2)
{
	PLAYER_SCORE_INFO plrinf;
	memcpy(&plrinf, psi1, sizeof(PLAYER_SCORE_INFO));
	memcpy(psi1, psi2, sizeof(PLAYER_SCORE_INFO));
	memcpy(psi2, &plrinf, sizeof(PLAYER_SCORE_INFO));
}

void CScoreBoard::Draw()
{
    if(!m_bToggle) return;
	
	pNetGame->UpdatePlayerScoresAndPings();
	
	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	int playercount = pPlayerPool->GetCount() + 1;

	if(m_iOffset > (playercount - 20)) m_iOffset = (playercount - 20);
	if(m_iOffset < 0) m_iOffset = 0;
	
	PLAYER_SCORE_INFO* Players;
	Players = (PLAYER_SCORE_INFO*)malloc(playercount * sizeof(PLAYER_SCORE_INFO));
	memset(Players, 0, playercount * sizeof(PLAYER_SCORE_INFO));
	Players[0].dwID = pPlayerPool->GetLocalPlayerID();
	Players[0].szName = pPlayerPool->GetLocalPlayerName();
	Players[0].iScore = pPlayerPool->GetLocalPlayerScore();
	Players[0].dwPing = pPlayerPool->GetLocalPlayerPing();
	Players[0].dwColor = pPlayerPool->GetLocalPlayer()->GetPlayerColorAsARGB();
	int i = 1, x;
	for(x = 0; x < MAX_PLAYERS; x++)
	{
		if (!pPlayerPool->GetSlotState(x)) continue;
		Players[i].dwID = x;
		Players[i].szName = pPlayerPool->GetPlayerName(x);
		Players[i].iScore = pPlayerPool->GetRemotePlayerScore(x);
		Players[i].dwPing = pPlayerPool->GetRemotePlayerPing(x);
		Players[i].dwColor = pPlayerPool->GetAt(x)->GetPlayerColorAsARGB();

		i++;
	}

	if(m_bSorted)
	{
		for (i = 0; i < playercount - 1; i++)
		{
			for (PLAYERID j = 0; j < playercount - 1 - i; j++)
			{
				if (Players[j + 1].iScore > Players[j].iScore)
				{
					SwapPlayerInfo(&Players[j], &Players[j + 1]);
                }
            }
        }
	}
	
    int endplayer = playercount;
    char szPlayerId[11], szScore[11], szPing[11];
    unsigned char RGBcolors[3];
	
    ImGuiIO &io = ImGui::GetIO();
	
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 8));
	ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.06f, 0.8f));
	
    ImGui::SetNextWindowSize(pSettings->Get().m_scoreboardPanelSize, NULL);
    ImGui::SetNextWindowPos(pSettings->Get().m_scoreboardPanelPos, ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    ImGui::Begin("###beginScoreboard", NULL, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings);
	
    ImGui::Columns(4, "###serverInfo", false);
	
	ImGui::Text("%s", pNetGame->m_szHostName);
	ImGui::SetColumnWidth(-1, ((pSettings->Get().m_scoreboardPanelSize.x - (ImGui::CalcTextSize("Players: 1000").x + pUI->GetFontSize()*1.5))));
	ImGui::NextColumn();
	
	ImGui::Text("Players: %d", playercount);
	ImGui::SetColumnWidth(-1, (pSettings->Get().m_scoreboardPanelSize.x / 100 + pUI->GetFontSize() + ImGui::CalcTextSize("Players: 1000").x));
	ImGui::NextColumn();
	
	ImGui::Columns(1);
	
	ImGui::Text("");
	
	ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
	ImGui::BeginChild("###headers", ImVec2(-1, pUI->GetFontSize()+1.0f), false);
	
    ImGui::Columns(4, "###headersColumn", false);
	
    ImGui::Text("id");
	ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 10);
	ImGui::NextColumn();
	
    ImGui::Text("name");
	ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 60);
	ImGui::NextColumn();
	
    ImGui::Text("score");
	ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 15);
	ImGui::NextColumn();
	
    ImGui::Text("ping");
	ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 15);
	ImGui::NextColumn();
	
	ImGui::Columns(1);
	
	ImGui::EndChild();
	ImGui::PopStyleColor();
	
	ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.06f, 0.06f, 0.06f, 0.60f));
	
	ImGui::BeginChild("###list", ImVec2(-1, -1), true, ImGuiWindowFlags_NoScrollbar);
	
	ImGui::Columns(4, "###listColumn", false);
	
    for (x = m_iOffset; x < endplayer; x++)
    {
        sprintf(szPlayerId, "%d", Players[x].dwID);
        sprintf(szScore, "%d", Players[x].iScore);
        sprintf(szPing, "%d", Players[x].dwPing);

        RGBcolors[0] = (Players[x].dwColor - 0xFF000000) >> 16;
        RGBcolors[1] = ((Players[x].dwColor - 0xFF000000) & 0x00FF00) >> 8;
        RGBcolors[2] = ((Players[x].dwColor - 0xFF000000) & 0x0000FF);

        ImGui::TextColored(ImColor(RGBcolors[0], RGBcolors[1], RGBcolors[2]), "%s", szPlayerId);
		ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 10);
        ImGui::NextColumn();

        ImGui::TextColored(ImColor(RGBcolors[0], RGBcolors[1], RGBcolors[2]), "%s", Players[x].szName);
		ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 60);
        ImGui::NextColumn();

        ImGui::TextColored(ImColor(RGBcolors[0], RGBcolors[1], RGBcolors[2]), "%s", szScore);
		ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 15);
        ImGui::NextColumn();

        ImGui::TextColored(ImColor(RGBcolors[0], RGBcolors[1], RGBcolors[2]), "%s", szPing);
		ImGui::SetColumnWidth(-1, pSettings->Get().m_scoreboardPanelSize.x / 100 * 15);
        ImGui::NextColumn();
    }
    ImGui::Columns(1);
	
	ScrollPanel::performLayout();
    ImGui::EndChild();
    ImGui::End();
	ImGui::PopStyleVar();
	ImGui::PopStyleColor();
}