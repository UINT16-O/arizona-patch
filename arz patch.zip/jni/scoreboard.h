#pragma once
#include "game/game.h"

#include <iostream>

typedef struct _PLAYER_SCORE_INFO
{
    uint32_t dwID;
    char *szName;
    int iScore;
    int32_t dwPing;
    uint32_t dwColor;
} PLAYER_SCORE_INFO;

class CScoreBoard
{
public:
    CScoreBoard();
    ~CScoreBoard();

    void Draw();
	
    void setActive(bool bToggle);
	bool getState() { return m_bToggle; }
	
  bool m_bToggle;
	
private:
    int m_iOffset;
	
    bool m_bSorted;
};
