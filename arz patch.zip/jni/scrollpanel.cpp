#include "main.h"
#include "gui/ui.h"
#include "scrollpanel.h"
#include "vendor/imgui/imgui_internal.h"

void ScrollPanel::performLayout()
{
	ImGuiIO &io = ImGui::GetIO();
	ImGuiWindow *window = ImGui::GetCurrentWindow();
	ImVec2 windowPos = ImGui::GetWindowPos();
	ImVec2 windowSize = ImGui::GetWindowSize();

	ImGuiID active_id = ImGui::GetActiveID();
	bool any_scrollbar_active = active_id && (active_id == ImGui::GetWindowScrollbarID(window, ImGuiAxis_X) || active_id == ImGui::GetWindowScrollbarID(window, ImGuiAxis_Y));

	if(!any_scrollbar_active &&
		io.MousePos.x >= windowPos.x && io.MousePos.x <= windowPos.x + windowSize.x &&
		io.MousePos.y >= windowPos.y && io.MousePos.y <= windowPos.y + windowSize.y)
	{
		ImVec2 mouse_delta = io.MouseDelta;
		if(mouse_delta.x != 0.0f && mouse_delta.x <= 100.0f) setScrollX(ImGui::GetScrollX() + -mouse_delta.x);
		if(mouse_delta.y != 0.0f && mouse_delta.y <= 100.0f) setScrollY(ImGui::GetScrollY() + -mouse_delta.y);
	}
}

void ScrollPanel::setScrollX(float x)
{
	x = (x - 2); // scroll delta x
	ImGui::SetScrollX(x);
}

void ScrollPanel::setScrollY(float y)
{
	y = (y - 2); // scroll delta y
	ImGui::SetScrollY(y);
}