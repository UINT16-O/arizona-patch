#pragma once
#include "vendor/imgui/imgui.h"

class ScrollPanel
{
	friend class UI;
public:
	static void performLayout();
	static void setScrollX(float x);
	static float getScrollX();
	static void setScrollY(float y);
	static float getScrollY();
};