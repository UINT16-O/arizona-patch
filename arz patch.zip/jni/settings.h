#pragma once

#include "vendor/imgui/imgui.h"

struct stSettings
{
	// font
	float m_fontSize;
	int m_outlineSize;
	
	// chat
	ImVec2 m_chatPos;
	ImVec2 m_chatSize;
	int m_chatMaxMessages;
	
	// spawn
	ImVec2 m_spawnPanelPos;
	ImVec2 m_spawnPanelSize;
	
	// nametag bar
	ImVec2 m_nametagBarSize;
	
	// keyboard
	ImVec2 m_keyboardPos;
	ImVec2 m_keyboardSize;
	int m_keyboardFontSize;
	
	// button panel
	ImVec2 m_buttonPanelPos;
	ImVec2 m_buttonPanelSize;
	
	// button panel ext
	ImVec2 m_extButtonPanelPos;
	ImVec2 m_extButtonPanelSize;
	
	// voice button panel
	ImVec2 m_voiceButtonPanelPos;
	ImVec2 m_voiceButtonPanelSize;
	
	// scoreboard panel
	ImVec2 m_scoreboardPanelPos;
	ImVec2 m_scoreboardPanelSize;
};

class CSettings
{
public:
	CSettings() {};

	stSettings& Get() { return m_Settings; }
	
private:
	struct stSettings m_Settings;
};